#ifndef _TAFCO_HOME_H_
#define _TAFCO_HOME_H_

#include <cstdint>
#include "GFXExtended.h"
#include "vPicBitData.h"

/// @brief Класс для рисования картинок
class Images : public DispParams {
  public:
    /// @brief Доступные изображения для рисования (их псевдонимы)
    typedef enum ImageAlias : uint16_t {
      img_null,
      img_tafco_home_big,             /* tafco - заставка     */
      img_vestor_big,                 /* vestor - заставка     */
      img_units_10x_grad_celsius,     /* Градусы цельсия      */
      img_units_10x12_ppm,            /* ppm, млн^-1, см3/м3  */
      img_units_10x_percent,          /* %  */
      img_units_10x_kg,               /* kg  */
      img_units_10x_volt,             /* V  */
      img_butt_accept,
      img_butt_back,
      img_butt_down,
      img_butt_up,
      img_butt_rigth,
      img_butt_rloop,
      img_butt_lloop,
      img_butt_increment,
      img_butt_decrement,
    } tImageAlias;

  private:
    tVImageDescript*    image_descript;     /* Описание изображения */
    tImageAlias         image_alias;        /* Имя изображения      */
  public:
    uint16_t image_height;        /* Высота выбранного изображения */
    uint16_t image_width;         /* Ширина выбранного изображения */

  public:
    Images();
    /// @brief Конструктор
    /// @param [in] heigth        ::  Высота дисплея
    /// @param [in] width         ::  Ширина дисплея
    /// @param [in] buffer        ::  Буфер\память дисплея
    Images(uint16_t heigth, uint16_t width, uint8_t* buffer);
    /// @brief Получить псевдоним выбранного изображение
    /// @return Псевдоним изображения
    tImageAlias GetNameImage();
    /// @brief Установить изображение
    /// @param [in] name          :: Имя 
    void SetImage(tImageAlias name);
    /// @brief Получить ширину изображения
    /// @return Ширина [пиксель]
    uint16_t GetWidth();
    /// @brief Получить высоту изображения 
    /// @return Высота [пиксель]
    uint16_t GetHigh(); 
    /// @brief Нарисовать изображение
    /// @param [in] pos_x         :: Позиция по оси x_абцисс
    /// @param [in] pos_y         :: Позиция по оси y_ординат
    void DrawImage(uint8_t pos_x, uint8_t pos_y);
    /// @brief Нарисовать изображение
    /// @param [in] pos_x         :: Позиция по оси x_абцисс
    /// @param [in] pos_y         :: Позиция по оси y_ординат
    /// @param [in] inv           :: Инверсия
    void DrawImage(uint8_t pos_x, uint8_t pos_y, bool inv);
  protected:
    /// @brief Вывести один пиксель
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    void DrawPixel(uint16_t x, uint16_t y, uint8_t brightness);
};

#endif //__TAFCO_HOME_H_