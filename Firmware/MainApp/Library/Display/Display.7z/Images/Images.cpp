#include "Images.h"
#include "GFXExtended.h"

/// TODO: В зависимости от применения сбросить ширину и высоту, если изображение nullptr...

Images::Images() : DispParams(0, 0, nullptr) {}

Images::Images(uint16_t heigth, uint16_t width, uint8_t* buffer) : DispParams(heigth, width, buffer) {}

void Images::SetImage(tImageAlias name) {
  switch (name) {
    case tImageAlias::img_tafco_home_big:
        image_descript = (tVImageDescript*)&VImage_TAFCO_Home_Big;
      break;
    case tImageAlias::img_vestor_big:
        image_descript = (tVImageDescript*)&VImage_VESTOR_Big;
      break;
    case tImageAlias::img_units_10x_grad_celsius:
        image_descript = (tVImageDescript*)&VImage_Units10X_GradCelsius;
      break;
    case tImageAlias::img_units_10x12_ppm:
        image_descript = (tVImageDescript*)&VImage_Units10X_UnitsPPM;
      break;
    case tImageAlias::img_units_10x_percent:
        image_descript = (tVImageDescript*)&VImage_Units10X_Percent;
      break;
    case tImageAlias::img_units_10x_kg:
        image_descript = (tVImageDescript*)&VImage_Units_10x10_kg;
      break;
    case tImageAlias::img_units_10x_volt:
        image_descript = (tVImageDescript*)&VImage_Units10X_Volt;
      break;
    case tImageAlias::img_butt_accept:
        image_descript = (tVImageDescript*)&VImage_Button_Accept;
      break;
    case tImageAlias::img_butt_back:
        image_descript = (tVImageDescript*)&VImage_Button_Back;
      break;
    case tImageAlias::img_butt_down:
        image_descript = (tVImageDescript*)&VImage_Button_Down;
      break;
    case tImageAlias::img_butt_up:
        image_descript = (tVImageDescript*)&VImage_Button_Up;
      break;
    case tImageAlias::img_butt_rigth:
        image_descript = (tVImageDescript*)&VImage_Button_Rigth;
      break;
    case tImageAlias::img_butt_rloop:
        image_descript = (tVImageDescript*)&VImage_Button_RLoop;
      break;
    case tImageAlias::img_butt_lloop:
        image_descript = (tVImageDescript*)&VImage_Button_LLoop;
      break;
    case tImageAlias::img_butt_increment:
        image_descript = (tVImageDescript*)&VImage_Button_Increment;
      break;
    case tImageAlias::img_butt_decrement:
        image_descript = (tVImageDescript*)&VImage_Button_Decrement;
      break;
    default:
        image_descript = nullptr;
      break;
  }
  if(image_descript != nullptr) {
    image_alias     = name;
    image_height    = image_descript->height;
    image_width     = image_descript->width;
  }
}

Images::tImageAlias Images::GetNameImage() {
  tImageAlias img_alias {};
  if(image_descript != nullptr)
    img_alias = image_alias;
  return img_alias;
}

uint16_t Images::GetWidth(){
  return image_descript->width;
}

uint16_t Images::GetHigh(){
  return image_descript->height;
}

void Images::DrawImage(uint8_t pos_x, uint8_t pos_y) {
  DrawImage(pos_x, pos_y, false);
}

void Images::DrawImage(uint8_t pos_x, uint8_t pos_y, bool inv) {
  if(image_descript == nullptr || frame_buffer == nullptr)
    return;
  //! TODO:: Пока так, потом сделай формулу!!!
  const uint32_t  pixel_limit {(uint32_t)image_descript->height * (uint32_t)image_descript->width};  
  uint32_t  counter         = pixel_limit;
  uint16_t  current_byte    = 0;
  uint8_t   current_pixel   = 7;
  const uint8_t pix_brigth  = 0xf;
  const uint8_t pix_dim     = 0x0;
  if(false == inv) {
    (*(uint8_t*)(&pix_brigth)) = 0x0;
    (*(uint8_t*)(&pix_dim))    = 0xf;
  }
  // С начала двигаемся по Х слева на право, затем по Y сверху вниз
  for(uint8_t curr_y = 0; curr_y < image_descript->height; curr_y++) { 	  // слева на право
    for (uint8_t curr_x = 0; curr_x < image_descript->width; curr_x++) { 	// сверху - вниз
      // расчитываем байт
      if(( image_descript->data[current_byte] >> current_pixel ) & 0x01)
        DrawPixel(curr_x + pos_x, curr_y + pos_y, pix_brigth);
      else 
        DrawPixel(curr_x + pos_x, curr_y + pos_y, pix_dim);
      counter--;
      if (counter >= pixel_limit) return;
      current_pixel--;
      if (current_pixel >= 254) {
        current_pixel = 7;
        current_byte++;
      }
    }
  }
}

void Images::DrawPixel(uint16_t x, uint16_t y, uint8_t brightness) {
  if(frame_buffer == nullptr)     return;
  if (x > (disp_width - 1) || y > (disp_height - 1))
    return;
  if ((y * disp_width + x) % 2 == 1)
    frame_buffer[((y * disp_width) + x) / 2] = (frame_buffer[((y * disp_width) + x) / 2] & 0xF0) | brightness;
  else 
    frame_buffer[((y * disp_width) + x) / 2] = (frame_buffer[((y * disp_width) + x) / 2] & 0x0F) | (brightness << 4);
}