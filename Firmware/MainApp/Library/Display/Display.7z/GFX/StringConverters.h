#ifndef _STRINGCONVERTERS_H_
#define _STRINGCONVERTERS_H_

#include <cstdint>

class StringConverter {
  public:
    /// @brief Конвертирует число в ascii
    /// @param [in] placement   :: куда ложить байты 
    /// @param [in] length      :: длина placement
    /// @param [in] value       :: число
    /// @return Длина результата преобразования
    static uint16_t IntToString(uint8_t* placement, uint16_t length, int32_t value);
    
    /// @brief Конвертирует число в ascii
    /// @param [in] placement   :: куда ложить байты 
    /// @param [in] length      :: длина placement
    /// @param [in] value       :: число
    /// @return Длина результата преобразования
    static uint16_t U32ToString(uint8_t* placement, uint16_t length, uint32_t value);
    
    /// @brief Преобразует значение float в ASCII
    /// @param [in] buffer    :: Буфер куда ложить байты 
    /// @param [in] length    :: Длина буфера для ограничений
    /// @param [in] value     :: Значение
    /// @param [in] postfix   :: Строка_Постфикс
    /// @return Укзаатель на последний вставленный байт
    static uint8_t* FloatToString(uint8_t* buffer, uint16_t length, float* value, const char* postfix);
    /// @brief Преобразует значение float в ASCII
    /// @param [in] buffer    :: Буфер куда ложить байты 
    /// @param [in] length    :: Длина буфера для ограничений
    /// @param [in] value     :: Значение
    /// @param [in] postfix   :: Строка_Постфикс
    /// @return Укзатель на последний вставленный байт
    static uint8_t* FloatToString(uint8_t* buffer, uint16_t length, float* value);

    static uint8_t * int_to_str(uint8_t *buffer, uint16_t length, int value, bool nullable = false, uint8_t order = 9);
    
    static uint8_t * f_to_str(uint8_t *buffer, uint16_t length, float value, uint8_t digital = 2);
  
  private:
    template<typename T>
    static T int_pow(T src_val, uint8_t deg) {
      T result { src_val };
      if(deg == 0)
        return 1;
      if(deg == 1)
        return src_val;
      for(; deg > 1; --deg) {
        result *= src_val;
      }
      return result;
    }
  
  private:
    #define MAX_ASCII_STR 100                   // Максимальная длина преобразуемой строки
    /// TODO: Сделать лучше, а после удалить это говно!
    static char ascii_str[MAX_ASCII_STR+1];     // Буфер для строки в кодировке ASCII [динамическое преобразование]
  public:
    /// @brief Для динамического преобразования кодировки UTF8 -> ASCII (Cyrilic)
    /// @param [in] source :: Исходная строка, надпись или текст в кодировке UTF8  
    /// @return Строку в кодировке ASCII
    static char* UTF8ToCP1251(const char *source);
};


#endif //__STRINGCONVERTERS_H_