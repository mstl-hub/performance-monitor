#ifndef _GFXEXTENDED_H_
#define _GFXEXTENDED_H_

  #include <cstdint>

  /// @brief Параметры дисплея, ширина, высота и буфер
  class DispParams {
    protected:
      uint16_t    disp_height;        /* Высота диплея [писксель]   */
      uint16_t    disp_width;         /* Ширина диплея [писксель]   */
      uint8_t*    frame_buffer;       /* Указатель на буффер кадра  */ 
    public:
      DispParams(uint16_t height, uint16_t width, uint8_t* buffer);// : disp_height(height), disp_width(width), frame_buffer(buffer) { }
      
      void SetParameters(uint16_t heigth, uint16_t width, uint8_t* buffer) {
        disp_height   = heigth;
        disp_width    = width;
        frame_buffer  = buffer;
      }
      void SetParameters(uint8_t *buffer) {
        frame_buffer = buffer;
      }
  };//__class DispParams

#endif // _GFXEXTENDED_H_
