#include "GFX.h"
#include <cstdlib>
#include <cmath>
#include <cstring>

DispParams::DispParams(uint16_t height, uint16_t width, uint8_t* buffer) : disp_height(height), disp_width(width), frame_buffer(buffer) { }

GFX::GFX() : DispParams(0, 0, nullptr) { }

GFX::GFX(uint16_t heigth, uint16_t width, uint8_t* buffer) : DispParams(heigth, width, buffer) { }

void GFX::FillBuffer(uint8_t brightness) {
  FillBuffer(frame_buffer, brightness);
}

void GFX::FillBuffer(uint8_t* frame_buffer, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  uint8_t byte_value = (brightness << 4) | brightness;
  uint32_t buffer_size = disp_height * disp_width / 2;
  while (buffer_size--) {
    *frame_buffer++ = byte_value;
  }
}


void GFX::DrawPixel(uint16_t x, uint16_t y, uint8_t brightness) {
  DrawPixel(frame_buffer , x, y, brightness);
}

void GFX::DrawPixel(uint8_t* frame_buffer, uint16_t x, uint16_t y, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  if (x > (disp_width - 1) || y > (disp_height - 1))
    return;
  if ((y * disp_width + x) % 2 == 1) {
    frame_buffer[((y * disp_width) + x) / 2] = (frame_buffer[((y * disp_width) + x) / 2] & 0xF0) | brightness;
  }
  else {
    frame_buffer[((y * disp_width) + x) / 2] = (frame_buffer[((y * disp_width) + x) / 2] & 0x0F) | (brightness << 4);
  }
}


void GFX::DrawVLine(uint16_t x, uint16_t y0, uint16_t y1, uint8_t brightness) {
  DrawVLine(frame_buffer, x, y0, y1, brightness);
}

void GFX::DrawVLine(uint8_t* frame_buffer, uint16_t x, uint16_t y0, uint16_t y1, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  if (y0 < y1) {
    for (uint16_t i = y0; i <= y1; i++) {
      DrawPixel(frame_buffer, x, i, brightness);
    }
  }
  else {
    for (uint16_t i = y1; i <= y0; i++) {
      DrawPixel(frame_buffer, x, i, brightness);
    }
  }
}


void GFX::DrawHLine(uint16_t y, uint16_t x0, uint16_t x1, uint8_t brightness) {
  DrawHLine(frame_buffer, y, x0, x1, brightness);
}

void GFX::DrawHLine(uint8_t* frame_buffer, uint16_t y, uint16_t x0, uint16_t x1, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  if (x0 < x1) {
    for (uint16_t i = x0; i <= x1; i++) {
      DrawPixel(frame_buffer, i, y, brightness);
    }
  }
  else {
    for (uint16_t i = x1; i <= x0; i++) {
      DrawPixel(frame_buffer, i, y, brightness);
    }
  }
}


void GFX::DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  DrawLine(frame_buffer, x0, y0, x1, y1, brightness);
}

void GFX::DrawLine(uint8_t* frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  //handle horizontal and vertical lines with appropriate functions
  if(frame_buffer == nullptr)
    return;
  if (x0 == x1) {
    DrawVLine(frame_buffer, x0, y0, y1, brightness);
  }
  if (y0 == y1) {
    DrawHLine(frame_buffer, y0, x0, x1, brightness);
  }

  int16_t steep = abs(y1 - y0) > abs(x1 - x0);
  if (steep == 1) {
    uint16_t tmp = y0;
    y0 = x0;
    x0 = tmp;
    tmp = y1;
    y1 = x1;
    x1 = tmp;
  }

  if (x0 > x1) {
    uint16_t tmp = x0;
    x0 = x1;
    x1 = tmp;
    tmp = y0;
    y0 = y1;
    y1 = tmp;
  }

  int16_t dx, dy;
  dx = x1 - x0;
  dy = abs(y1 - y0);

  int16_t err = dx / 2;
  int16_t ystep;

  if (y0 < y1) {
    ystep = 1;
  }
  else {
    ystep = -1;
  }

  for (; x0 <= x1; x0++) {
    if (steep) {
      DrawPixel(frame_buffer, y0, x0, brightness);
    }
    else {
      DrawPixel(frame_buffer, x0, y0, brightness);
    }
    err -= dy;
    if (err < 0) {
      y0 += ystep;
      err += dx;
    }
  }
}


void GFX::DrawAALine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  DrawAALine(frame_buffer, x0, y0, x1, y1, brightness);
}

void GFX::DrawAALine(uint8_t* frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  //handle horizontal and vertical lines with appropriate functions
  if (x0 == x1) {
    DrawVLine(frame_buffer, x0, y0, y1, brightness);
  }
  if (y0 == y1) {
    DrawHLine(frame_buffer, y0, x0, x1, brightness);
  }

  uint8_t steep = abs(y1 - y0) > abs(x1 - x0);

  if (steep) {
    uint16_t tmp = y0;
    y0 = x0;
    x0 = tmp;
    tmp = y1;
    y1 = x1;
    x1 = tmp;
  }
  if (x0 > x1) {
    uint16_t tmp = x0;
    x0 = x1;
    x1 = tmp;
    tmp = y0;
    y0 = y1;
    y1 = tmp;
  }

  float dx = x1 - x0;
  float dy = y1 - y0;
  float gradient = dy / dx;

  // handle first endpoint
  float xend = round(x0);
  float yend = y0 + gradient * (xend - x0);
  float xgap = 1 - ((x0 + 0.5) - floor(x0 + 0.5));
  float xpxl1 = xend; // this will be used in the main loop
  float ypxl1 = floor(yend);
  if (steep) {
    DrawPixel(frame_buffer, ypxl1, xpxl1, (1 - (yend - (floor(yend))) * xgap) * brightness);
    DrawPixel(frame_buffer, ypxl1 + 1, xpxl1, (yend - (floor(yend)) * xgap) * brightness);
  }
  else {
    DrawPixel(frame_buffer, xpxl1, ypxl1, (1 - (yend - (floor(yend))) * xgap) * brightness);
    DrawPixel(frame_buffer, xpxl1, ypxl1 + 1, (yend - (floor(yend)) * xgap) * brightness);
  }

  float intery = yend + gradient; // first y-intersection for the main loop

  // handle second endpoint
  xend = round(x1);
  yend = y1 + gradient * (xend - x1);
  xgap = (x1 + 0.5) - floor(x1 + 0.5);
  float xpxl2 = xend; //this will be used in the main loop
  float ypxl2 = floor(yend);
  if (steep) {
    DrawPixel(frame_buffer, ypxl2, xpxl2, (1 - (yend - floor(yend)) * xgap) * brightness);
    DrawPixel(frame_buffer, ypxl2 + 1, xpxl2, ((yend - floor(yend)) * xgap) * brightness);
  }
  else {
    DrawPixel(frame_buffer, xpxl2, ypxl2, (1 - (yend - floor(yend)) * xgap) * brightness);
    DrawPixel(frame_buffer, xpxl2, ypxl2 + 1, ((yend - floor(yend)) * xgap) * brightness);
  }

  // main loop
  if (steep) {
    for (int x = xpxl1 + 1; x <= xpxl2 - 1; x++) {
      DrawPixel(frame_buffer, floor(intery), x, (1 - (intery - floor(intery))) * brightness);
      DrawPixel(frame_buffer, floor(intery) + 1, x, (intery - floor(intery)) * brightness);
      intery = intery + gradient;
    }
  }
  else {
    for (int x = xpxl1 + 1; x <= xpxl2 - 1; x++) {
      DrawPixel(frame_buffer, x, floor(intery), (1 - (intery - floor(intery))) * brightness);
      DrawPixel(frame_buffer, x, floor(intery) + 1, (intery - floor(intery)) * brightness);
      intery = intery + gradient;
    }
  }
}


void GFX::DrawRect(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  DrawRect(frame_buffer, x0, y0, x1, y1, brightness);
}

void GFX::DrawRect(uint8_t* frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  DrawVLine(frame_buffer, x0, y0, y1, brightness);
  DrawVLine(frame_buffer, x1, y0, y1, brightness);
  DrawHLine(frame_buffer, y0, x0, x1, brightness);
  DrawHLine(frame_buffer, y1, x0, x1, brightness);
}


void GFX::DrawRectFilled(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  DrawRectFilled(frame_buffer, x0, y0, x1, y1, brightness);
}

void GFX::DrawRectFilled(uint8_t* frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  for (uint16_t i = x0; i <= x1; i++) {
    for (uint16_t j = y0; j <= y1; j++) {
      DrawPixel(frame_buffer, i, j, brightness);
    }
  }
}


void GFX::DrawCircle(uint16_t x0, uint16_t y0, uint16_t r, uint8_t brightness) {
  DrawCircle(frame_buffer, x0, y0, r, brightness);
}

void GFX::DrawCircle(uint8_t* frame_buffer, uint16_t x0, uint16_t y0, uint16_t r, uint8_t brightness) {
  if(frame_buffer == nullptr)
    return;
  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;

  DrawPixel(frame_buffer, x0, y0 + r, brightness);
  DrawPixel(frame_buffer, x0, y0 - r, brightness);
  DrawPixel(frame_buffer, x0 + r, y0, brightness);
  DrawPixel(frame_buffer, x0 - r, y0, brightness);

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    DrawPixel(frame_buffer, x0 + x, y0 + y, brightness);
    DrawPixel(frame_buffer, x0 - x, y0 + y, brightness);
    DrawPixel(frame_buffer, x0 + x, y0 - y, brightness);
    DrawPixel(frame_buffer, x0 - x, y0 - y, brightness);
    DrawPixel(frame_buffer, x0 + y, y0 + x, brightness);
    DrawPixel(frame_buffer, x0 - y, y0 + x, brightness);
    DrawPixel(frame_buffer, x0 + y, y0 - x, brightness);
    DrawPixel(frame_buffer, x0 - y, y0 - x, brightness);
  }
}


void GFX::DrawBitmap8bpp(const uint8_t* bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size) {
  DrawBitmap8bpp(frame_buffer, bitmap, x0, y0, x_size, y_size);
}

void GFX::DrawBitmap8bpp(uint8_t* frame_buffer, const uint8_t* bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size) {
  if(frame_buffer == nullptr)
    return;
  uint16_t bitmap_pos = 0;
  for (uint16_t i = y0; i < y0 + y_size; i++) {
    for (uint16_t j = x0; j < x0 + x_size; j++) {
      DrawPixel(frame_buffer, j, i, bitmap[bitmap_pos] >> 4);
      bitmap_pos++;
    }
  }
}


void GFX::DrawBitmap4bpp(const uint8_t* bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size) {
  DrawBitmap4bpp(frame_buffer, bitmap, x0, y0, x_size, y_size);
}

void GFX::DrawBitmap4bpp(uint8_t* frame_buffer, const uint8_t* bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size) {
  if(frame_buffer == nullptr)
    return;
  uint16_t bitmap_pos = 0;       //byte index in bitmap array
  uint16_t processed_pixels = 0;
  uint8_t pixel_parity = 0;      //if pixel is even = 0; odd = 1
  for (uint16_t i = y0; i < y0 + y_size; i++) {
    for (uint16_t j = x0; j < x0 + x_size; j++) {
      pixel_parity = processed_pixels % 2;

      if (pixel_parity == 0) {
        DrawPixel(frame_buffer, j, i, bitmap[bitmap_pos] >> 4);
        processed_pixels++;
      }
      else {
        DrawPixel(frame_buffer, j, i, bitmap[bitmap_pos]);
        processed_pixels++;
        bitmap_pos++;
      }
    }
  }
}

// void GFX::Select_font(const GFXfont* new_gfx_font) {
//   font = new_gfx_font;
// }

// void GFX::Draw_char(uint8_t* frame_buffer, uint8_t c, uint16_t x, uint16_t y, uint8_t brightness) {
//   if (font == NULL)
//     return;

//   c -= (uint8_t)font->first;          //convert input char to corresponding byte from font array
//   GFXglyph* glyph = font->glyph + c;  //get pointer of glyph corresponding to char
//   uint8_t* bitmap = font->bitmap;     //get pointer of char bitmap

//   uint16_t bo = glyph->bitmapOffset;
//   uint8_t width = glyph->width;
//   uint8_t height = glyph->height;

//   int8_t x_offset = glyph->xOffset;
//   int8_t y_offset = glyph->yOffset;

//   //decide for background brightness or font brightness
//   uint8_t bit = 0;
//   uint8_t bits = 0;
//   uint8_t y_pos = 0;
//   uint8_t x_pos = 0;

//   for (y_pos = 0; y_pos < height; y_pos++) {
//     for (x_pos = 0; x_pos < width; x_pos++) {
//       if (!(bit++ & 7)) {
//         bits = (*(const unsigned char*)(&bitmap[bo++]));
//       }
//       if (bits & 0x80) {
//         DrawPixel(frame_buffer, x + x_offset + x_pos, y + y_offset + y_pos, brightness);
//       }
//       else {

//       }
//       bits <<= 1;
//     }
//   }
// }

// void GFX::Draw_text(uint8_t* frame_buffer, const char* text, uint16_t x, uint16_t y, uint8_t brightness) {
//   while (*text) {
//     Draw_char(frame_buffer, *text, x, y, brightness);
//     x = x + font->glyph[*text - 32].xAdvance;
//     text++;
//   }
// }


// char GFX::target[maxString + 1] = "";

// char* GFX::UTF8ToCP1251(char *source) {
//   int i,j,k;
//   unsigned char n;
//   char m[2] = { '0', '\0' };
//   strcpy(target, ""); 
//   k = strlen(source); 
//   i = j = 0;
//   while (i < k) {
//     n = source[i]; i++;
//     if (n >= 127) {
//       switch (n) {
//         case 208: {
//           n = source[i]; i++;
//           if (n == 129) { n = 192; break; } // перекодируем букву Ё
//           break;
//         }
//         case 209: {
//           n = source[i]; i++;
//           if (n == 145) { n = 193; break; } // перекодируем букву ё
//           break;
//         }
//       }
//     }
//     m[0] = n; strcat(target, m);
//     j++; if (j >= maxString) break;
//   }
//   return target;
// }

/*
    Сделать интерфейс ! ! ! ! ! ! ! ! 
*/
// void GFX::UpdateOLED(uint8_t* frame_buffer, uint16_t start_x, uint16_t start_y) {
//   display->SetWindow(0, 63, 0, 127);//0-63-0-127
//   display->SendBuffer(frame_buffer + (start_y * OLED_WIDTH / 2) + start_x, 8192);
// }