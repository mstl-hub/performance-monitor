#ifndef _GFX_H_
#define _GFX_H_

#include <cstdint>
#include "GFXExtended.h"

/// @brief Графические примитивы библиотеки Adafruit + где-то своя писанина
class GFX : public DispParams {
  public:
    GFX();
    GFX(uint16_t heigth, uint16_t width, uint8_t* buffer);

    void Init();

    void FillBuffer(uint8_t brightness);                            // <<< Это обертка
    void FillBuffer(uint8_t *frame_buffer, uint8_t brightness);
    void FillBuffer(uint8_t *frame_buffer, uint8_t *brightness);    // <<< Можно сделать так

    void DrawPixel(uint16_t x, uint16_t y, uint8_t brightness);
    void DrawPixel(uint8_t *frame_buffer, uint16_t x, uint16_t y, uint8_t brightness);

    void DrawVLine(uint16_t x, uint16_t y0, uint16_t y1, uint8_t brightness);
    void DrawVLine(uint8_t *frame_buffer, uint16_t x, uint16_t y0, uint16_t y1, uint8_t brightness);
    
    void DrawHLine(uint16_t y, uint16_t x0, uint16_t x1, uint8_t brightness);
    void DrawHLine(uint8_t *frame_buffer, uint16_t y, uint16_t x0, uint16_t x1, uint8_t brightness);
    
    void DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    void DrawLine(uint8_t *frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    
    void DrawAALine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    void DrawAALine(uint8_t *frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    
    void DrawRect(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    void DrawRect(uint8_t *frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    
    void DrawRectFilled(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    void DrawRectFilled(uint8_t *frame_buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t brightness);
    
    void DrawCircle(uint16_t x0, uint16_t y0, uint16_t r, uint8_t brightness);
    void DrawCircle(uint8_t *frame_buffer, uint16_t x0, uint16_t y0, uint16_t r, uint8_t brightness);
    
    void DrawBitmap8bpp(const uint8_t *bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size);
    void DrawBitmap8bpp(uint8_t *frame_buffer, const uint8_t *bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size);
    
    void DrawBitmap4bpp(const uint8_t *bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size);
    void DrawBitmap4bpp(uint8_t *frame_buffer, const uint8_t *bitmap, uint16_t x0, uint16_t y0, uint16_t x_size, uint16_t y_size);
};

#endif // _GFX_H_