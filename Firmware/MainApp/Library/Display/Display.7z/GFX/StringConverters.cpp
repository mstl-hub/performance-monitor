#include "StringConverters.h"

#include <cstring>
#include <cmath>

uint16_t StringConverter::IntToString(uint8_t* placement, uint16_t length, int32_t value) {
  auto convert_small_value_class = [](uint8_t** ptr_str, uint16_t* value, uint16_t v_class, bool** f_null){
    uint16_t c_value = (*value);
    if((*value) >= v_class) {
      (**f_null) = true;
      c_value = (*value) / v_class;
      (**ptr_str) = c_value + 0x30;
      (*value) -= c_value * v_class;
      (*ptr_str)++;
    }
    else if(true == (**f_null)) {
      (**ptr_str) = 0x30;
      (*ptr_str)++;
    }
  };
  auto u_convert = [&](uint8_t** ptr_str, uint16_t value, bool** f_null){
    uint16_t c_value = value;
    convert_small_value_class(ptr_str, &c_value, 100, f_null);
    convert_small_value_class(ptr_str, &c_value, 10,  f_null);
    convert_small_value_class(ptr_str, &c_value, 1,   f_null);
  };
  auto convert_big_value_class = [&](uint8_t** p_str, int32_t* value, int32_t value_class, bool* f_null){
    if((*value) >= value_class) {
      uint32_t div = (*value) / value_class;
      u_convert(p_str, (uint16_t)div, &f_null);
      div *= value_class;
      (*value) -= div;
    } 
    else if(true == (*f_null)) {
      for(uint8_t k = 0; k < 3; ++k, (*p_str)++) {
        (**p_str) = 0x30;
      }
    }
  };

  memset(placement, 0, length);
  uint8_t* start_buff {placement}; 
  /// TODO: Переписать и вставить защиту
  uint16_t share_length { 0 };
  uint32_t reserve_length { 0 };
  /* Проверка длины буфера */
  if(value == 0)
    reserve_length = 1;
  else {
    uint32_t tempory = abs(value);
    while (tempory > 0) {
      tempory /= 10;
      ++reserve_length;
    }
  }
  if(length < reserve_length)
    return 0;

  if(value < 0) {
    share_length++;
    (*placement) = '-';
    value = abs(value);
    placement++;
  }

  if(value > 0){
    /*  TODO: Вставить проверку */ 
    bool      f_null       { false };      
    convert_big_value_class(&placement, &value, 1000000000,  &f_null);
    convert_big_value_class(&placement, &value, 1000000,     &f_null);
    convert_big_value_class(&placement, &value, 1000,        &f_null);
    convert_big_value_class(&placement, &value, 1,           &f_null);
  }
  else {
    (*placement) = 0x30; 
    placement++;
  }
  // memcpy(placement, "\r\n", 3);
  // placement+=1;//3
  // (*placement++) = ' ';
  share_length = placement - start_buff;
  return share_length;
}

uint16_t StringConverter::U32ToString(uint8_t* placement, uint16_t length, uint32_t value) {
  auto convert_small_value_class = [](uint8_t** ptr_str, uint16_t* value, uint16_t v_class, bool** f_null){
    uint16_t c_value = (*value);
    if((*value) >= v_class) {
      (**f_null) = true;
      c_value = (*value) / v_class;
      (**ptr_str) = c_value + 0x30;
      (*value) -= c_value * v_class;
      (*ptr_str)++;
    }
    else if(true == (**f_null)) {
      (**ptr_str) = 0x30;
      (*ptr_str)++;
    }
  };
  auto u_convert = [&](uint8_t** ptr_str, uint16_t value, bool** f_null){
    uint16_t c_value = value;
    convert_small_value_class(ptr_str, &c_value, 100, f_null);
    convert_small_value_class(ptr_str, &c_value, 10,  f_null);
    convert_small_value_class(ptr_str, &c_value, 1,   f_null);
  };
  auto convert_big_value_class = [&](uint8_t** p_str, uint32_t* value, uint32_t value_class, bool* f_null){
    if((*value) >= value_class) {
      uint32_t div = (*value) / value_class;
      u_convert(p_str, (uint16_t)div, &f_null);
      div *= value_class;
      (*value) -= div;
    } 
    else if(true == (*f_null)) {
      for(uint8_t k = 0; k < 3; ++k, (*p_str)++) {
        (**p_str) = 0x30;
      }
    }
  };

  memset(placement, 0, length);
  uint8_t* start_buff {placement}; 
  /// TODO: Переписать и вставить защиту
  uint16_t share_length { 0 };
  uint32_t reserve_length { 0 };
  /* Проверка длины буфера */
  if(value == 0)
    reserve_length = 1;
  else {
    uint32_t tempory = value;
    while (tempory > 0) {
      tempory /= 10;
      ++reserve_length;
    }
  }
  if(length < reserve_length)
    return 0;

  if(value > 0){
    /*  TODO: Вставить проверку */ 
    bool      f_null       { false };      
    convert_big_value_class(&placement, &value, 1000000000,  &f_null);
    convert_big_value_class(&placement, &value, 1000000,     &f_null);
    convert_big_value_class(&placement, &value, 1000,        &f_null);
    convert_big_value_class(&placement, &value, 1,           &f_null);
  }
  else {
    (*placement) = 0x30; 
    placement++;
  }
  // memcpy(placement, "\r\n", 3);
  // placement+=1;//3
  // (*placement++) = ' ';
  share_length = placement - start_buff;
  return share_length;
}

uint8_t* StringConverter::FloatToString(uint8_t* buffer, uint16_t length, float* value, const char* postfix) {  
  uint16_t temp_length { 0 };
  int integer     = abs((int)(*value));
  int fractional  = (int)(abs((*value)*100));
  fractional = fractional - integer * 100;

  if((*value) < 0.0f) {
    (*buffer) = '-';
    temp_length++;
    // (*value) = (*value) * -1.0f;
    // buffer++;
    // integer *= -1;
  }
    
  temp_length += IntToString((uint8_t*)&buffer[temp_length], length, integer);
  buffer[temp_length++] = (uint8_t)',';
  temp_length += IntToString((uint8_t*)&buffer[temp_length], length - temp_length, fractional);

  uint16_t length_postfix = strlen(postfix);
  if((temp_length + length_postfix) <= length)
    memcpy(&buffer[temp_length], postfix, length_postfix);
  temp_length += length_postfix;
  // buffer[temp_length] = ' ';

  return &buffer[temp_length];
}

uint8_t* StringConverter::FloatToString(uint8_t* buffer, uint16_t length, float* value) {  
  uint16_t temp_length { 0 };
  int integer     = abs((int)(*value));
  int fractional  = (int)(abs((*value)*100));
  fractional = fractional - integer * 100;
  memset(buffer, 0, length);

  if((*value) < 0.0f) {
    (*buffer) = '-';
    temp_length++;
    // (*value) = (*value) * -1.0f;
    // buffer++;
    // integer *= -1;
  }
    
  temp_length += IntToString((uint8_t*)&buffer[temp_length], length, integer);
  buffer[temp_length++] = (uint8_t)',';
  temp_length += IntToString((uint8_t*)&buffer[temp_length], length - temp_length, fractional);
  // uint16_t length_postfix = strlen(postfix);
  // if((temp_length + length_postfix) <= length)
  //   memcpy(&buffer[temp_length], postfix, length_postfix);
  // temp_length += length_postfix;
  // buffer[temp_length] = ' ';

  return &buffer[temp_length];
}

uint8_t * StringConverter::int_to_str(uint8_t *buffer, uint16_t length, int value, bool nullable, uint8_t order) 
{ 
  // memset(buffer, 0, length);

  if(value < 0) {
    *buffer++ = '-';
    value *= -1;
  }
  
  for(int8_t i = order; i >= 0; --i) { 
    // _4_294_967_295_
    // printf("MOD: %d \n", ipow( 10, i + 1 ));
    // printf("DIV: %d \n", ipow( 10, i )    );
    uint32_t ral = ( value % int_pow<uint64_t>( 10, i + 1 ) ) / int_pow<uint64_t>( 10, i );
    if(ral || nullable) {
      // printf(" %d \n", ral);
      nullable = true;
      *buffer++ = 0x30 + (ral % 0xA);
    }
  }
  return buffer;
}

uint8_t * StringConverter::f_to_str(uint8_t *buffer, uint16_t length, float value, uint8_t digital) {
  if(value < 0.0f) {
    *buffer++ = '-';
    value *= -1.0f;
  }

  int32_t integer       = (int32_t)value;
  int32_t fractional    = (int32_t)(value * 100) - (integer * 100);
  digital--;

  uint8_t order { 0 };      
  for(uint8_t i = 0; i < 9; ++i) {
    if( ( integer % int_pow<uint64_t>( 10, i + 1 ) ) / int_pow<uint64_t>( 10, i ) ) 
    {
      order = i;
    }
  }

  // printf("Order: %d \n", order);

  uint8_t * out_value = int_to_str(
    buffer, 
    length, 
    integer, 
    integer == 0 ? true : false, 
    integer == 0 ? 1 : order  
  );
  *out_value++ = ',';
  int_to_str(out_value, length - strlen((char*)buffer), fractional, true, digital);

  return nullptr;
}

char StringConverter::ascii_str[MAX_ASCII_STR+1] = "";

char* StringConverter::UTF8ToCP1251(const char *source) {
  int i,j,k;
  uint8_t   u8temp;
  uint16_t  u16temp;
  unsigned char n;
  char m[2] = { '0', '\0' };
  strcpy(ascii_str, ""); /* можно заменить на memset(ascii_str, 0, sizeof(ascii_str)) */
  k = strlen(source); 
  i = j = 0;
  while (i < k) {
    u8temp  = source[i];
    if( u8temp != 0xD0 && u8temp != 0xD1 ) {
      // UTF8_unicode, могут быть символы по два байта и по одному из стандартной таблице
      n = static_cast<uint8_t>(u8temp);
      i++;
    }
    else {
      u16temp = *((uint16_t*)(&source[i]));
      u16temp = ((u16temp >> 8) & 0xFF) | ((u16temp & 0xFF) << 8);
      // В кодировке unicode есть разрыв в русском алфавите, поэтому
      if(u16temp >= 0xD180)
        u16temp -= 0xC0; //C1
      // Offset for glyph 0xD090. Delete unicode offset. Or Convert to ASCII
      if(u16temp >= 0xD090)
        u16temp -= 0xCFD0;
      i += 2;
      n = static_cast<uint8_t>(u16temp);
    }
    m[0] = n; strcat(ascii_str, m);
    j++; if (j >= MAX_ASCII_STR) break;
  }
  /*! TODO: Что бы не париться, иожно сделать так, если строка изначально в кодировке cp1251, то возвращаем source  */
  return ascii_str;
}