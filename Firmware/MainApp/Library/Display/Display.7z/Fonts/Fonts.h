#ifndef _FREESANS12_H_
#define _FREESANS12_H_

#include <cstdint>
#include "GFXExtended.h"
#include "FontGFX.h"
#include "FontGS.h"
#include "FontV.h"

/// @brief Общий интерфейс для Шрифтов
class IFont : public DispParams {
  public:
    IFont();
    /// @brief Конструктор
    /// @param [in] heigth        ::  Высота дисплея
    /// @param [in] width         ::  Ширина дисплея
    /// @param [in] buffer        ::  Буфер\память дисплея
    IFont(uint16_t heigth, uint16_t width, uint8_t* buffer);
  protected:
    /// @brief Вывести один пиксель
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    void DrawPixel(uint16_t x, uint16_t y, uint8_t brightness);
  public:
    /// @brief Выбрать шрифт 
    /// @param [in] _tFont        :: Номер шрифта по перечислению VFonts
    /// @return Результат 
    virtual bool Select(uint8_t _tFont) = 0;
    /// @brief Вывести текст
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint8_t brightness) = 0;
    /// @brief Вывести текст c подстветкой одного символа
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    /// @param [in] index_bsymb   :: Индекс подствечиваемого символа 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint8_t brightness, uint8_t index_bsymb) = 0;
    /// @brief Вывести текст c ограниченной длинной
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] len_limit     :: Ограничение длины строки 
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint16_t len_limit, uint8_t brightness) = 0;
    /// @brief Вывести текст c ограниченной длинной и подсветкой одного символа
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] len_limit     :: Ограничение длины строки 
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов
    /// @param [in] index_brigth  :: Индекс элемента, которого нужно подстветить 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint16_t len_limit, uint8_t brightness, uint8_t index_index_brigth) = 0;
    /// @brief Вывести текст
    /// @param [in] frame_buffer  :: Буфер дисплея 
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    virtual void DrawText(uint8_t *frame_buffer, const char* text, uint16_t x, uint16_t y, uint8_t brightness) = 0;
    /// @brief Вывести один символ
    /// @param [in] chr           :: Символ
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка или инверсия цветов 
    virtual void DrawChar(uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness) = 0;
    /// @brief Вывести один символ
    /// @param [in] chr           :: Символ
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка или инверсия цветов 
    virtual void DrawChar(uint8_t* frame_buffer, uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness) = 0;
    /// @brief Расчитать длину\ширину символа в пикселях
    /// @param [in] str           :: строка
    /// @return Х [пиксель]
    virtual uint16_t GetWidth (uint8_t  symbol) = 0;
    /// @brief Расчитать длину\ширину строки в пикселях
    /// @param [in] str           :: строка
    /// @return Х [пиксель]
    virtual uint16_t GetWidth (const char* str) = 0;
    /// @brief Расчитать длину\ширину строки с числами в пикселях
    /// @param [in] num           :: число
    /// @return Х [пиксель]
    virtual uint16_t GetWidth (int32_t num) = 0;
    /// @brief Получить высоту символа
    /// @return высота
    virtual uint8_t GetHigh() = 0;
};

/// @brief Шрифт из зАДа
class FontGS : public IFont {
  public:
    enum /* class */ GSFonts : uint8_t {
      GSF_TimesNewRoman_10,
      GSF_Calibri_10,
      GSF_Tahoma_10,
      GSF_FontSize,
    };

  private:
    static const tGSFont *fonts[GSF_FontSize];
    static GSFonts nFont; // Выбранные шрифт

  public:
    FontGS();
    FontGS(uint16_t heigth, uint16_t width, uint8_t* buffer);
    virtual bool Select(uint8_t _tFont) override;
    virtual void DrawText(uint8_t *frame_buffer, const char* text, uint16_t x, uint16_t y, uint8_t brightness) override;
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint16_t len_limit, uint8_t brightness) override;
    virtual void DrawChar(uint8_t *frame_buffer, uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness) override;
};

/// @brief VIFont реализация саморисованного шрифта
class FontV : public IFont {
  public:
    enum /* class */ VFonts : uint8_t {
      VF_Font_10,
      VF_Font_12,
      VF_FontSize,
    };

  private:
    static const tVFont *fonts[VF_FontSize];
    static VFonts nFont;                        // Выбранные шрифт

  public:
    FontV();
    /// @brief Конструктор
    /// @param [in] heigth        ::  Высота дисплея
    /// @param [in] width         ::  Ширина дисплея
    /// @param [in] buffer        ::  Буфер\память дисплея
    FontV(uint16_t heigth, uint16_t width, uint8_t* buffer);
    /// @brief Выбрать шрифт 
    /// @param [in] _tFont        :: Номер шрифта по перечислению VFonts
    /// @return Результат 
    virtual bool Select(uint8_t _tFont) override;
    /// @brief Вывести текст
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint8_t brightness) override;
    /// @brief Вывести текст c подстветкой одного символа
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    /// @param [in] index_bsymb   :: Индекс подствечиваемого символа 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint8_t brightness, uint8_t index_bsymb) override;
    /// @brief Вывести текст c ограниченной длинной
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] len_limit     :: Ограничение длины строки 
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint16_t len_limit, uint8_t brightness) override;
    /// @brief Вывести текст c ограниченной длинной и подсветкой одного символа
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] len_limit     :: Ограничение длины строки 
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов
    /// @param [in] index_brigth  :: Индекс элемента, которого нужно подстветить 
    virtual void DrawText(const char* text, uint16_t x, uint16_t y, uint16_t len_limit, uint8_t brightness, uint8_t index_index_brigth) override;
    /// @brief Вывести текст
    /// @param [in] frame_buffer  :: Буфер дисплея 
    /// @param [in] text          :: Текст ASCII 
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
    virtual void DrawText(uint8_t *frame_buffer, const char* text, uint16_t x, uint16_t y, uint8_t brightness) override;
    /// @brief Вывести один символ
    /// @param [in] chr           :: Символ
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка или инверсия цветов 
    virtual void DrawChar(uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness);
    /// @brief Вывести один символ
    /// @param [in] chr           :: Символ
    /// @param [in] x             :: Позиция по оси x_абцисс
    /// @param [in] y             :: Позиция по оси y_ординат
    /// @param [in] brightness    :: Подсветка или инверсия цветов 
    virtual void DrawChar(uint8_t* frame_buffer, uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness) override;
    /// @brief Расчитать длину\ширину символа в пикселях [Только для ASCII]
    /// @param [in] symbol        :: символ
    /// @return Х [пиксель]
    virtual uint16_t GetWidth (uint8_t  symbol) override;
    /// @brief Расчитать длину\ширину строки в пикселях [Только для ASCII]
    /// @param [in] _string       :: строка
    /// @return Х [пиксель]
    virtual uint16_t GetWidth (const char* _string) override;
    /// @brief Расчитать длину\ширину строки с числами в пикселях [Только для ASCII]
    /// @param [in] num           :: число
    /// @return Х [пиксель]
    virtual uint16_t GetWidth (int32_t num) override;

    /// @brief Получить высоту символа.
    /// @return высота
    virtual uint8_t GetHigh() override;
};


#endif // _FREESANS12_H_