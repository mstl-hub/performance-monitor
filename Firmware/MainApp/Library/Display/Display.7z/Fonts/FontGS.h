#ifndef _FONTGS_H_
#define _FONTGS_H_

#include <cstdint>

/*
  - шрифт формируется из диапазона база + английские буквы UTF8 э [32 : 126] и русских ASCII э [192 : 255]

  На будущее UTF16: Русские 1040 - 1103; ° °± Ωδ∞φε±°Θαß
*/

/// @brief Описание глифа GS (GrayScale)
typedef struct GSFGlyph {
	uint16_t  offset;           // Смещение по таблице BitMap
  uint16_t  size;
	uint8_t   width;            // Ширина
	uint8_t   height;           // Высота
} tGSFGlyph;

/// @brief Описание шрифта GS (GrayScale)
typedef struct GSFont {
	const uint8_t*    data;     // Указатель на BitMap всего шрифта
	const tGSFGlyph*  Glyphs;   // Указатель на таблицу описания глифов
	uint16_t          size;     // Размер массива BitMap
	uint16_t          first;    // Код первого символа. Dec_32, ASCII extents (first char)
	uint16_t          last;     // Код последнего символа. Dec_255, ASCII extents (last char)
} tGSFont;


/// @brief Считает размер по массиву. DEPRECATED
/// @param [in] w     :: Ширина [пиксель]
/// @param [in] h     :: Высота [пиксель]
/// @return Литерал
constexpr uint16_t GetSize(uint8_t w, uint8_t h) {
	uint16_t temp = w * h * 4 / 8;
	return temp;
};

/// @brief 
/// @param prev 
/// @param curr 
/// @return 
constexpr uint16_t GetSumm(uint16_t prev, uint16_t curr) {
  return prev + curr;
}

constexpr int GetASCII_Index(uint16_t symb) {
  // Offset for glyph 0xD180. Delete empty space.
  if(symb >= 0xD180)
    symb -= 0xC0; //C1
  // Offset for glyph 0xD090. Delete unicode offset. Or Convert to ASCII
  if(symb >= 0xD090)
    symb -= 0xCFD0;
  // Delete ASCII empty space.
  if(symb >= 192)
    symb -= 65;
  // Delete first empty space
  symb -= 32;
  return symb;
}

constexpr int GetASCII_PrevIndex(uint16_t symb) {
  if(!GetASCII_Index(symb))
    return 0;
  return GetASCII_Index(symb) - 1;
}

extern const tGSFont GSF_TimeNR_10;
extern const tGSFont GSF_FCalibri_10;
extern const tGSFont GSF_FTahoma_10;

/*
--------------------------------------------------------------------------------
----------------------- Пример Обработчиков ------------------------------------
--------------------------------------------------------------------------------
*/
/*
  void DrawChar(uint8_t* frame, uint16_t x, uint16_t y, const GSFGlyph* glyph) {
    // преобразовать x-y в бит
    for (uint16_t _x = x; _x < glyph->heigth; ++_x) {
      for (uint16_t _y = y; _y < glyph->width; ++y) {
        uint8_t bit_pix = _y * glyph->width + x;
        uint16_t n_byte = bit_pix / 2;
        uint8_t bright = 0;
        if (bit_pix % 2)
          bright = TimeNewRoman_10_data[glyph->offset + n_byte] & 0xFU;
        else
          bright = ( TimeNewRoman_10_data[glyph->offset + n_byte] >> 4 ) & 0xFU;
        
        // CallDrawPixel(frame, x, y, bright);
      }
    }
  }

  void DrawText(GSFont* font, uint8_t* frame_buffer, const char* text, uint16_t x, uint16_t y) {
    // Устанавилваем указатель на bitMap глиф
    const uint8_t* data = &font->data[font->Glyphs->offset];
    while (*text) {
      uint16_t index = (*text) - 32;
      if (index > 126)
        index -= 65;
      DrawChar(frame_buffer, x, y, &font->Glyphs[index]);
      text++;
    }
  }
*/

#endif // _FONTGS_H_