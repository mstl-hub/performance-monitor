#ifndef _FONTV_H_
#define _FONTV_H_

#include <cstdint>

typedef struct VIFONT {
  uint8_t         HeadSize;       // Размер заголовка
  uint8_t         Width;          // Ширина символа
  uint8_t         Heigth;         // Высота символа
  uint8_t         GlyphSize;      // Размер одного символа: ширина, пиксели
  uint8_t         Offs_Symb;      // Смещение до первого символа (пропуск 0 - 31)
  uint8_t         Offs_EN_RUS;    // Смещение АНГ - РУС символами (пропуск 128 - 191)
  const uint8_t   *data;          // Указаетль на первый глиф
  uint16_t        TotalSize;      // Общий размер
} tVFont;


extern const tVFont FontV10;
extern const tVFont FontV12;


#endif // _FONTV_H_