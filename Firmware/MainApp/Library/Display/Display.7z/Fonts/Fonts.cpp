#include "Fonts.h"
#include <cstring>

extern const tGFXfont FreeSansOblique9pt7b;
extern const tGFXfont FreeSans6pt8b;
extern const tGFXfont FreeSans7pt8b;
extern const tGFXfont FreeSans8pt8b;
extern const tGFXfont FreeSans9pt8b;
extern const tGFXfont FreeSans10pt8b;
extern const tGFXfont FreeSans12pt8b;
extern const tGFXfont FreeSans14pt8b;
extern const tGFXfont FreeSans16pt8b;
extern const tGFXfont FreeSans18pt8b;
extern const tGFXfont Bahamas10pt8b;
extern const tGFXfont FreeSerif10pt8b;
extern const tGFXfont TimesNRCyr10pt8b;

extern const tGSFont GSF_TimeNR_10;

#pragma region    [Interface for fonts]

  IFont::IFont() : DispParams(0, 0, nullptr) {};
  IFont::IFont(uint16_t heigth, uint16_t width, uint8_t* buffer) : DispParams(heigth, width, buffer) {};
 
  void IFont::DrawPixel(uint16_t x, uint16_t y, uint8_t brightness) {
    if(frame_buffer == nullptr) return;

    if (x > (disp_width - 1) || y > (disp_height - 1))
      return;
    if ((y * disp_width + x) % 2 == 1) {
      frame_buffer[((y * disp_width) + x) / 2] = (frame_buffer[((y * disp_width) + x) / 2] & 0xF0) | brightness;
    }
    else {
      frame_buffer[((y * disp_width) + x) / 2] = (frame_buffer[((y * disp_width) + x) / 2] & 0x0F) | (brightness << 4);
    }
  }

#pragma endregion [Interface for fonts]

#pragma region    [Font GS] /* with gray scale pixel */

FontGS::GSFonts FontGS::nFont;

const tGSFont *FontGS::fonts[GSF_FontSize] = {
  &GSF_TimeNR_10,
  &GSF_FCalibri_10,
  &GSF_FTahoma_10,
};

FontGS::FontGS() : IFont(0, 0, nullptr) {}
FontGS::FontGS(uint16_t heigth, uint16_t width, uint8_t* buffer) : IFont(heigth, width, buffer) {}

bool FontGS::Select(uint8_t _tFont) {
  if(_tFont >= FontGS::GSF_FontSize) {
    FontGS::nFont = static_cast<FontGS::GSFonts>(0);
    return false;
  }
  nFont = static_cast<FontGS::GSFonts>(_tFont);
  return true;
};

void FontGS::DrawText(uint8_t *frame_buffer, const char* text, uint16_t x, uint16_t y, uint8_t brightness) {
  // fonts[nFont]->data[fonts[nFont]->Glyphs->offset];
  // Устанавилваем указатель на bitMap глиф
  while (*text) {
    DrawChar(frame_buffer, *text, x, y, 0);
    uint16_t index = (*text) - 32;
    if (index != 0)
      x += 7;
    else
      x += 2;
    text++;
  }
};

void FontGS::DrawChar(uint8_t *frame_buffer, uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness) {
  const tGSFont *font_descript = FontGS::fonts[nFont];
  const uint8_t *data = font_descript->data;  // &font->data[font->Glyphs->offset];
  const tGSFGlyph *glyph_desript;
  uint16_t index = chr - 32;
  if (index > 126) index -= 65;
  glyph_desript = &font_descript->Glyphs[index];

  // преобразовать x-y в бит
  for (uint16_t _y = 0; _y < glyph_desript->height; ++_y) {
    for (uint16_t _x = 0; _x < glyph_desript->width; ++_x) {
      uint8_t bit_pix = _y * glyph_desript->width + _x;
      uint16_t n_byte = bit_pix / 2; // * 4 perBit / 8 byte
      uint8_t bright = 0;
      if (bit_pix % 2)
        bright = data[glyph_desript->offset + n_byte] & 0xFU;
      else
        bright = ( data[glyph_desript->offset + n_byte] >> 4 ) & 0xFU;

      DrawPixel(x + _x, y + _y, bright);
    }
  }
};

#pragma endregion [Font GS]

#pragma region    [ViFont]

  const tVFont *FontV::fonts[VF_FontSize] = {
    &FontV10,
    &FontV12
  };

  FontV::VFonts FontV::nFont; // Выбранные шрифт
  
  FontV::FontV() : IFont(0, 0, nullptr) {}
  FontV::FontV(uint16_t heigth, uint16_t width, uint8_t* buffer) : IFont(heigth, width, buffer) {}

  bool FontV::Select(uint8_t _tFont) {
    if(_tFont >= VFonts::VF_FontSize) {
      FontV::nFont = static_cast<FontV::VFonts>(0);
      return false;
    }
    nFont = static_cast<FontV::VFonts>(_tFont);
    return true;
  }

  void FontV::DrawText(const char* text, uint16_t x, uint16_t y, uint8_t brightness) {
    DrawText(frame_buffer, text, x, y, brightness);
  }

  /// @brief Вывести текст c ограниченной длинной
  /// @param [in] text          :: Текст ASCII 
  /// @param [in] x             :: Позиция по оси x_абцисс
  /// @param [in] y             :: Позиция по оси y_ординат
  /// @param [in] len_limit     :: Ограничение длины строки [в символах] 
  /// @param [in] brightness    :: Подсветка текста или инверсия цветов 
  void FontV::DrawText(const char* text, uint16_t x, uint16_t y, uint16_t len_limit, uint8_t brightness) {
    if(frame_buffer == nullptr)
      return;
    if( (*text == 0) || (sizeof(text) == 0) ) 
      return;

    uint8_t str_length = len_limit;  // str == 0 ? 0 : 1 
    uint8_t pos_x = x;

    // if (pos_x == RIGHT) pos_x = OLED_WIDTH - OLED_GetWidthStr(str) - 1;
    // if (pos_x == CENTER) pos_x = ( OLED_WIDTH - OLED_GetWidthStr(str) - 1 ) / 2;
    // if (y == CENTER) y = ( OLED_HEIGHT - Font.height ) / 2;

    //uint8_t glif;
    for (uint8_t cnt = 0; cnt < str_length; cnt++, *text++) {
      DrawChar(frame_buffer, *text, pos_x, y, brightness);
      uint8_t position = *text;
      // С учетом кодировки cp1251::
      if (position > 128) 
        position -= fonts[nFont]->Offs_EN_RUS;
      position -= fonts[nFont]->Offs_Symb;
      pos_x += fonts[nFont]->data[fonts[nFont]->GlyphSize * position /* + Font.headerSize */];

    }
  }

  void FontV::DrawText(const char* text, uint16_t x, uint16_t y, uint16_t len_limit, uint8_t brightness, uint8_t index_index_brigth) {
    if(frame_buffer == nullptr)
      return;
    if( (*text == 0) || (sizeof(text) == 0) ) 
      return;

    uint8_t str_length = len_limit;  // str == 0 ? 0 : 1 
    uint8_t pos_x = x;

    // if (pos_x == RIGHT) pos_x = OLED_WIDTH - OLED_GetWidthStr(str) - 1;
    // if (pos_x == CENTER) pos_x = ( OLED_WIDTH - OLED_GetWidthStr(str) - 1 ) / 2;
    // if (y == CENTER) y = ( OLED_HEIGHT - Font.height ) / 2;

    //uint8_t glif;
    for (uint8_t cnt = 0; cnt < str_length; cnt++, *text++) {
      if(cnt == index_index_brigth) DrawChar(frame_buffer, *text, pos_x, y, !brightness);
      else                          DrawChar(frame_buffer, *text, pos_x, y, brightness);
      uint8_t position = *text;
      // С учетом кодировки cp1251::
      if (position > 128) 
        position -= fonts[nFont]->Offs_EN_RUS;
      position -= fonts[nFont]->Offs_Symb;
      pos_x += fonts[nFont]->data[fonts[nFont]->GlyphSize * position /* + Font.headerSize */];

    }
  }

  void FontV::DrawText(uint8_t *frame_buffer, const char* text, uint16_t x, uint16_t y, uint8_t brightness) {
    if(frame_buffer == nullptr)
      return;
    if( (*text == 0) || (sizeof(text) == 0) ) 
      return;

    uint8_t str_length = strlen(text);  // str == 0 ? 0 : 1 
    uint8_t pos_x = x;

    // if (pos_x == RIGHT) pos_x = OLED_WIDTH - OLED_GetWidthStr(str) - 1;
    // if (pos_x == CENTER) pos_x = ( OLED_WIDTH - OLED_GetWidthStr(str) - 1 ) / 2;
    // if (y == CENTER) y = ( OLED_HEIGHT - Font.height ) / 2;

    //uint8_t glif;
    for (uint8_t cnt = 0; cnt < str_length; cnt++, *text++) {
      DrawChar(frame_buffer, *text, pos_x, y, brightness);
      uint8_t position = *text;
      // С учетом кодировки cp1251::
      if (position > 128) 
        position -= fonts[nFont]->Offs_EN_RUS;
      position -= fonts[nFont]->Offs_Symb;
      pos_x += fonts[nFont]->data[fonts[nFont]->GlyphSize * position /* + Font.headerSize */];
    }
  }

  void FontV::DrawText(const char* text, uint16_t x, uint16_t y, uint8_t brightness, uint8_t index_bsymb) {
    if(frame_buffer == nullptr)
      return;
    if( (*text == 0) || (sizeof(text) == 0) ) 
      return;

    uint8_t str_length = strlen(text);  // str == 0 ? 0 : 1 
    uint8_t pos_x = x;

    //uint8_t glif;
    for (uint8_t cnt = 0; cnt < str_length; cnt++, *text++) {
      if(cnt == index_bsymb) DrawChar(frame_buffer, *text, pos_x, y, !brightness);
      else                   DrawChar(frame_buffer, *text, pos_x, y, brightness);
      uint8_t position = *text;
      // С учетом кодировки cp1251::
      if (position > 128) 
        position -= fonts[nFont]->Offs_EN_RUS;
      position -= fonts[nFont]->Offs_Symb;
      pos_x += fonts[nFont]->data[fonts[nFont]->GlyphSize * position /* + Font.headerSize */];
    }
  }

  void FontV::DrawChar(uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness) {
    DrawChar(frame_buffer, chr, x, y, brightness);
  }

  void FontV::DrawChar(uint8_t *frame_buffer, uint8_t chr, uint16_t x, uint16_t y, uint8_t brightness) {
    if(frame_buffer == nullptr)
      return;
    // Применяем кодировку CP1251 и смещаем до русских букв, если они есть
    uint8_t n_glyph = chr;
    // С учетом кодировки cp1251::
    if (n_glyph > 128) 
      n_glyph -= fonts[nFont]->Offs_EN_RUS;
    uint8_t widht = fonts[nFont]->data[fonts[nFont]->GlyphSize * (n_glyph - fonts[nFont]->Offs_Symb)];
      
    const uint8_t* data_glyph = 
      &fonts[nFont]->data[fonts[nFont]->GlyphSize * (n_glyph - fonts[nFont]->Offs_Symb) + 1];

    uint16_t bb_pos; // Позиция байта/бита
    for (uint8_t _x = 0; _x < widht; _x++) {
      for (uint8_t _y = 0; _y < fonts[nFont]->Heigth; _y++) {
        bb_pos = (fonts[nFont]->Heigth * _x  + _y);
        if (data_glyph[bb_pos/8] & (0x01 << (7 - bb_pos % 8))) {
          DrawPixel( _x + x, _y + y, (brightness) ? 0xfu : 0 ); /* 0xfu - это яркость пикселя */ 
        }
        else {
          DrawPixel( _x + x, _y + y, (brightness) ? 0 : 0xfu );
        }
      }
    }
  }

  uint16_t FontV::GetWidth (uint8_t  symbol) {
    // С учетом кодировки cp1251::
    if (symbol > 128) 
      symbol -= fonts[nFont]->Offs_EN_RUS;
    return fonts[nFont]->data[fonts[nFont]->GlyphSize * (symbol - fonts[nFont]->Offs_Symb)];
  }

  uint16_t FontV::GetWidth (const char* _string) {
    uint8_t lenghtStr = strlen(_string); 
    uint8_t width { 0 };                  /*  Позиция в массиве */ 
    //Старый вариает без ширины: len = stl * Font.width;
    for(uint8_t j = 0; j < lenghtStr; ++j) {
      width += GetWidth((uint8_t)_string[j]);
    }
    return width;
  }

  uint16_t FontV::GetWidth (int32_t num) {
    // char buf[15];
    // sprintf(buf, "%d", num);
    // return OLED_GetWidthStr(buf);
    return 0;
  }

  uint8_t FontV::GetHigh() {
    return fonts[nFont]->Heigth;
  }

#pragma endregion [ViFont]