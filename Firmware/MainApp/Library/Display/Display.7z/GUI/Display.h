#ifndef _DISPLAY_H_
#define _DISPLAY_H_

#include <cstdint>
#include "SPIDisplay.h"
#include "SSD1322.h"
#include "SBerryPIO.h"
#include "GFX.h"

/// @brief Переопределение имени типа
using Switcher = SBerryCore::Switcher;

static constexpr uint16_t OLED_Height { 64  };    /* Высота дисплея */ 
static constexpr uint16_t OLED_Width  { 256 };    /* Ширина дисплея */

/// @brief Класс отвечающий за работу дисплея на драйвере SSD1322
class Display {
  private:
    uint8_t*                frame_buffer;       /* Указатель на буффер */
    ICs::SSD1322*           ic_ssd1322;         /* API + Driver для управление микросхемой SSD1322 */

  public:
    static const uint16_t   width   { OLED_Width   };    /* Высота дисплея */
    static const uint16_t   height  { OLED_Height  };    /* Ширина дисплея */
    static Switcher         power;                       /* Питание дисплея */

  public:
    Display(ICs::SSD1322* ssd1322);

    /// @brief Инициализация дисплея и связанной перефирии
    void Init();

    void SetBuffer(uint8_t *frame);

    /// @brief Обновление кадра
    /// @param [in] start_x   :: Начальная координата обновления по оси x
    /// @param [in] start_y   :: Начальная координата обновления по оси y
    void Update(uint16_t start_x, uint16_t start_y);

};

#endif // _DISPLAY_H_