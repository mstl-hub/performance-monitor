#ifndef _BOARDB_MAINPAGE_H_
#define _BOARDB_MAINPAGE_H_

  #include <cstdint>
  #include "Window.h"
  #include "Filter.h"

  #include "CropRProtocol.h"

  /// @brief Начальная страница для отображения IO платы board_a 
  class BoardB_MainPage : public IPage {
    typedef enum SubPage {
      SubPage_AnalogInputs,     /* Отображать страницу с аналоговыми входами  */
      SubPage_DigitalInputs,    /* Отображать страницу с цифровыми   входами  */
      SubPage_AnalogOtputs,     /* Отображать страницу с аналоговыми выходами */
      SubPage_DigitalOtputs,    /* Отображать страницу с цифровыми   выходами */
    } tSubPage;

    /* Переопределение клавиши для текщей страницы */
    typedef enum IOBKeyCode : uint32_t {
      Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
      Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
      Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
      Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
    } tKeyCode;
 
    tSubPage sub_page;     /* режим отображения текущей страницы */

    CroptimizRProtocol::AINs*   boards_ains;                      /* Указатель на аналоговые входы io-платы       */
    char*     rus_string      { nullptr };                        /*  */
    uint16_t  rus_string_len  { };
    uint8_t   num_label[15]   { };
    uint8_t   y_high          { };
    float     avalue          { 0.0f };

    const struct PageGrid {
      uint16_t x_column_0 { 0   };  /* Начальная позиция по оси x колонки 0 */
      uint16_t x_column_1 { 64  };  /* Начальная позиция по оси x колонки 1 */
      uint16_t x_column_2 { 128 };  /* Начальная позиция по оси x колонки 2 */
      uint16_t x_column_3 { 192 };  /* Начальная позиция по оси x колонки 3 */
    } page_grid;

    public:
      BoardB_MainPage(Window* window);

      virtual void Init() override;

      virtual void ClickHandl(uint32_t code) override;

      virtual void Loop() override;

      inline void LoopSubPage_AnalogInputs();
      inline void LoopSubPage_DigitalInputs();
      inline void LoopSubPage_AnalogOutputs();
      inline void LoopSubPage_DigitalOutputs();
  };

  #define BOARDB_MPAGE_SIZE (sizeof(BoardB_MainPage))

#endif//_BOARDB_MAINPAGE_H_