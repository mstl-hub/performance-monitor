#include "BoardB_MainPage.h"

#include "GFX.h"
#include "SBerryBoard.h"
#include "SBDelay.h"
#include "UnitALineTask.h"
#include "UnitBLineTask.h"
#include "Images.h"

using tImageAlias = Images::tImageAlias;      /* Псевдонимы изображений */

BoardB_MainPage::BoardB_MainPage(Window* window) : IPage(window) { }

void BoardB_MainPage::Init() {
  // window->display_memory;
  // AINS = UnitALineTasl.GetPtrAnalogInputs()
  boards_ains = UnitB_Line::UnitBLineTask::GetAInsPointer();
  sub_page = tSubPage::SubPage_AnalogInputs;
}

void BoardB_MainPage::ClickHandl(uint32_t code)  {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Up:
        if(sub_page > tSubPage::SubPage_AnalogInputs)
          (*((uint32_t*)&sub_page))--;
      break;
    case tKeyCode::Key_Down:
        if(sub_page < tSubPage::SubPage_DigitalOtputs)
          (*((uint32_t*)&sub_page))++;
      break;
    default:
      break;
  }
}

void BoardB_MainPage::Loop() {
  mwindow->Clear();
  if(boards_ains == nullptr)
    boards_ains = UnitB_Line::UnitBLineTask::GetAInsPointer();
  // uint8_t num_label [15] {};
  // StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), keys_code);
  // mwindow->font.DrawText((char*)num_label, 128, 32, 1);

  /* { .type_board = CANFuncs::tSPI_IDBoard::SPIidBoard_IO2033, .quant_ains = 12, .quant_dins = 8, .quant_aouts = 16, .quant_douts = 16  }, */
  switch(sub_page) {
    case SubPage_AnalogInputs:
        LoopSubPage_AnalogInputs();
      break;
    case SubPage_DigitalInputs:
        LoopSubPage_DigitalInputs();
      break;
    case SubPage_AnalogOtputs:
        LoopSubPage_AnalogOutputs();
      break;
    case SubPage_DigitalOtputs:
        LoopSubPage_DigitalOutputs();
      break;
    default:
      break;
  }

  mwindow->display->Update(0,0);
}

inline void BoardB_MainPage::LoopSubPage_AnalogInputs(){
  rus_string      = StringConverter::UTF8ToCP1251("МОНИТОР АНАЛОГОВЫХ ВХОДОВ");
  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , 0, 1);
  memset(num_label, 0, sizeof(num_label));
  y_high = 0;
  float     avalue { 0.0f };
  auto print_ains_f = [&](bool ains_state, const char* _rus_string, float* ains_value, tImageAlias img_alias, uint16_t x, uint16_t y) {
    if(!ains_state) {
      mwindow->font.DrawText(_rus_string, x, y, 1);
      rus_string_len  = mwindow->font.GetWidth(_rus_string);
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
      return;
    }
    memset(num_label, 0, sizeof(num_label));
    rus_string      = StringConverter::UTF8ToCP1251(_rus_string);
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, x, y, 1);
    
    StringConverter::FloatToString((uint8_t*)num_label, sizeof(num_label), ains_value);
    mwindow->font.DrawText((char*)num_label, x + rus_string_len, y, 1);
    x += rus_string_len + mwindow->font.GetWidth((const char*)num_label) + 2; /* +2 это пробел */
    
    mwindow->images.SetImage(img_alias);
    mwindow->images.DrawImage(x, y);
  };
  auto print_ains_i = [&](bool ains_state, const char* _rus_string, int16_t ains_value, tImageAlias img_alias, uint16_t x, uint16_t y){
    if(!ains_state) {
      mwindow->font.DrawText(_rus_string, x, y, 1);
      rus_string_len  = mwindow->font.GetWidth(_rus_string);
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
      return;
    }
    memset(num_label, 0, sizeof(num_label));
    rus_string      = StringConverter::UTF8ToCP1251(_rus_string);
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, x, y, 1);
    StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), ains_value);
    
    mwindow->font.DrawText((char*)num_label, x + rus_string_len, y, 1);
    /* print units */
    // uint16_t width_units = mwindow->font.GetWidth((char*)num_label);
    // mwindow->font.DrawText(units_string, x + rus_string_len + width_units, y, 1);
    x += rus_string_len + mwindow->font.GetWidth((const char*)num_label) + 2; /* +2 это пробел */
    mwindow->images.SetImage(img_alias);
    mwindow->images.DrawImage(x, y);
  };
  /*! NOTES:
    Расположение элементов по сетке:
    1     6     11    16
    2     7     12
    3     8     13
    4     9     14
    5     10    15
  */
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(0)) / 10.0f; print_ains_i(UnitB_Line::UnitBLineTask::GetAINSState(0), "1: ", boards_ains[0].GetConvertedValue(), tImageAlias::img_units_10x_percent,  page_grid.x_column_0,  y_high);

    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(5)) / 10.0f; print_ains_f(false, "6: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1, y_high);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(10))/ 10.0f; print_ains_f(false,"11: ",&avalue, tImageAlias::img_units_10x_percent,  page_grid.x_column_2,  y_high);
                                                                              // print_ains_i(UnitB_Line::UnitBLineTask::GetAINSState(15),"16: ",boards_ains[15].GetConvertedValue(),  tImageAlias::img_units_10x12_ppm,  192,  y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(1)) / 10.0f; print_ains_i(UnitB_Line::UnitBLineTask::GetAINSState(1),"2: ",  boards_ains[1].GetConvertedValue(), tImageAlias::img_units_10x_percent,  page_grid.x_column_0,    y_high);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(6)) / 10.0f; print_ains_f(false,"7: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1, y_high);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(11))/ 10.0f; print_ains_f(false,"12: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_2, y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    SBDelay::Delay_ms(2);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(2)) / 10.0f; print_ains_i(UnitB_Line::UnitBLineTask::GetAINSState(2),"3: ",  boards_ains[2].GetConvertedValue(), tImageAlias::img_units_10x12_ppm,  page_grid.x_column_0,    y_high);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(7)) / 10.0f; print_ains_f(false,"8: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1, y_high);
    // avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(12))/ 10.0f; print_ains_f(UnitB_Line::UnitBLineTask::GetAINSState(12),"13: ",&avalue, tImageAlias::img_units_10x_grad_celsius,  128,  y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    SBDelay::Delay_ms(2);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(3)) / 10.0f; print_ains_f(false,"4: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_0, y_high);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(8)) / 10.0f; print_ains_f(false,"9: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1, y_high);
                                                                              // print_ains_i(UnitB_Line::UnitBLineTask::GetAINSState(13),"14: ",boards_ains[13].GetConvertedValue(), tImageAlias::img_units_10x_percent,  128,  y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    SBDelay::Delay_ms(2);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(4)) / 10.0f; print_ains_f(false,"5: ",  &avalue,  tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_0, y_high);
    avalue = ((float) UnitB_Line::UnitBLineTask::GetAINSAVGValue(9)) / 10.0f; print_ains_i(UnitB_Line::UnitBLineTask::GetAINSState(9),"10: ", boards_ains[9].GetConvertedValue(), tImageAlias::img_units_10x_percent, page_grid.x_column_1,     y_high);
                                                                              // print_ains_i(UnitB_Line::UnitBLineTask::GetAINSState(14),"15: ",boards_ains[14].GetConvertedValue(),  tImageAlias::img_units_10x_percent,  128,  y_high);
}
inline void BoardB_MainPage::LoopSubPage_DigitalInputs(){
  /* { .type_board = CANFuncs::tSPI_IDBoard::SPIidBoard_IO2033, .quant_ains = 12, .quant_dins = 8, .quant_aouts = 16, .quant_douts = 16  }, */
  rus_string      = StringConverter::UTF8ToCP1251("МОНИТОР ЦИФРОВЫХ ВХОДОВ");
  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , 0, 1);
  memset(num_label, 0, sizeof(num_label));
  y_high = 0;
  // float     avalue { 0.0f };
  auto print_dins = [&](const char* vstring, bool state, bool state_latch, uint16_t x, uint16_t y){
    mwindow->font.DrawText(vstring, x, y, 1);
    rus_string_len = mwindow->font.GetWidth(vstring);
    if(state) {
      if(state_latch)
        rus_string  = StringConverter::UTF8ToCP1251("Вкл.");
      else
        rus_string  = StringConverter::UTF8ToCP1251("Выкл.");

      mwindow->font.DrawText(rus_string, x + rus_string_len, y, 1);
    }
    else {
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
    }
  };
  y_high  = mwindow->font.GetHigh() + 1;
  print_dins("1: ",   UnitB_Line::UnitBLineTask::GetDinsState(0),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(0),  page_grid.x_column_0, y_high);
  print_dins("6: ",   UnitB_Line::UnitBLineTask::GetDinsState(5),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(5),  page_grid.x_column_1, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_dins("2: ",   UnitB_Line::UnitBLineTask::GetDinsState(1),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(1),  page_grid.x_column_0, y_high);
  print_dins("7: ",   UnitB_Line::UnitBLineTask::GetDinsState(6),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(6),  page_grid.x_column_1, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_dins("3: ",   UnitB_Line::UnitBLineTask::GetDinsState(2),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(2),  page_grid.x_column_0, y_high);
  print_dins("8: ",   UnitB_Line::UnitBLineTask::GetDinsState(7),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(7),  page_grid.x_column_1, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_dins("4: ",   UnitB_Line::UnitBLineTask::GetDinsState(3),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(3),  page_grid.x_column_0, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_dins("5: ",   UnitB_Line::UnitBLineTask::GetDinsState(4),  UnitB_Line::UnitBLineTask::GetDinsStateLatch(4),  page_grid.x_column_0, y_high);
}
inline void BoardB_MainPage::LoopSubPage_AnalogOutputs(){
  /* { .type_board = CANFuncs::tSPI_IDBoard::SPIidBoard_IO2033, .quant_ains = 12, .quant_dins = 8, .quant_aouts = 16, .quant_douts = 16  }, */
  rus_string      = StringConverter::UTF8ToCP1251("МОНИТОР АНАЛОГОВЫХ ВЫХОДОВ");
  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , 0, 1);
  memset(num_label, 0, sizeof(num_label));
  y_high = 0;
  float     avalue { 0.0f };
  auto print_aouts = [&](const char* vstring, bool state, float value, uint16_t x, uint16_t y){
    mwindow->font.DrawText(vstring, x, y, 1);
    rus_string_len = mwindow->font.GetWidth(vstring);
    if(state) {
      StringConverter::FloatToString((uint8_t*)num_label, sizeof(num_label), &value, " V");
      mwindow->font.DrawText((const char*)num_label, x + rus_string_len, y, 1);
    } 
    else {
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
    }
  };
  y_high += mwindow->font.GetHigh() + 1;
  print_aouts("1: ",  UnitB_Line::UnitBLineTask::GetAoutsState(0),  UnitB_Line::UnitBLineTask::GetAoutsValue(0), page_grid.x_column_0, y_high);
  print_aouts("6: ",  false,                                        avalue,                                      page_grid.x_column_1, y_high);
  print_aouts("11: ", false,                                        avalue,                                      page_grid.x_column_2, y_high);
  print_aouts("16: ", false,                                        avalue,                                      page_grid.x_column_3, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_aouts("2: ",  UnitB_Line::UnitBLineTask::GetAoutsState(1), UnitB_Line::UnitBLineTask::GetAoutsValue(1),  page_grid.x_column_0, y_high);
  print_aouts("7: ",  false, avalue, page_grid.x_column_1, y_high);
  print_aouts("12: ", false, avalue, page_grid.x_column_2, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_aouts("3: ",  false, avalue, page_grid.x_column_0, y_high);
  print_aouts("8: ",  false, avalue, page_grid.x_column_1, y_high);
  print_aouts("13: ", false, avalue, page_grid.x_column_2, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_aouts("4: ",  false, avalue, page_grid.x_column_0, y_high);
  print_aouts("9: ",  false, avalue, page_grid.x_column_1, y_high);
  print_aouts("14: ", false, avalue, page_grid.x_column_2, y_high);
  y_high += mwindow->font.GetHigh() + 1;
  print_aouts("5: ",  false, avalue, page_grid.x_column_0, y_high);
  print_aouts("10: ", false, avalue, page_grid.x_column_1, y_high);
  print_aouts("15: ", false, avalue, page_grid.x_column_2, y_high);
  
}
inline void BoardB_MainPage::LoopSubPage_DigitalOutputs(){
  /* { .type_board = CANFuncs::tSPI_IDBoard::SPIidBoard_IO2033, .quant_ains = 12, .quant_dins = 8, .quant_aouts = 16, .quant_douts = 16  }, */
  rus_string      = StringConverter::UTF8ToCP1251("МОНИТОР ЦИФРОВЫХ ВЫХОДОВ");
  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , 0, 1);
  memset(num_label, 0, sizeof(num_label));
  y_high = 0;
  auto print_douts = [&](const char* vstring, bool state, bool state_latch, uint16_t x, uint16_t y){
    mwindow->font.DrawText(vstring, x, y, 1);
    rus_string_len = mwindow->font.GetWidth(vstring);
    if(state) {
      if(state_latch)
        rus_string  = StringConverter::UTF8ToCP1251("Вкл.");
      else
        rus_string  = StringConverter::UTF8ToCP1251("Выкл.");

      mwindow->font.DrawText(rus_string, x + rus_string_len, y, 1);
    }
    else {
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
    }
  };
  y_high  += mwindow->font.GetHigh() + 1;
  print_douts("1: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(0),  page_grid.x_column_0, y_high);
  print_douts("6: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(5),  page_grid.x_column_1, y_high);
  print_douts("11: ", true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(10), page_grid.x_column_2, y_high);
  print_douts("16: ", true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(15), page_grid.x_column_3, y_high);
  y_high  += mwindow->font.GetHigh() + 1;
  print_douts("2: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(1),  page_grid.x_column_0, y_high);
  print_douts("7: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(6),  page_grid.x_column_1, y_high);
  print_douts("12: ", true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(11), page_grid.x_column_2, y_high);
  y_high  += mwindow->font.GetHigh() + 1;
  print_douts("3: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(2),  page_grid.x_column_0, y_high);
  print_douts("8: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(7),  page_grid.x_column_1, y_high);
  print_douts("13: ", true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(12), page_grid.x_column_2, y_high);
  y_high  += mwindow->font.GetHigh() + 1;
  print_douts("4: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(3),  page_grid.x_column_0, y_high);
  print_douts("9: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(8),  page_grid.x_column_1, y_high);
  print_douts("14: ", true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(13), page_grid.x_column_2, y_high);
  y_high  += mwindow->font.GetHigh() + 1;
  print_douts("5: ",  true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(4),  page_grid.x_column_0, y_high);
  print_douts("10: ", true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(9),  page_grid.x_column_1, y_high);
  print_douts("15: ", true, UnitB_Line::UnitBLineTask::GetDoutsStateLatch(14), page_grid.x_column_2, y_high);

}