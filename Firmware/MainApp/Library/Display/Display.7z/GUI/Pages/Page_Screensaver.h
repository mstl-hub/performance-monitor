#ifndef _PAGE_SCREENSAVER_H_
#define _PAGE_SCREENSAVER_H_

#include <cstdint>
#include "Window.h"

/// @brief Страница "Заставка ТАФКО"
class tafcoScreensaver : public IPage {
  uint16_t    pos_x { 0 };
  uint16_t    pos_y { 0 };

  public:
    tafcoScreensaver(Window* window);
    virtual void Init() override;
    virtual void ClickHandl(uint32_t code) override;
    virtual void Loop() override;
};

#define TAFCO_SCREENSAVER_SIZE (sizeof(tafcoScreensaver))

/// @brief Страница "Заставка ТАФКО"
class VestorScreensaver : public IPage {
  uint16_t    pos_x { 0 };
  uint16_t    pos_y { 0 };

  public:
    VestorScreensaver(Window* window);
    virtual void Init() override;
    virtual void ClickHandl(uint32_t code) override;
    virtual void Loop() override;
};

#define VESTOR_SCREENSAVER_SIZE (sizeof(VestorScreensaver))

#endif //___PAGE_SCREENSAVER_H_