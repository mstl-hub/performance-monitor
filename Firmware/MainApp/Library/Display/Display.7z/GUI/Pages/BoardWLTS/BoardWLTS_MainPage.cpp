#include "BoardWLTS_MainPage.h"

#include "GFX.h"
#include "SBerryBoard.h"
#include "SBDelay.h"
#include "BoardWLTSLineTask.h"
#include "Images.h"

using tImageAlias = Images::tImageAlias;      /* Псевдонимы изображений */

BoardWLTS_MainPage::BoardWLTS_MainPage(Window* window) : IPage(window) { }

void BoardWLTS_MainPage::Init() {
  // window->display_memory;
  // AINS = UnitALineTasl.GetPtrAnalogInputs()
  boards_ains = UnitWLTS_Line::UnitWLTSLineTask::GetAInsPointer();
}

void BoardWLTS_MainPage::ClickHandl(uint32_t code)  { }

void BoardWLTS_MainPage::Loop() {
  mwindow->Clear();

  /* Раскидываем значения с AINS */
  uint8_t   num_label[15] { };
  uint8_t   y_high = 0;
  char*     rus_string      = StringConverter::UTF8ToCP1251("МОНИТОР АНАЛОГОВЫХ ВХОДОВ");
  uint16_t  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);

  if(boards_ains == nullptr)
    boards_ains = UnitWLTS_Line::UnitWLTSLineTask::GetAInsPointer();

  auto print_ains_f = [&](bool ains_state, const char* _rus_string, float* ains_value, tImageAlias img_alias, uint16_t x, uint16_t y) {
    if(!ains_state) {
      mwindow->font.DrawText(_rus_string, x, y, 1);
      rus_string_len  = mwindow->font.GetWidth(_rus_string);
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
      return;
    }
    memset(num_label, 0, sizeof(num_label));
    rus_string      = StringConverter::UTF8ToCP1251(_rus_string);
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, x, y, 1);
    
    StringConverter::FloatToString((uint8_t*)num_label, sizeof(num_label), ains_value);
    mwindow->font.DrawText((char*)num_label, x + rus_string_len, y, 1);
    x += rus_string_len + mwindow->font.GetWidth((const char*)num_label) + 2; /* +2 это пробел */
    
    mwindow->images.SetImage(img_alias);
    mwindow->images.DrawImage(x, y);
  };
  auto print_ains_i = [&](bool ains_state, const char* _rus_string, int16_t ains_value, tImageAlias img_alias, uint16_t x, uint16_t y){
    if(!ains_state) {
      mwindow->font.DrawText(_rus_string, x, y, 1);
      rus_string_len  = mwindow->font.GetWidth(_rus_string);
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
      return;
    }
    memset(num_label, 0, sizeof(num_label));
    rus_string      = StringConverter::UTF8ToCP1251(_rus_string);
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, x, y, 1);
    StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), ains_value);
    
    mwindow->font.DrawText((char*)num_label, x + rus_string_len, y, 1);
    /* print units */
    // uint16_t width_units = mwindow->font.GetWidth((char*)num_label);
    // mwindow->font.DrawText(units_string, x + rus_string_len + width_units, y, 1);
    x += rus_string_len + mwindow->font.GetWidth((const char*)num_label) + 2; /* +2 это пробел */
    mwindow->images.SetImage(img_alias);
    mwindow->images.DrawImage(x, y);
  };
  // boards_ains[0].GetConvertedValue(boards_ains[0].adc_value_v)
  // 6 строк всего, 5 строк на таблицу
  float avalue;
  /*! NOTES:
    Расположение элементов по сетке:
    1     6     11    16
    2     7     12
    3     8     13
    4     9     14
    5     10    15
    c 13й позиции начинается вольт-токовые датчики 
  */
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(0)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(0),  "1: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_0,  y_high);
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(5)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(5),  "6: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1,  y_high);
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(10))/ 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(10), "11: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_2,  y_high);
    avalue = 0.0f;                                                                  print_ains_f(false,                                             "16: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_3,  y_high);     
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(1)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(1),  "2: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_0,  y_high);
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(6)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(6),  "7: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1,  y_high);
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(11))/ 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(11), "12: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_2,  y_high);     
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(2)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(2),  "3: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_0,  y_high);
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(7)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(7),  "8: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1,  y_high);
    avalue = 0.0f;                                                                  print_ains_f(false,                                             "13: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_2,  y_high);     
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(3)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(3),  "4: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_0,  y_high);
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(8)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(8),  "9: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1,  y_high);
    avalue = 0.0f;                                                                  print_ains_f(false,                                             "14: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_2,  y_high);     
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(4)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(4),  "5: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_0,  y_high);
    avalue = ((float) UnitWLTS_Line::UnitWLTSLineTask::GetAINSAVGValue(9)) / 10.0f; print_ains_f(UnitWLTS_Line::UnitWLTSLineTask::GetAINSState(9),  "10: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_1,  y_high);
    avalue = 0.0f;                                                                  print_ains_f(false,                                             "15: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  page_grid.x_column_2,  y_high);
  mwindow->display->Update(0,0);
}