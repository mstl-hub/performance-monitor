#include "BoardA_MainPage.h"
#include "GFX.h"
#include "SBerryBoard.h"
#include "SBDelay.h"
#include "UnitALineTask.h"
#include "Images.h"

using tImageAlias = Images::tImageAlias;      /* Псевдонимы изображений */

BoardA_MainPage::BoardA_MainPage(Window* window) : IPage(window) { }

void BoardA_MainPage::Init() {
  // window->display_memory;
  // AINS = UnitALineTasl.GetPtrAnalogInputs()
  boards_ains = UnitA_Line::UnitALineTask::GetAInsPointer();
}

void BoardA_MainPage::ClickHandl(uint32_t code)  { }

void BoardA_MainPage::Loop() {
  mwindow->Clear();

  /* Раскидываем значения с AINS */
  uint8_t   num_label[15] { };
  uint8_t   y_high = 0;
  char*     rus_string      = StringConverter::UTF8ToCP1251("МОНИТОР АНАЛОГОВЫХ ВХОДОВ");
  uint16_t  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);

  if(boards_ains == nullptr)
    boards_ains = UnitA_Line::UnitALineTask::GetAInsPointer();

  auto print_ains_f = [&](bool ains_state, const char* _rus_string, float* ains_value, tImageAlias img_alias, uint16_t x, uint16_t y) {
    if(!ains_state) {
      mwindow->font.DrawText(_rus_string, x, y, 1);
      rus_string_len  = mwindow->font.GetWidth(_rus_string);
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
      return;
    }
    memset(num_label, 0, sizeof(num_label));
    rus_string      = StringConverter::UTF8ToCP1251(_rus_string);
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, x, y, 1);
    
    StringConverter::FloatToString((uint8_t*)num_label, sizeof(num_label), ains_value);
    mwindow->font.DrawText((char*)num_label, x + rus_string_len, y, 1);
    x += rus_string_len + mwindow->font.GetWidth((const char*)num_label) + 2; /* +2 это пробел */
    
    mwindow->images.SetImage(img_alias);
    mwindow->images.DrawImage(x, y);
  };
  auto print_ains_i = [&](bool ains_state, const char* _rus_string, int16_t ains_value, tImageAlias img_alias, uint16_t x, uint16_t y){
    if(!ains_state) {
      mwindow->font.DrawText(_rus_string, x, y, 1);
      rus_string_len  = mwindow->font.GetWidth(_rus_string);
      mwindow->font.DrawText("--", x + rus_string_len, y, 1);
      return;
    }
    memset(num_label, 0, sizeof(num_label));
    rus_string      = StringConverter::UTF8ToCP1251(_rus_string);
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, x, y, 1);
    StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), ains_value);
    
    mwindow->font.DrawText((char*)num_label, x + rus_string_len, y, 1);
    /* print units */
    // uint16_t width_units = mwindow->font.GetWidth((char*)num_label);
    // mwindow->font.DrawText(units_string, x + rus_string_len + width_units, y, 1);
    x += rus_string_len + mwindow->font.GetWidth((const char*)num_label) + 2; /* +2 это пробел */
    mwindow->images.SetImage(img_alias);
    mwindow->images.DrawImage(x, y);
  };
  // boards_ains[0].GetConvertedValue(boards_ains[0].adc_value_v)
  // 6 строк всего, 5 строк на таблицу
  float avalue;
  /*
  
    TODO:
      - [X] Если статус - не работает, то прочерк и не показываем единицы измерения
      - [ ] Разобюраться с вызовом init
  */
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(0)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(0), "1: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  0,    y_high);

    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(5)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(5), "6: ", &avalue, tImageAlias::img_units_10x_grad_celsius,  64,   y_high);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(10))/ 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(10),"11: ",&avalue, tImageAlias::img_units_10x_grad_celsius,  128,  y_high);
                                                                              print_ains_i(UnitA_Line::UnitALineTask::GetAINSState(15),"16: ",boards_ains[15].GetConvertedValue(),  tImageAlias::img_units_10x12_ppm,  192,  y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(1)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(1),"2: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  0,    y_high);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(6)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(6),"7: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  64,   y_high);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(11))/ 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(11),"12: ",&avalue, tImageAlias::img_units_10x_grad_celsius,  128,  y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    SBDelay::Delay_ms(2);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(2)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(2),"3: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  0,    y_high);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(7)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(7),"8: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  64,   y_high);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(12))/ 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(12),"13: ",&avalue, tImageAlias::img_units_10x_grad_celsius,  128,  y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    SBDelay::Delay_ms(2);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(3)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(3),"4: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  0,    y_high);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(8)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(8),"9: ",  &avalue, tImageAlias::img_units_10x_grad_celsius,  64,   y_high);
                                                                              print_ains_i(UnitA_Line::UnitALineTask::GetAINSState(13),"14: ",boards_ains[13].GetConvertedValue(), tImageAlias::img_units_10x_percent,  128,  y_high);
  y_high += mwindow->font.GetHigh() + 1;  
    SBDelay::Delay_ms(2);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(4)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(4),"5: ",  &avalue,  tImageAlias::img_units_10x_grad_celsius,  0,      y_high);
    avalue = ((float) UnitA_Line::UnitALineTask::GetAINSAVGValue(9)) / 10.0f; print_ains_f(UnitA_Line::UnitALineTask::GetAINSState(9),"10: ", &avalue,  tImageAlias::img_units_10x_grad_celsius,  64,     y_high);
                                                                              print_ains_i(UnitA_Line::UnitALineTask::GetAINSState(14),"15: ",boards_ains[14].GetConvertedValue(),  tImageAlias::img_units_10x_percent,  128,  y_high);
      
  
  mwindow->display->Update(0,0);
}