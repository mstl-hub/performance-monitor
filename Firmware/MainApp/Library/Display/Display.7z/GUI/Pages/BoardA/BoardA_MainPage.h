#ifndef _BOARDA_MAINPAGE_H_
#define _BOARDA_MAINPAGE_H_

  #include <cstdint>
  #include "Window.h"
  #include "Filter.h"

  #include "CropRProtocol.h"

  /// @brief Начальная страница для отображения IO платы board_a 
  class BoardA_MainPage : public IPage {
    uint16_t  counter {0};
    CroptimizRProtocol::AINs*   boards_ains;                      /* Указатель на аналоговые входы io-платы       */

    public:
      BoardA_MainPage(Window* window);

      virtual void Init() override;

      virtual void ClickHandl(uint32_t code) override;

      virtual void Loop() override;

  };

  #define BOARDA_MPAGE_SIZE (sizeof(BoardA_MainPage))

#endif //___BOARDA_MAINPAGE_H_