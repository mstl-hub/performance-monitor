#ifndef _MBU_MAINPAGE_H_
#define _MBU_MAINPAGE_H_

  #include <cstdint>
  #include "Window.h"
  #include "Filter.h"

  /// @brief Отладочная страница
  class MBU_MainPage : public IPage {
    typedef enum SubPage {
      SubPage_Status,          /* Отображать страницу со статусами работы      */
      SubPage_ReservControl,   /* Отображать страницу с резервное управление   */
      SubPage_fwInfo,          /* Отображать страницу с информация о прошивке  */
      SubPage_CompanyInfo,     /* Отображать страницу с информация о компании  */
    } tSubPage;

    /* Переопределение клавиши для текущей страницы */
    typedef enum IOBKeyCode : uint32_t {
      Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
      Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
      Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
      Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
    } tKeyCode;

    tSubPage  sub_page;
    bool      entry_mode_reserv_ctrl { false };
    uint8_t   pwd_state              { 0   };         /* 0 - 3 это выбор символа пароля, 4 это принять */
    char      pwd_symb[4]            { '0', '0', '0', '0' };
    bool      pwd_accept             { false };

    char*     rus_string      { nullptr };                        /*  */
    uint16_t  rus_string_len  { };
    uint8_t   num_label[15]   { };
    uint8_t   y_high = 0;

    uint16_t  reset_counter {};

    uint8_t   cache[32] {};

    uint8_t   cnt_reset_stat {0};

    public:
      MBU_MainPage(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;

      inline void LoopSubPage_MainStatus();
      inline void LoopSubPage_Debug();
      inline void LoopSubPage_ReservControl();
      inline void LoopSubPage_fwInfo();
      inline void LoopSubPage_CompanyInfo();
  };

#endif//_MBU_MAINPAGE_H_