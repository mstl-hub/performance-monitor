#include "MBU_MainPage.h"
#include "SBDelay.h"

#include "PICTransport.h"

MBU_MainPage::MBU_MainPage(Window* window) : IPage(window){}

void MBU_MainPage::Init(){
  // PICuyan::SPILineTask::tStatistics* loc_statistics = PICuyan::SPILineTask::GetStatistic();
  // memcpy(cache, loc_statistics, sizeof(PICuyan::SPILineTask::tStatistics));
}

void MBU_MainPage::ClickHandl(uint32_t code){
  /// @brief Обработчик нажатия клавиш для главной страницы
  auto click_handle_main = [&](){
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Up:
          if(sub_page > tSubPage::SubPage_Status)
            (*((uint32_t*)&sub_page))--;
        break;
      case tKeyCode::Key_Down:
          if(sub_page < tSubPage::SubPage_CompanyInfo)
            (*((uint32_t*)&sub_page))++;
        break;
      case tKeyCode::Key_Accept:
          if(sub_page == tSubPage::SubPage_ReservControl) {
            entry_mode_reserv_ctrl = true;
          }
        break;
      case tKeyCode::Key_Back:
        break;
      #if (GLOB_PIC32MBU_USE_STAT )
        case (tKeyCode::Key_Back | tKeyCode::Key_Up):
            cnt_reset_stat++;
            if(cnt_reset_stat > 2) {
              cnt_reset_stat = 0;
              PICuyan::SPILineTask::mbu_debug_errors = {};
            }
          break;
      #endif
      default:
        break;
    }
  };
  /// @brief Обработчик нажатия клавиш для страницы "Резервное управление"
  auto click_handle_accept = [&](){
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Up:
          if(pwd_state < 4)
            pwd_state++;
        break;
      case tKeyCode::Key_Down:
          if(pwd_state > 0)
            pwd_state--;
        break;
      case tKeyCode::Key_Accept:
          if(pwd_state == 4)
            pwd_accept = true;
          else {
            if(pwd_symb[pwd_state] < '9') {
              pwd_symb[pwd_state]++;
            }
            else {
              pwd_symb[pwd_state] = '0';
            }
          }
        break;
      case tKeyCode::Key_Back:
          entry_mode_reserv_ctrl = false;
        break;
      default:
        break;
    }
  };

  // _pClickHandle = click_handle_main;

  if(!entry_mode_reserv_ctrl)
    click_handle_main();
  else
    click_handle_accept();
}

void MBU_MainPage::Loop(){
  mwindow->Clear();
  
  switch(sub_page) {
    case tSubPage::SubPage_Status:
        #if (GLOB_PIC32MBU_USE_STAT )
          LoopSubPage_Debug();
        #else
          LoopSubPage_MainStatus();
        #endif
      break;
    case tSubPage::SubPage_ReservControl :
        LoopSubPage_ReservControl();
      break;
    case tSubPage::SubPage_fwInfo:
        LoopSubPage_fwInfo();
      break;
    case tSubPage::SubPage_CompanyInfo:
        LoopSubPage_CompanyInfo();
      break;
    default:
      break;
  }

  mwindow->display->Update(0,0);
}

inline void MBU_MainPage::LoopSubPage_MainStatus() {
  #if (GLOB_PIC32MBU_USE_STAT )
    PICuyan::SPILineTask::tStatistics* _statistics        = PICuyan::SPILineTask::GetStatistic();
    // PICuyan::SPILineTask::tStatistics* _statistics_cache  = (PICuyan::SPILineTask::tStatistics*)cache;

    y_high = 0;
    rus_string      = StringConverter::UTF8ToCP1251("СТАТУС СИСТЕМЫ РЕЗЕРВНОГО УПРАВЛЕНИЯ");
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);

    y_high         += mwindow->font.GetHigh() + 1;
    rus_string      = StringConverter::UTF8ToCP1251("Связь с контроллером: ");
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, 0, y_high, 1);
    if(_statistics->is_connect) {
      rus_string    = StringConverter::UTF8ToCP1251("подключено");
      mwindow->font.DrawText(rus_string, 0 + rus_string_len, y_high, 1);
    }
    else {
      rus_string    = StringConverter::UTF8ToCP1251("нет подключения");
      mwindow->font.DrawText(rus_string, 0 + rus_string_len, y_high, 1);
    }
    
    uint8_t num_label[16] {};

    auto print_val = [&](const char* label, uint32_t value, uint16_t x, uint16_t y){
      // y_high         += mwindow->font.GetHigh() + 1;
      rus_string      = StringConverter::UTF8ToCP1251(label);
      rus_string_len  = mwindow->font.GetWidth(rus_string);
      mwindow->font.DrawText(rus_string, x, y, 1);
      StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), value);
      mwindow->font.DrawText((char*)num_label, 0 + rus_string_len, y, 1);
    };
    
    y_high += mwindow->font.GetHigh() + 1; print_val("Кол-во ошибок: ", _statistics->cnt_error_no_cmd + _statistics->cnt_error_no_read, 0, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("Кол-во сообщений в приемнике: ", _statistics->que_quantity_spi_rx, 0, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("Кол-во сообщений на передачу: ", _statistics->que_quantity_spi_tx, 0, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("Кол-во необработанных сообщений: ", _statistics->que_quantity_can_rx, 0, y_high);

    reset_counter++;
    if(reset_counter > 72) {
      reset_counter = 0;
      _statistics->que_quantity_spi_tx = 0;
      _statistics->que_quantity_spi_rx = 0;
      _statistics->que_quantity_can_rx = 0;
    }
    
  #endif
}
inline void MBU_MainPage::LoopSubPage_Debug() {
  #if (GLOB_PIC32MBU_USE_STAT )
    PICuyan::SPILineTask::tStatistics* _statistics        = PICuyan::SPILineTask::GetStatistic();
    // PICuyan::SPILineTask::mbu_debug_errors;

    y_high = 0;
    rus_string      = StringConverter::UTF8ToCP1251("СТАТУС СИСТЕМЫ РЕЗЕРВНОГО УПРАВЛЕНИЯ");
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);

    y_high         += mwindow->font.GetHigh() + 1;
    rus_string      = StringConverter::UTF8ToCP1251("Связь с контроллером: ");
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, 0, y_high, 1);
    if(_statistics->is_connect) {
      rus_string    = StringConverter::UTF8ToCP1251("подключено");
      mwindow->font.DrawText(rus_string, 0 + rus_string_len, y_high, 1);
    }
    else {
      rus_string    = StringConverter::UTF8ToCP1251("нет подключения");
      mwindow->font.DrawText(rus_string, 0 + rus_string_len, y_high, 1);
    }
    
    uint8_t num_label[16] {};

    auto print_val = [&](const char* label, uint32_t value, uint16_t x, uint16_t y){

      rus_string      = (char*)label;
      rus_string_len  = mwindow->font.GetWidth(rus_string);
      mwindow->font.DrawText(rus_string, x, y, 1);
      memset(num_label, 0, sizeof(num_label));
      StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), value);
      mwindow->font.DrawText((char*)num_label, x + rus_string_len, y, 1);
    };
    
    y_high += mwindow->font.GetHigh() + 1; print_val("clspi: ",  PICuyan::SPILineTask::mbu_debug_errors.cnt_clear_tx_buffs,  0, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("canrq: ",  PICuyan::SPILineTask::mbu_debug_errors.cnt_can_req_reboot,  0, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("nocmd: ",  PICuyan::SPILineTask::mbu_debug_errors.cnt_no_cmd,          0, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("nohrt: ",  PICuyan::SPILineTask::mbu_debug_errors.cnt_no_heart_beat,   0, y_high);

    y_high = mwindow->font.GetHigh();
    y_high += mwindow->font.GetHigh() + 1; print_val("nord: ",  PICuyan::SPILineTask::mbu_debug_errors.cnt_no_read,         85, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("blck: ",   PICuyan::SPILineTask::mbu_debug_errors.cnt_que_tx_block,    85, y_high);
    
    y_high = mwindow->font.GetHigh();
    y_high += mwindow->font.GetHigh() + 1; print_val("vlcanr: ", PICuyan::SPILineTask::mbu_debug_errors.max_vol_can_rx,      170, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("vlspir: ", PICuyan::SPILineTask::mbu_debug_errors.max_vol_spi_rx,      170, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("vlspit: ", PICuyan::SPILineTask::mbu_debug_errors.max_vol_spi_tx,      170, y_high);
    y_high += mwindow->font.GetHigh() + 1; print_val("canful: ", PICuyan::SPILineTask::mbu_debug_errors.can_max_stx,         170, y_high);

    reset_counter++;
    if(reset_counter > 72) {
      reset_counter = 0;
      _statistics->que_quantity_spi_tx = 0;
      _statistics->que_quantity_spi_rx = 0;
      _statistics->que_quantity_can_rx = 0;
    }
    
  #endif
}
inline void MBU_MainPage::LoopSubPage_ReservControl() {
  y_high = 0;
  if(entry_mode_reserv_ctrl) {
    rus_string      = StringConverter::UTF8ToCP1251("КОНФИГУРАЦИЯ АЛГОРИТМА");
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);
    y_high += mwindow->font.GetHigh() + 1;
    rus_string      = StringConverter::UTF8ToCP1251("Введите пароль");
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);
    /* Вывод цифры */
    if(false == pwd_accept) {
      mwindow->font.DrawChar(pwd_symb[0], 128 - 12 , 32, !(((pwd_state | 1) >> pwd_state) & 0x1u)); 
      mwindow->font.DrawChar(pwd_symb[1], 128 - 4 , 32, !(((pwd_state | 2) >> pwd_state) & 0x1u)); 
      mwindow->font.DrawChar(pwd_symb[2], 128 + 4 , 32, !(((pwd_state | 4) >> pwd_state) & 0x1u)); 
      mwindow->font.DrawChar(pwd_symb[3], 128 + 12 , 32, !(((pwd_state | 8) >> pwd_state) & 0x1u));
      /* Подсветка кнопки принятия */
      y_high = mwindow->font.GetHigh() + 1;
      rus_string      = StringConverter::UTF8ToCP1251("Подтвердить");
      rus_string_len  = mwindow->font.GetWidth(rus_string);
      mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , 50, !(((pwd_state | 16) >> pwd_state) & 0x1u));
    }
    else { /* Вывод кнопки принятия */
      pwd_accept = false;
      rus_string = StringConverter::UTF8ToCP1251("Не верно!");
      rus_string_len  = mwindow->font.GetWidth(rus_string);
      mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , 32, 1);
      mwindow->display->Update(0,0);
      SBDelay::Delay_ms(3000);
    }
  } 
  else {
    rus_string      = StringConverter::UTF8ToCP1251("АЛГОРИТМ АВАРИЙНОГО РЕЖИМА");
    rus_string_len  = mwindow->font.GetWidth(rus_string);
    mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);

    y_high += mwindow->font.GetHigh() + 1;
    rus_string      = StringConverter::UTF8ToCP1251("Статус: выкл.");
    mwindow->font.DrawText(rus_string, 0, y_high, 1);
    y_high += mwindow->font.GetHigh() + 1;
    rus_string      = StringConverter::UTF8ToCP1251("Сконфигурировать");
    mwindow->font.DrawText(rus_string, 0, y_high, 1);
  }
}
inline void MBU_MainPage::LoopSubPage_fwInfo() {
  y_high = 0;
  rus_string      = StringConverter::UTF8ToCP1251("ИНФОРМАЦИЯ О ПО");
  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);

  y_high += mwindow->font.GetHigh() + 1;
  rus_string      = StringConverter::UTF8ToCP1251("Версия: 1.0.0");
  mwindow->font.DrawText(rus_string, 0, y_high, 1);
  
  y_high += mwindow->font.GetHigh() + 1;
  rus_string      = StringConverter::UTF8ToCP1251("Дата производства 10.01.2025");
  mwindow->font.DrawText(rus_string, 0, y_high, 1);
}
inline void MBU_MainPage::LoopSubPage_CompanyInfo() {
  y_high = 0;
  rus_string      = StringConverter::UTF8ToCP1251("ИНФОРМАЦИЯ О КОМПАНИИ");
  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);

  y_high += mwindow->font.GetHigh() + 1;
  rus_string      = StringConverter::UTF8ToCP1251("ООО ТАФКО");
  mwindow->font.DrawText(rus_string, 0, y_high, 1);

  y_high += mwindow->font.GetHigh() + 1;
  rus_string      = StringConverter::UTF8ToCP1251("392000, Тамбовская область,");
  mwindow->font.DrawText(rus_string, 0, y_high, 1);
  y_high += mwindow->font.GetHigh() + 1;
  rus_string      = StringConverter::UTF8ToCP1251("г.Тамбов, б-р Энтузиастов, д.1с, помещ.1");
  mwindow->font.DrawText(rus_string, 0, y_high, 1);
  
  y_high += mwindow->font.GetHigh() + 1;
  mwindow->font.DrawText("tafco@ internet.ru", 0, y_high, 1);
  y_high += mwindow->font.GetHigh() + 1;
  mwindow->font.DrawText("8-960-670-12-12", 0, y_high, 1);
   
}