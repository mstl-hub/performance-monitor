#include "Page_Screensaver.h"
#include "SBDelay.h"

/*!
  TODO:
    - [ ] Сделать общий скринсайвер

*/

tafcoScreensaver::tafcoScreensaver(Window* window) : IPage(window) { }
void tafcoScreensaver::Init() { }
void tafcoScreensaver::ClickHandl(uint32_t code) {
  // mwindow->current_page = .....
}
void tafcoScreensaver::Loop() {
  if(mwindow == nullptr)
    return;
  if(mwindow->images.GetNameImage() != mwindow->images.img_tafco_home_big)
    mwindow->images.SetImage(mwindow->images.img_tafco_home_big);

  pos_x += 1;
  if(pos_x >= mwindow->display->width) {
    pos_y += 2;
    pos_x  = 0;
  }
  if(pos_y >= (mwindow->display->height - mwindow->images.image_height))
    pos_y = 0;
      
  mwindow->Clear();
  mwindow->images.DrawImage(pos_x, pos_y);
  if(mwindow->display != nullptr) mwindow->display->Update(0,0);
}

VestorScreensaver::VestorScreensaver(Window* window) : IPage(window) {}
void VestorScreensaver::Init() {}
void VestorScreensaver::ClickHandl(uint32_t code) {}
void VestorScreensaver::Loop() {
  if(mwindow == nullptr)
    return;
  if(mwindow->images.GetNameImage() != mwindow->images.img_vestor_big)
    mwindow->images.SetImage(mwindow->images.img_vestor_big);
  /* Установка позиции */
  if(pos_x == 0 || pos_y == 0) {
    pos_x = (256 / 2) - (mwindow->images.GetWidth() / 2);
    pos_y = (64 / 2)  - (mwindow->images.GetHigh() / 2);
    pos_x = pos_x >= 256 ? 0 : pos_x;
    pos_y = pos_y >= 64  ? 0 : pos_y;
  }
     
  mwindow->Clear();
  mwindow->images.DrawImage(pos_x, pos_y);
  if(mwindow->display != nullptr) mwindow->display->Update(0,0);
}
