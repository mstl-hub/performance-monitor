#ifndef _IOB_ABOUT_H_
#define _IOB_ABOUT_H_

  #include <cstdint>
  #include "Window.h"
  #include "IOBoards.h"


  class IOBPageAbout : public IPage {
    /*  
      - имя устройства
      - версия прошивки
      - дата производства
      - сетевой адрес кан шины
    */
    public:
      #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
      /* Переопределение клавиши для текщей страницы */
      typedef enum DEFINE_KEY_ABOUT : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "Информация" };

      UCPrime::Mark               btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      UCPrime::RecordString  records[5] {
        {create_gui_apis_refs, {}, (char*)"Устройство"},
        {create_gui_apis_refs, {}, (char*)"Серийный номер"},
        {create_gui_apis_refs, {}, (char*)"Версия ПО"},
        {create_gui_apis_refs, {}, (char*)"Дата"},
        {create_gui_apis_refs, {}, (char*)"Адрес на CAN шине"}
      };
      UCPrime::Grid uc_mesh {
        create_gui_apis_refs, { {16, 14}, 224, 64-14 }
      };

      struct string_bufs {
        uint8_t  serial[10]    {};
        uint8_t  fw_vers[10]   {};
        uint8_t  date[15]      {};
        uint8_t  can_addr[6]   {};
      } lbl_strings {

      };

      IOBoards::IOBCObject* io_board;

      IOBPageAbout(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };//__class IOBPageAbout
  #define IOBPage_ABOUT (sizeof(IOBPageAbout)) 

#endif //_IOB_PAGE_H_