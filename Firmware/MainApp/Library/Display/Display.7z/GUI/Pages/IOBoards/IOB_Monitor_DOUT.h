#ifndef _IOB_MONITOR_DOUT_H_
#define _IOB_MONITOR_DOUT_H_ 

  #include <cstdint>
  #include "Window.h"
  #include "SBerryConfig.h"
  #include "IOBoards.h"

  class PageIOMonitor_DOUT : public IPage {
    public:
      #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
      /* Переопределение клавиши для текщей страницы */
      typedef enum RootDIRKK : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "Монитор цыфровых выходов" };

      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      UCPrime::tProportion proportion {
        0.38f,//0.4
        1.0f,//1.0
        3.6f,//3.6
        1.0f,//1.0
      };
      // uint32_t dbg_dout_stabs { 0xAAAAAAAA };
      UCPrime::GridBitValues uc_mesh {
        create_gui_apis_refs, {{16, 15}, 224, 50}
      };

      IOBoards::IOBCObject* io_board;

      PageIOMonitor_DOUT(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };

  #define IOBPage_MONITOR_DOUT (sizeof(PageIOMonitor_DOUT))

#endif