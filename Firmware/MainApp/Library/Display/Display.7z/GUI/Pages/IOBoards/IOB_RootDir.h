#ifndef _IOB_ROOTDIR_H_
#define _IOB_ROOTDIR_H_

  #include <cstdint>
  #include "Window.h"

  class PageRootDir : public IPage {
    #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }

    /* Переопределение клавиши для текщей страницы */
    typedef enum RootDIRKK : uint32_t {
      Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
      Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
      Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
      Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
    } tKeyCode;

    UCPrime::Title title { create_gui_apis_refs, { { 0, 0 }, 255, 15 }, "Меню" };

    UCPrime::Mark               btn_marks[4] {
      { create_gui_apis_refs, {{0, 16 - 16/2}, 16, 16}, Images::tImageAlias::img_butt_accept }, 
      { create_gui_apis_refs, {{0, 48 - 16/2}, 16, 16}, Images::tImageAlias::img_butt_back }, 
      { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16}, Images::tImageAlias::img_butt_up }, 
      { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16}, Images::tImageAlias::img_butt_down }, 
    };
    #define BTN_MARKS_Size (sizeof(btn_marks))
    
    UCPrime::Grid               uc_mesh {create_gui_apis_refs, {{16, 14}, 224, 64-14}};

    enum RPG : uint8_t { 
      rpg_debug, 
      rpg_iomon,
      rpg_mbu,
      rpg_wlts,
      rpg_disp,
      rpg_rctrl,
      rpg_pwd,
      rpg_canbus,
      rpg_info,
      rpg_size
    };
    struct ClickButton { 
      UCPrime::Label  label;
      UCPrime::Button<void(*)()>  button;
    }
    click_buttons[RPG::rpg_size] {
      { .label = { create_gui_apis_refs, (char*)"devc" },                 .button = {create_gui_apis_refs } },    /* Отладочная страничка */
      { .label = { create_gui_apis_refs, (char*)"Монитор входов" },       .button = {create_gui_apis_refs } },    /* Для IO-блоков        */
      { .label = { create_gui_apis_refs, (char*)"Статусы MBU" },          .button = {create_gui_apis_refs } },    /* MBU::  Отображение статусов соеденения для главной платы */
      { .label = { create_gui_apis_refs, (char*)"Беспроводные датчики" }, .button = {create_gui_apis_refs } },    /* WLTS:: Поиск и установка датчиков */
      { .label = { create_gui_apis_refs, (char*)"Дисплей" },              .button = {create_gui_apis_refs } },    /* Дисплей */
      { .label = { create_gui_apis_refs, (char*)"Резервное управление" }, .button = {create_gui_apis_refs } },    /* Для платы 2033, настройка резервного управления */
      { .label = { create_gui_apis_refs, (char*)"ПИН-код" },              .button = {create_gui_apis_refs } },    /* Установка пароля для всех, кроме главной платы */
      { .label = { create_gui_apis_refs, (char*)"CAN шина" },             .button = {create_gui_apis_refs } },    /* Настройки can-шины */
      { .label = { create_gui_apis_refs, (char*)"Информация" },           .button = {create_gui_apis_refs } },    /* Отображение текущей информации */
    };
    #define CLICK_BUTTONS_Size (sizeof(click_buttons))

    public:
      PageRootDir(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };

  #define PAGEROOTDIR_Size (sizeof(PageRootDir))

#endif //_IOB_ROOTDIR_H_