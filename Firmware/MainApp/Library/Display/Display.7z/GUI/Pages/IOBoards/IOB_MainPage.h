#ifndef _IOB_MAINPAGE_H_
#define _IOB_MAINPAGE_H_ 

  #include <cstdint>
  #include "Window.h"

  /// @brief Начальная страница для отображения IO платы board_wlts 
  class IOBoards_MainPage : public IPage {
    uint16_t  counter {0};
    // CroptimizRProtocol::AINs*   boards_ains;                      /* Указатель на аналоговые входы io-платы       */
    uint8_t canbus_addr {};
    uint8_t canbus_ioid {};
    const struct PageGrid {
      uint16_t x_column_0 { 0   };  /* Начальная позиция по оси x колонки 0 */
      uint16_t x_column_1 { 64  };  /* Начальная позиция по оси x колонки 1 */
      uint16_t x_column_2 { 128 };  /* Начальная позиция по оси x колонки 2 */
      uint16_t x_column_3 { 192 };  /* Начальная позиция по оси x колонки 3 */
    } page_grid;
    
    public:
      IOBoards_MainPage(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };

  #define BOARDWLTS_MPAGE_SIZE (sizeof(BoardWLTS_MainPage))

#endif //___BOARDWLTS_MAINPAGE_H_