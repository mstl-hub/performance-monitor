#include "IOB_RootDir.h"
#include "UControls.h"
#include "SBerryConfig.h"
#include "IOBoards.h"

using tSBerryBoard = SBerryCore::CFGParam::tSBerryBoard;

PageRootDir::PageRootDir(Window* window) 
  /* Init internal objects:: */
  : IPage(window)
  /* Method:: */ {
  for(uint8_t i = 0; i < RPG::rpg_size; ++i){
    click_buttons[i].button.child_component = &click_buttons[i].label;
  }
  click_buttons[RPG::rpg_debug].button.click_handler  = [](){ Window::GoToPage(Window::PageName::Page_Debugz,       true); };
  click_buttons[RPG::rpg_iomon].button.click_handler  = [](){ Window::GoToPage(Window::PageName::Page_MonitorRoot,  true); };
  click_buttons[RPG::rpg_mbu].button.click_handler    = [](){ Window::GoToPage(Window::PageName::Page_MBU_State,    true); };
  click_buttons[RPG::rpg_pwd].button.click_handler    = [](){ Window::GoToPage(Window::PageName::Page_Password,     true); };
  click_buttons[RPG::rpg_canbus].button.click_handler = [](){ Window::GoToPage(Window::PageName::Page_CANBus,       true); };
  click_buttons[RPG::rpg_rctrl].button.click_handler  = [](){ Window::GoToPage(Window::PageName::Page_RSRControl,   true); };
  click_buttons[RPG::rpg_wlts].button.click_handler   = [](){ Window::GoToPage(Window::PageName::Page_WLTS_Root,    true); };
  click_buttons[RPG::rpg_info].button.click_handler   = [](){ Window::GoToPage(Window::PageName::Page_About,        true); };
  
  uc_mesh.vol_horizontal_line = 1;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.align_h = UCPrime::tHrzAlign::h_align_centr;
  uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;

  uint8_t index { 0 };
  #if 0 /*! DEBUG: */ 
    uc_mesh.components[index++] = &click_buttons[RPG::rpg_iomon].button;
    uc_mesh.components[index++] = &click_buttons[RPG::rpg_wlts].button;
    uc_mesh.components[index++] = &click_buttons[RPG::rpg_canbus].button;
    uc_mesh.components[index++] = &click_buttons[RPG::rpg_pwd].button;
    uc_mesh.components[index++] = &click_buttons[RPG::rpg_info].button;
  #else
  switch (dev_config.conf_prod.tasks.main_board){
    case tSBerryBoard::MainBoard_MBU_PIC:
        // uc_mesh.components[index++] = &click_buttons[RPG::rpg_debug].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_mbu].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_info].button;
        break;
    case tSBerryBoard::MainBoard_IOB_UNITA:
        // uc_mesh.components[index++] = &click_buttons[RPG::rpg_debug].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_iomon].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_pwd].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_canbus].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_info].button;
        break;
    case tSBerryBoard::MainBoard_IOB_UNITB:
        // uc_mesh.components[index++] = &click_buttons[RPG::rpg_debug].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_iomon].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_rctrl].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_canbus].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_pwd].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_info].button;
      break;
    case tSBerryBoard::MainBoard_IOB_WLTS:
        // uc_mesh.components[index++] = &click_buttons[RPG::rpg_debug].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_iomon].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_wlts].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_canbus].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_pwd].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_info].button;
      break;
    default:
        // uc_mesh.components[index++] = &click_buttons[RPG::rpg_debug].button;
        uc_mesh.components[index++] = &click_buttons[RPG::rpg_info].button;
      break;
  }
  #endif
  uc_mesh.volume = index;
  uc_mesh.AlignComponents();
  uc_mesh.index = 0;
  uc_mesh.components[0]->is_brigth = true;
}

void PageRootDir::Init() {

}

void PageRootDir::ClickHandl(uint32_t code) {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
        // WindowTask::GoToPage(WindowTask::PageName::Page_Previous, );
      break;
    case tKeyCode::Key_Up:
        uc_mesh.Previous();
      break;
    case tKeyCode::Key_Down:
        uc_mesh.Next();
      break;
    case tKeyCode::Key_Accept:
        if(uc_mesh.components[uc_mesh.index] != nullptr) {
          ((UCPrime::Button<void(*)()>*)uc_mesh.components[uc_mesh.index])->click_handler();
        }
      break;
    default:
      break;
  }
}

void PageRootDir::Loop() {
  mwindow->Clear();

  title.Draw();
  for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) {
    btn_marks[i].Draw(); 
  }
  uc_mesh.Draw();

  mwindow->display->Update(0,0);
}