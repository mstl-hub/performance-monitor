#include "IOB_CANBus.h"
#include "SBerryConfig.h"
#include "Global_Usings.h"

IOB_PageCANBus::IOB_PageCANBus(Window* window)
  /* Init:: */
  : IPage(window)
  /* Method:: */{
  for(uint8_t i = 0; i < PWD_BTNS_VOL; ++i){
    click_buttons[i].button.child_component = &click_buttons[i].label;
  }
  /* Обработчик нажатия клавиши "установки адреса" */
  click_buttons[IDX_CLBTN::idx_can_addr].button.click_handler = [](Window* win, IOB_PageCANBus* page){
    if(win->password.is_set) {
      if(win->password.is_auth) {
        page->uc_curr_u2dv = &page->uc_canaddr;
        page->fsm_page = FSM_CBUS::fsmcb_entry;
        page->titles = CANBusTitles::cbus_title_set_addr;
      }
      else {
        Window::GoToPage(Window::PageName::Page_CANBus, Window::PageName::Page_PasswordAuth, true);
      }
    }
    else if(!win->password.is_set) {
      page->uc_curr_u2dv = &page->uc_canaddr;
      page->fsm_page = FSM_CBUS::fsmcb_entry;
      page->titles = CANBusTitles::cbus_title_set_addr;
    }
  };
  /* Обработчик нажатия клавиши "установки скорости" */
  click_buttons[IDX_CLBTN::idx_can_brate].button.click_handler = [](Window* win, IOB_PageCANBus* page){
    return;
  };
  
  uc_mesh.vol_horizontal_line = 1;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.align_h = UCPrime::tHrzAlign::h_align_centr;
  uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;

  uint8_t index { 0 };
  uc_mesh.components[index++] = &click_buttons[IDX_CLBTN::idx_can_addr].button;
  uc_mesh.components[index++] = &click_buttons[IDX_CLBTN::idx_can_brate].button;
  
  uc_mesh.volume = index;
  uc_mesh.AlignComponents();
  uc_mesh.index = 0;
  uc_mesh.components[0]->is_brigth = true;

  uc_canaddr.align_h = UCPrime::tHrzAlign::h_align_centr;
  uc_canaddr.align_v = UCPrime::tVrtAlign::v_align_centr;
  uc_lbl_msg.align_h = UCPrime::tHrzAlign::h_align_centr;
  uc_lbl_msg.align_v = UCPrime::tVrtAlign::v_align_centr;

  uc_canaddr.limit_low = 1;
  uc_canaddr.limit_up  = 16;
  uc_canaddr.value     = dev_config.conf_user.io_board.board_addr + 1;
}
void IOB_PageCANBus::Init(){}
void IOB_PageCANBus::ClickHandl(uint32_t code){
  auto click_handl_root   = [&](){
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Back:
          Window::GoToPage(Window::PageName::Page_Root, true);
        break;
      case tKeyCode::Key_Up:
          uc_mesh.Previous();
        break;
      case tKeyCode::Key_Down:
          uc_mesh.Next();
        break;
      case tKeyCode::Key_Accept:
          if(uc_mesh.components[uc_mesh.index] != nullptr) {
            ((UCPrime::Button<void(*)(Window*, IOB_PageCANBus*)>*)uc_mesh.components[uc_mesh.index])->click_handler(mwindow, this);
          }
        break;
      default:
        break;
    }
  };
  auto click_handl_entry  = [&](){
    uint8_t value {};
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Back:
          fsm_page = FSM_CBUS::fsmcb_root;
          titles   = CANBusTitles::cbus_title_root;
        break;
      case tKeyCode::Key_Up:
          if(uc_curr_u2dv != nullptr) uc_curr_u2dv->Increment();
        break;
      case tKeyCode::Key_Down:
          if(uc_curr_u2dv != nullptr) uc_curr_u2dv->Decrement();
        break;
      case tKeyCode::Key_Accept:
          /*! 
            WARNING: Вставить
              - сохранить
              - переинициализировать can
          */
          value = (uc_canaddr.value) & 0xfu;
          if(value > 0)
            value--;
          if(value < 0x10u) {
            dev_config.conf_user.io_board.board_addr = value;
            // dev_config.Save();
            GlobalUsings::request_flash_save = true;
            fsm_can_msg   = FSM_CAN_POPUP_MSG::fsmcan_msg_success;
            IOBoards::TaskIOBoards::ReinitCAN();
          }
          else {
            fsm_can_msg   = FSM_CAN_POPUP_MSG::fsmcan_msg_error;
            uc_canaddr.value = dev_config.conf_user.io_board.board_addr + 1;            
          }
          titles        = CANBusTitles::cbus_title_root;
          fsm_page      = FSM_CBUS::fsmcb_popup_msg;
        break;
      default:
        break;
    }
  };

  switch(fsm_page) {
    case FSM_CBUS::fsmcb_root:
        click_handl_root();
      break;
    case FSM_CBUS::fsmcb_entry:
        click_handl_entry();
      break;
    case FSM_CBUS::fsmcb_popup_msg:
      break;
    default:
      break;
  }
}
void IOB_PageCANBus::Loop(){
  mwindow->Clear();

  title.text = (char*)txt_titles[titles];

  switch(fsm_page){
    case FSM_CBUS::fsmcb_root:
        title.Draw();
        btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_up;
        btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_down;
        for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) btn_marks[i].Draw();
        uc_mesh.Draw();
      break;
    case FSM_CBUS::fsmcb_entry:
        title.Draw();
        btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
        btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_decrement;
        for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) btn_marks[i].Draw();
        uc_canaddr.Draw();//??? uc_curr
      break;
    case FSM_CBUS::fsmcb_popup_msg:

        if(fsm_can_msg == FSM_CAN_POPUP_MSG::fsmcan_msg_error) {
          uc_lbl_msg.text = (char*)txt_popup_msgs[PopupENum::PopUp_Error];
        }
        else if(fsm_can_msg == FSM_CAN_POPUP_MSG::fsmcan_msg_success) {
          uc_lbl_msg.text = (char*)txt_popup_msgs[PopupENum::PopUp_Success];
        }

        uc_lbl_msg.Draw();
        msg_iteration++;
        if(msg_iteration >= IOB_CAN_MSG_ITER) {
          msg_iteration = 0;
          fsm_page = FSM_CBUS::fsmcb_root;
        }
      break;
  }

  mwindow->display->Update(0,0);
}