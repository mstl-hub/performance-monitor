#ifndef _IOB_PASSWORD_H_
  #define _IOB_PASSWORD_H_

  #include <cstdint>
  #include "Window.h"
  #include "SBerryConfig.h"
  #include "IOBoards.h"
  #include "Security.h"

  #define IOB_PWD_MSG_ITER (40)

  class IOB_PasswordRootDir : public IPage {
    #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
    public:
      /* Переопределение клавиши для текщей страницы */
      typedef enum DEFINE_KEY_Settings : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      enum FSM_PWD_ROOT : uint8_t {
        fsmpr_root,         /* корневое меню установки пароля */
        fsmpr_entry,        /* ввод пароля      */
        fsmpr_msg_success,  /* вывод сообщения  */
      } fsm_pr {
        fsmpr_root
      };

      const char* txt_title_pwd     {(char*)"ПИН-код"};
      const char* txt_title_pwd_set {(char*)"Введите ПИН"};
      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, txt_title_pwd };
      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };
      enum BTN_MARK : uint8_t {
        BTN_LU = 0,
        BTN_LD = 1,
        BTN_RU = 2,
        BTN_RD = 3
      };

      const char* txt_pwd_change = (const char*)"Изменить";
      const char* txt_pwd_set    = (const char*)"Установить";
      #define PWD_BTNS_VOL (2)
      struct ClickButton { 
        UCPrime::Label              label;
        UCPrime::Button<void(*)(Window*,IOB_PasswordRootDir*)>  button;
      }
      click_buttons[PWD_BTNS_VOL] {
        { .label = { create_gui_apis_refs, (char*)"Изменить" },      .button = {create_gui_apis_refs } },    /* Отладочная страничка */
        { .label = { create_gui_apis_refs, (char*)"Удалить" },       .button = {create_gui_apis_refs } },    /* Для IO-блоков        */
      };
      #define CLICK_BUTTONS_Size (sizeof(click_buttons))
      enum RPG : uint8_t {
        rpg_pwd_change,
        rpg_pwd_delete,
      };
      UCPrime::Grid         uc_mesh     {create_gui_apis_refs, {{16, 14}, 224, 64-14}};
      UCPrime::U4DPassword  uc_pwd      {create_gui_apis_refs, {{16, 16}, 224, 64-16}};
      UCPrime::Label        uc_lbl_msg  {create_gui_apis_refs, {{16, 16}, 224, 64-16}, (char*)"Успешно"};
      uint16_t              msg_iteration {0};

      IOB_PasswordRootDir(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
      void DrawRoot();
      void DrawEntry();
      void DrawMSG();
  };
  #define PAGE_PasswordRootDir_Size (sizeof(IOB_PasswordRootDir))
  
  class IOB_PasswordAuth : public IPage {
    #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
    public:
      /* Переопределение клавиши для текщей страницы */
      typedef enum DEFINE_KEY_Settings : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;
      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "Авторизация" };
      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };
      enum BTN_MARK : uint8_t {
        BTN_LU = 0,
        BTN_LD = 1,
        BTN_RU = 2,
        BTN_RD = 3
      };

      const char* txt_msg_success         {(char*)"Авторизация успешна"};
      const char* txt_msg_error           {(char*)"Не верно!"};
      const char* txt_msg_reset_success   {(char*)"ПИН-код сброшен"};
      UCPrime::U4DPassword  uc_pwd      {create_gui_apis_refs, {{0, 0}, 255, 64}};
      UCPrime::Label        uc_lbl_msg  {create_gui_apis_refs, {{0, 0}, 255, 64}, (char*)txt_msg_success};

      const char* uc_title_strs[2] {
        (char*)"Для разблокировки",
        (char*)"сообщите в техподдержку"
      };
      UCPrime::Title uc_title_1   { create_gui_apis_refs, {{ 16, 0  }, 224, 14}, (char*)uc_title_strs[0] };
      UCPrime::Title uc_title_2   { create_gui_apis_refs, {{ 16, 14 }, 224, 14}, (char*)uc_title_strs[1] };
      UCPrime::Title uc_title_rst { create_gui_apis_refs, {{ 16, 0  }, 224, 14}, (char*)"Введите код сброса"};
      
      UCPrime::RecordString  uc_records[2] {
        {create_gui_apis_refs, {}, (char*)"Серийный номер"},
        {create_gui_apis_refs, {}, (char*)"Код"},
      };
      UCPrime::Grid uc_mesh {
        create_gui_apis_refs, { {16, 28}, 224, 64-14 }
      };
      struct string_bufs {
        uint8_t  serial[12] {};
        uint8_t  code[12]   {};
      } lbl_strings {
      };

      struct page_pin_codes {
        uint8_t   err_auth_cnt  {}; /* Счетчик неуспешных авторизаций */
        uint32_t  dev_serial    {};
        uint32_t  private_key   {};
        uint32_t  public_key    {};
        SBerryCore::PIN4Reset::pin_code32_t curr_pin  {};   /* Текущий пин-код */
        SBerryCore::PIN4Reset::pin_code32_t rst_pin   {};   /* пин-код сброса  */
      } pin_codes {};

      enum FSM_PWD_AUTH {
        fsmpa_msg_null,
        fsmpa_msg_success,
        fsmpa_msg_error,    
        fsmpa_msg_support,      /* Выдача сообщения и публичного ключа */
        fsmpa_msg_pin_reset,    /* Сброс пароля */
      } fsm_pauth {
        fsmpa_msg_null
      };
      uint16_t msg_iteration {0};

      IOB_PasswordAuth(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };
  #define PAGE_PasswordAuth_Size (sizeof(IOB_PasswordAuth))

#endif//_IOB_PASSWORD_H_