#include "IOB_UB_reserv_ctrl.h"
#include "SBerryConfig.h"
#include "Global_Usings.h"

IOB_Page_UBRsvCtrl::IOB_Page_UBRsvCtrl(Window* window)
  /* Init:: */
  : IPage(window)
  /* Method:: */{
  for(uint8_t i = 0; i < RSV_BTNS_VOL; ++i){
    click_buttons[i].button.child_component = &click_buttons[i].label;
  }
  /* Обработчик нажатия клавиши - установка состояния системы: вкл./выкл. */
  click_buttons[IDX_CLBTN::btn_idx_rsv_set_state].button.click_handler = [](Window* win, IOB_Page_UBRsvCtrl* page){
    auto go = [&](){
      page->page_fsm          = FSM_RSV::fsm_rsv_set_state;
      page->page_title_index  = PAGE_RSV_Titles::rsv_title_set_state;
    };
    if(win->password.is_set) {
      if(win->password.is_auth) {
        go();
      }
      else {
        Window::GoToPage(Window::PageName::Page_RSRControl, Window::PageName::Page_PasswordAuth, true);
      }
    }
    else if(!win->password.is_set) {
      go();
    }
  };
  /* Обработчик нажатия клавиши - установка задержки */
  click_buttons[IDX_CLBTN::btn_idx_rsv_set_delay].button.click_handler = [](Window* win, IOB_Page_UBRsvCtrl* page){
    auto go = [&](){
      page->page_fsm          = FSM_RSV::fsm_rsv_set_timeout;
      page->page_title_index  = PAGE_RSV_Titles::rsv_title_set_tout;
    };
    if(win->password.is_set) {
      if(win->password.is_auth) {
        go();
      }
      else {
        Window::GoToPage(Window::PageName::Page_RSRControl, Window::PageName::Page_PasswordAuth, true);
      }
    }
    else if(!win->password.is_set) {
      go();
    }
  };
  /* Обработчик нажатия клавиши - установка состояний цифровых выходов */
  click_buttons[IDX_CLBTN::btn_idx_rsv_set_digout].button.click_handler = [](Window* win, IOB_Page_UBRsvCtrl* page){
    auto go = [&](){
      page->page_fsm          = FSM_RSV::fsm_rsv_set_bitfield;
      page->page_title_index  = PAGE_RSV_Titles::rsv_title_set_bfield;
    };
    if(win->password.is_set) {
      if(win->password.is_auth) {
        go();
      }
      else {
        Window::GoToPage(Window::PageName::Page_RSRControl, Window::PageName::Page_PasswordAuth, true);
      }
    }
    else if(!win->password.is_set) {
      go();
    }
  };

  uc_mesh.vol_horizontal_line = 1;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.align_h = UCPrime::tHrzAlign::h_align_centr;
  uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;

  uint8_t index { 0 };
  uc_mesh.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_rsv_set_state].button;
  uc_mesh.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_rsv_set_delay].button;
  uc_mesh.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_rsv_set_digout].button;
  uc_mesh.volume = index;
  uc_mesh.AlignComponents();

  uc_mesh.index = 0;
  uc_mesh.components[0]->is_brigth = true;

  uc_delay.align_h    = UCPrime::tHrzAlign::h_align_centr;
  uc_delay.align_v    = UCPrime::tVrtAlign::v_align_centr;
  uc_delay.limit_low  = GLOB_PCFG_MOD_B_RSVCTRL_MINTOUT / 1000;
  uc_delay.limit_up   = GLOB_PCFG_MOD_B_RSVCTRL_MAXTOUT / 1000;
  uc_delay.value      = dev_config.conf_user.reserv.timeout / 1000;

  uc_b_state.align_h      = UCPrime::tHrzAlign::h_align_centr;
  uc_b_state.align_v      = UCPrime::tVrtAlign::v_align_centr;
  uc_b_state.b_str_false  = (char*)lbl_boolean[0];
  uc_b_state.b_str_true   = (char*)lbl_boolean[1];
  uc_b_state.value        = dev_config.conf_user.reserv.is_on;

  uc_bit_mesh_cache              = dev_config.conf_user.reserv.bits_out_relay;
  IOBoards::IOBCObject* io_board = IOBoards::TaskIOBoards::GetDecriptBoard();
  uc_bit_mesh.volume = io_board != nullptr ? io_board->ucrop_iob_descript->quant_douts : 0;
  uc_bit_mesh.vol_horizontal_line = 3;
  uc_bit_mesh.vol_vertical_line   = 4;
  uc_bit_mesh.p_value         = &uc_bit_mesh_cache; //dev_config.conf_user.reserv.bits_out_relay;
  uc_bit_mesh.txt_on          = (char*)"Вкл.";
  uc_bit_mesh.txt_off         = (char*)"Выкл.";
  uc_bit_mesh.txt_separator   = (char*)":";
  uc_bit_mesh.proportion      = &proportion;
  uc_bit_mesh.is_brigth       = true;
  
  uc_lbl_popup_msg.align_h = UCPrime::tHrzAlign::h_align_centr;
  uc_lbl_popup_msg.align_v = UCPrime::tVrtAlign::v_align_centr;
}

void IOB_Page_UBRsvCtrl::Init(){

}

void IOB_Page_UBRsvCtrl::ClickHandl(uint32_t code){
  auto click_handl_root = [&](){
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Back:
          Window::GoToPage(Window::PageName::Page_Root, true);
        break;
      case tKeyCode::Key_Up:
          uc_mesh.Previous();
        break;
      case tKeyCode::Key_Down:
          uc_mesh.Next();
        break;
      case tKeyCode::Key_Accept:
          if(uc_mesh.components[uc_mesh.index] != nullptr) {
            ((UCPrime::Button<void(*)(Window*, IOB_Page_UBRsvCtrl*)>*)uc_mesh.components[uc_mesh.index])->click_handler(mwindow, this);
          }
        break;
      default:
        break;
    }
  };
  auto click_handl_set_state = [&](){
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Back:
          page_fsm          = FSM_RSV::fsm_rsv_root;
          page_title_index  = PAGE_RSV_Titles::rsv_title_root;
          uc_b_state.value  = dev_config.conf_user.reserv.is_on;
        break;
      case tKeyCode::Key_Up:
          uc_b_state.Change();
        break;
      case tKeyCode::Key_Down:
          uc_b_state.Change();
        break;
      case tKeyCode::Key_Accept:
          /* Сохраняем значение в конфигурацию */
          dev_config.conf_user.reserv.is_on = uc_b_state.value;
          // dev_config.Save();
          GlobalUsings::request_flash_save = true;
          /* сообщение - сохранено! */
          page_fsm = FSM_RSV::fsm_rsv_popup_msg;
        break;
      default:
        break;
    }
  };
  auto click_handl_set_delay = [&](){
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Back:
          page_fsm          = FSM_RSV::fsm_rsv_root;
          page_title_index  = PAGE_RSV_Titles::rsv_title_root;
          uc_delay.value    = dev_config.conf_user.reserv.timeout / 1000;
        break;
      case tKeyCode::Key_Up:
          uc_delay.Increment();
        break;
      case tKeyCode::Key_Down:
          uc_delay.Decrement();
        break;
      case tKeyCode::Key_Accept:
          /* Сохраняем значение в конфигурацию */
          dev_config.conf_user.reserv.timeout = (uint32_t)(uc_delay.value * 1000);
          // dev_config.Save();
          GlobalUsings::request_flash_save = true;
          /* сообщение - сохранено! */
          page_fsm = FSM_RSV::fsm_rsv_popup_msg;
        break;
      default:
        break;
    }
  };
  auto click_handl_set_digiout = [&](){
    uint8_t result {};
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Back:
          page_fsm          = FSM_RSV::fsm_rsv_root;
          page_title_index  = PAGE_RSV_Titles::rsv_title_root;
          /* Сохраняем значение в конфигурацию */
          if(memcmp((void*)&uc_bit_mesh_cache, (void*)&dev_config.conf_user.reserv.bits_out_relay, sizeof(uint32_t))){
            dev_config.conf_user.reserv.bits_out_relay = uc_bit_mesh_cache;
            // dev_config.Save();
            GlobalUsings::request_flash_save = true;
            /* сообщение - сохранено! */
            page_fsm = FSM_RSV::fsm_rsv_popup_msg;
          }
          uc_bit_mesh_cache = dev_config.conf_user.reserv.bits_out_relay;
        break;
      case tKeyCode::Key_Up: 
          uc_bit_mesh.NextItem();
        break;
      case tKeyCode::Key_Down:
          uc_bit_mesh.PreviousItem();
        break;
      case tKeyCode::Key_Accept:
          result = (uc_bit_mesh_cache >> uc_bit_mesh.index) & 0x1U;
          if(result) {
            uc_bit_mesh_cache &= ~(1 << uc_bit_mesh.index);
          }
          else {
            uc_bit_mesh_cache |= (1 << uc_bit_mesh.index);
          }
        break;
      default:
        break;
    }
  };

  switch(page_fsm) {
    case FSM_RSV::fsm_rsv_root:         click_handl_root();         break;
    case FSM_RSV::fsm_rsv_set_state:    click_handl_set_state();    break;
    case FSM_RSV::fsm_rsv_set_timeout:  click_handl_set_delay();    break;
    case FSM_RSV::fsm_rsv_set_bitfield: click_handl_set_digiout();  break;
    default: break;
  }
  
}

/// @brief Вернуть кол-во элементов
#define get_qitems(UNIT, ITEM) (sizeof(UNIT)/sizeof(ITEM))

void IOB_Page_UBRsvCtrl::Loop(){
  mwindow->Clear();
  
  auto draw_base = [&](){
    title.text = (char*)txt_titels[page_title_index];
    title.Draw();
    for(uint8_t i = 0; i < get_qitems(btn_marks, UCPrime::Mark); ++i){btn_marks[i].Draw();}
  };

  switch(page_fsm) {
    case FSM_RSV::fsm_rsv_root:
        btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_up;
        btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_down;
        draw_base();
        uc_mesh.Draw();
      break;
    case FSM_RSV::fsm_rsv_set_state:
        draw_base();
        uc_b_state.Draw();
      break;
    case FSM_RSV::fsm_rsv_set_timeout:
        btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
        btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_decrement;
        draw_base();
        uc_delay.Draw();
      break;
    case FSM_RSV::fsm_rsv_set_bitfield:
        btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_rloop;
        btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_lloop;
        draw_base();
        uc_bit_mesh.Draw();
      break;
    case FSM_RSV::fsm_rsv_popup_msg:
        uc_lbl_popup_msg.Draw();
        msg_iteration++;
        if(msg_iteration >= IOB_RSV_MSG_ITER) {
          msg_iteration = 0;
          page_fsm = FSM_RSV::fsm_rsv_root;
        }
      break;
    default: 
    break;
  }

  mwindow->display->Update(0,0);
}