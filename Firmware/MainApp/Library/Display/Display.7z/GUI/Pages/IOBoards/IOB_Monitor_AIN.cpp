#include "IOB_Monitor_AIN.h"

PageIOMonitor_AIN::PageIOMonitor_AIN(Window* window) : IPage(window)
  /* Init internal objects:: */
  /* Method:: */ {
  io_board = IOBoards::TaskIOBoards::GetDecriptBoard();
  
  uc_mesh.vol_horizontal_line = 3;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.align_h = UCPrime::tHrzAlign::h_align_left;
  uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;
  if(io_board != nullptr) {
    uc_mesh.volume = io_board->ucrop_iob_descript->quant_ains;
    for(uint8_t i = 0; i < io_board->ucrop_iob_descript->quant_ains; ++i) {
      uc_mesh.components[i] = &ain_records[i];
      ain_records[i].lbl_separator.text = (char*)":";
      ain_records[i].proportion = &proportion;
    }
    // switch(io_board->board_id) {
    //   case IOBoards::tSPI_IDBoard::SPIidBoard_IO1601:
    //       for(uint8_t i = 0; i < io_board->ucrop_iob_descript->quant_ains; ++i) {
    //         uc_mesh.components[i] = &ain_records[i];
    //         // ain_records[i].p_flt_value = &io_board->ios.analog_inputs.iodata[i].adc_value_v;
    //         // ain_records[i].p_flt_value = &io_board->ios.analog_filter[i].avg;
    //         ain_records[i].lbl_separator.text = (char*)":";
    //         // ain_records[i].image_units = Images::tImageAlias::img_units_10x_grad_celsius;
    //         ain_records[i].proportion = &proportion;
    //       }
    //       // ain_records[12].image_units = Images::tImageAlias::img_units_10x_percent;
    //       // ain_records[13].image_units = Images::tImageAlias::img_units_10x_percent;
    //       // ain_records[14].image_units = Images::tImageAlias::img_units_10x_kg;
    //       // ain_records[15].image_units = Images::tImageAlias::img_units_10x12_ppm;
    //       break;
    //     case IOBoards::tSPI_IDBoard::SPIidBoard_IO2033:
    //       for(uint8_t i = 0; i < io_board->ucrop_iob_descript->quant_ains; ++i) {
    //         uc_mesh.components[i] = &ain_records[i];
    //         // ain_records[i].p_flt_value = &io_board->ios.analog_inputs.iodata[i].adc_value_v;
    //         // ain_records[i].p_flt_value = &io_board->ios.analog_filter[i].avg;
    //         ain_records[i].lbl_separator.text = (char*)":";
    //         // ain_records[i].image_units = Images::tImageAlias::img_units_10x_grad_celsius;
    //         ain_records[i].proportion = &proportion;
    //       }
    //       // ain_records[0].image_units = Images::tImageAlias::img_units_10x_percent;
    //       // ain_records[1].image_units = Images::tImageAlias::img_units_10x_kg;
    //       // ain_records[3].image_units = Images::tImageAlias::img_units_10x12_ppm;  
    //     break;
    //     default:
    //       break;
    // }
  }
  uc_mesh.AlignComponents();
  // uc_mesh.index = 0;
  // uc_mesh.components[0]->is_brigth = true;
}

void PageIOMonitor_AIN::Init() {}

void PageIOMonitor_AIN::ClickHandl(uint32_t code) {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
        Window::GoToPage(Window::PageName::Page_MonitorRoot, true);
      break;
    case tKeyCode::Key_Up:
        uc_mesh.PreviousGroup();
      break;
    case tKeyCode::Key_Down:
        uc_mesh.NextGroup();
      break;
    case tKeyCode::Key_Accept:
      break;
    // [[fallthrough]]; /* break; */
    // case tKeyCode::Key_Back | tKeyCode::Key_Up:    
    //     // for(uint8_t i = 0; i < 16; ++i) { stabs[i] += 100.1; }
    //   break;
    // case tKeyCode::Key_Back | tKeyCode::Key_Down:    
    //     // for(uint8_t i = 0; i < 16; ++i) { stabs[i] -= 100.1; }
    //   break;
    default:
      break;
  }
} 

void PageIOMonitor_AIN::Loop() {
  mwindow->Clear();

  title.Draw();
  for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i){
    btn_marks[i].Draw();
  }

  /* Выставляем результат измерения */
  for(uint8_t i = 0; i < io_board->ucrop_iob_descript->quant_ains; ++i){
    if(((io_board->ios.analog_inputs.w_state >> i) & 0x1)) {
      ain_records[i].p_flt_value  = &io_board->ios.analog_filter[i].avg;
      switch(io_board->ios.analog_inputs.iodata[i].GetDefType()) {
        case CroptimizRProtocol::AINs::tSensType::SensDef_Temp:
            ain_records[i].image_units  = Images::tImageAlias::img_units_10x_grad_celsius;
          break;
        case CroptimizRProtocol::AINs::tSensType::SensDef_HR:
            ain_records[i].image_units  = Images::tImageAlias::img_units_10x_percent;
          break;
        case CroptimizRProtocol::AINs::tSensType::SensDef_CO2:
            ain_records[i].image_units  = Images::tImageAlias::img_units_10x12_ppm;
          break;
        case CroptimizRProtocol::AINs::tSensType::SensDef_Weight:
            ain_records[i].image_units  = Images::tImageAlias::img_units_10x_kg;
          break;
        default:
            ain_records[i].image_units  = Images::tImageAlias::img_null;
          break;
      }
      ain_records[i].none_value   = nullptr;
      ain_records[i].err_value    = nullptr;
      /* Если значение -100, то это ошибка */
      if((*ain_records[i].p_flt_value) <= -90.0f) {
        ain_records[i].p_flt_value  = nullptr;
        ain_records[i].none_value   = value_Err;
        ain_records[i].image_units  = Images::tImageAlias::img_null;
      }
    }
    else {
      ain_records[i].p_flt_value  = nullptr;
      ain_records[i].err_value    = nullptr;
      ain_records[i].none_value   = value_NaN;
      ain_records[i].image_units = Images::tImageAlias::img_null;
    }
  } 

  uc_mesh.Draw();

  mwindow->display->Update(0,0);
}