#include "IOB_DebugPage.h"

#include "GFX.h"
#include "Images.h"
#ifdef GLOB_USE_FREE_RTOS
  extern "C" {
    #include <FreeRTOSConfig.h>
    #include <FreeRTOS.h>
    #include <task.h>
    #include <queue.h>
    #include <timers.h>
    #include <semphr.h>
  }
#endif

using tImageAlias = Images::tImageAlias;      /* Псевдонимы изображений */

#define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }

IOBDebugPage::IOBDebugPage(Window* window) : IPage(window) 
  /*  Methods:: */ {
  pwd.align_h = UCPrime::tHrzAlign::h_align_centr;
  pwd.align_v = UCPrime::tVrtAlign::v_align_centr;
}

void IOBDebugPage::Init() { }

void IOBDebugPage::ClickHandl(uint32_t code) {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
        Window::GoToPage(Window::PageName::Page_Root);
      break;
    case tKeyCode::Key_Up:
        pwd.Increment();
      break;
    case tKeyCode::Key_Down:
        pwd.Decrement();
      break;
    case tKeyCode::Key_Accept:
      pwd.NextDigit();
    break;
    default:
      break;
  }
}

void IOBDebugPage::Loop() {
  mwindow->Clear();

  title.Draw();
  for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) {
    btn_marks[i].Draw();
  }
    
  pwd.Draw();

  mwindow->display->Update(0,0);
}