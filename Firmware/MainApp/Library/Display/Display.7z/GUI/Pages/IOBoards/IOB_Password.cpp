#include "IOB_Password.h"
#include "Global_Usings.h"

#pragma region    [PIN_ROOT]

  IOB_PasswordRootDir::IOB_PasswordRootDir(Window* window)
    /* Init:: */
    : IPage(window)
    /* Method:: */{
    for(uint8_t i = 0; i < PWD_BTNS_VOL; ++i){
      click_buttons[i].button.child_component = &click_buttons[i].label;
    }
    
    click_buttons[0].label.text = mwindow->password.is_set ? (char*)txt_pwd_change : (char*)txt_pwd_set;  

    click_buttons[RPG::rpg_pwd_change].button.click_handler = [](Window* win, IOB_PasswordRootDir* page){ 
      if(win->password.is_set) {
        if(win->password.is_auth) {
          /* Переключаем на изменение пароля */
          page->fsm_pr = FSM_PWD_ROOT::fsmpr_entry;
        }
        else {
          Window::GoToPage(Window::PageName::Page_Password, Window::PageName::Page_PasswordAuth, true);
        }
      }
      else if(!win->password.is_set) {
        page->fsm_pr = FSM_PWD_ROOT::fsmpr_entry;
      }
    };
    click_buttons[RPG::rpg_pwd_delete].button.click_handler = [](Window* win, IOB_PasswordRootDir* page){ 
      /* Window::GoToPage(Window::PageName::Page_MonitorRoot, true); */ 
      if(win->password.is_set) {
        if(win->password.is_auth) {
          /* Удаляем пароль, сохраняем конфигурацию, переключаемся на сообщение */
          memset((void*)&dev_config.conf_user.password_user.pwd, 0, sizeof(dev_config.conf_user.password_user.pwd));
          win->password.is_set = false;
          page->click_buttons[0].label.text = win->password.is_set ? (char*)page->txt_pwd_change : (char*)page->txt_pwd_set;
          /* message: pwd delete success */
          page->fsm_pr = FSM_PWD_ROOT::fsmpr_msg_success;
          /*! 
            TODO: сохраняем конфигурацию */
          // dev_config.Save();
          GlobalUsings::request_flash_save = true;
        }
        else {
          Window::GoToPage(Window::PageName::Page_Password, Window::PageName::Page_PasswordAuth, true);
        }
      }
    };
    
    uc_mesh.vol_horizontal_line = 1;
    uc_mesh.vol_vertical_line   = 4;
    uc_mesh.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;

    uint8_t index { 0 };
    uc_mesh.components[index++] = &click_buttons[RPG::rpg_pwd_change].button;
    uc_mesh.components[index++] = &click_buttons[RPG::rpg_pwd_delete].button;
    
    uc_mesh.volume = index;
    uc_mesh.AlignComponents();
    uc_mesh.index = 0;
    uc_mesh.components[0]->is_brigth = true;

    uc_pwd.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_pwd.align_v = UCPrime::tVrtAlign::v_align_centr;
    uc_lbl_msg.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_lbl_msg.align_v = UCPrime::tVrtAlign::v_align_centr;
  }
  void IOB_PasswordRootDir::Init(){
    
  }
  void IOB_PasswordRootDir::ClickHandl(uint32_t code){
    auto click_handl_root   = [&](){
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            Window::GoToPage(Window::PageName::Page_Root, true);
          break;
        case tKeyCode::Key_Up:
            uc_mesh.Previous();
          break;
        case tKeyCode::Key_Down:
            uc_mesh.Next();
          break;
        case tKeyCode::Key_Accept:
            if(uc_mesh.components[uc_mesh.index] != nullptr) {
              ((UCPrime::Button<void(*)(Window*,IOB_PasswordRootDir*)>*)uc_mesh.components[uc_mesh.index])->click_handler(mwindow, this);
            }
          break;
        default:
          break;
      }
    };
    auto click_handl_entry  = [&](){
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            fsm_pr = FSM_PWD_ROOT::fsmpr_root;
          break;
        case tKeyCode::Key_Up:
            uc_pwd.Increment();
          break;
        case tKeyCode::Key_Down:
            // uc_pwd.Decrement();
            uc_pwd.NextDigit();
          break;
        case tKeyCode::Key_Accept:
            /*! 
              WARNING: Вставить
                - сохранить пароль
                - поменть статус mwindow->pwd ....
            */
            memcpy(
              (void*)&dev_config.conf_user.password_user.pwd, 
              uc_pwd.str_pwd, 
              sizeof(dev_config.conf_user.password_user.pwd)
            );
            mwindow->password.is_set  = true;
            mwindow->password.is_auth = false;
            GlobalUsings::request_flash_save = true;
            click_buttons[0].label.text = mwindow->password.is_set ? (char*)txt_pwd_change : (char*)txt_pwd_set;  
            fsm_pr = FSM_PWD_ROOT::fsmpr_msg_success;
          break;
        default:
          break;
      }
    };

    switch(fsm_pr) {
      case FSM_PWD_ROOT::fsmpr_root:
          click_handl_root();
        break;
      case FSM_PWD_ROOT::fsmpr_entry:
          click_handl_entry();
        break;
      case FSM_PWD_ROOT::fsmpr_msg_success:
        break;
      default:
        break;
    }

  }
  void IOB_PasswordRootDir::Loop(){
    mwindow->Clear();

    switch(fsm_pr) {
      case FSM_PWD_ROOT::fsmpr_root:
          title.text = (char*)txt_title_pwd;
          title.Draw();
          btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_up;
          btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_down;
          // btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
          // btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_rloop;
          for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) btn_marks[i].Draw();
          uc_mesh.Draw();
        break;
      case FSM_PWD_ROOT::fsmpr_entry:
          title.text = (char*)txt_title_pwd_set;
          title.Draw();
          // btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_up;
          // btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_down;
          btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
          btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_rloop;
          for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) btn_marks[i].Draw();
          uc_pwd.Draw();
        break;
      case FSM_PWD_ROOT::fsmpr_msg_success:
          uc_lbl_msg.Draw();
          msg_iteration++;
          if(msg_iteration >= IOB_PWD_MSG_ITER) {
            msg_iteration = 0;
            fsm_pr = FSM_PWD_ROOT::fsmpr_root;
          }
        break;
      default:
        break;
    }

    mwindow->display->Update(0,0);
  }

#pragma endregion [PIN_ROOT] 

#pragma region    [PIN_AUTH]

  IOB_PasswordAuth::IOB_PasswordAuth(Window* window)
    /* Init:: */
    : IPage(window)
    /* Method:: */{
    uc_pwd.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_pwd.align_v = UCPrime::tVrtAlign::v_align_centr;
    uc_lbl_msg.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_lbl_msg.align_v = UCPrime::tVrtAlign::v_align_centr;
    
    uc_mesh.vol_horizontal_line = 1;
    uc_mesh.vol_vertical_line   = 4;
    uc_mesh.align_h = UCPrime::tHrzAlign::h_align_left;
    uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;
    uc_mesh.volume = 2;
    for(uint8_t i = 0; i < uc_mesh.volume; ++i) {
      uc_mesh.components[i]         = &uc_records[i];
      uc_records[i].lbl_separator.text = (char*)"-";
    }
    
    pin_codes.dev_serial  = dev_config.conf_prod.serial.serial;
    pin_codes.private_key = dev_config.conf_user.password_user.private_key;
    memcpy(&pin_codes.curr_pin.data, dev_config.conf_user.password_user.pwd, sizeof(dev_config.conf_user.password_user.pwd)); 
    pin_codes.public_key  = PIN4Reset(pin_codes.dev_serial, pin_codes.private_key, pin_codes.curr_pin).GetPublicCode();
    pin_codes.rst_pin     = PIN4Reset(pin_codes.dev_serial, pin_codes.public_key).GetResetPINCode();
    // encrypted_pin = PIN4crypt((uint32_t)dev_config.conf_prod.serial.serial, dev_config.conf_user.password_user.pwd).GetEncrypt();

    StringConverter::U32ToString((uint8_t*)&lbl_strings.serial, sizeof(lbl_strings.serial), (uint32_t)pin_codes.dev_serial);
    StringConverter::U32ToString((uint8_t*)&lbl_strings.code,   sizeof(lbl_strings.code),   (uint32_t)pin_codes.public_key);
    uc_records[0].lbl_value.text = (char*)&lbl_strings.serial;
    uc_records[1].lbl_value.text = (char*)&lbl_strings.code;

    uc_mesh.AlignComponents();
  }
  void IOB_PasswordAuth::Init(){

  }
  void IOB_PasswordAuth::ClickHandl(uint32_t code){
    if(fsm_pauth == FSM_PWD_AUTH::fsmpa_msg_null) {
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            // Window::GoToPage(Window::PageName::Page_Previous, true);
            Window::GoToPage(Window::PageName::Page_Previous, true);
          break;
        case tKeyCode::Key_Up:
            uc_pwd.Increment();
          break;
        case tKeyCode::Key_Down:
            uc_pwd.NextDigit();
          break;
        case tKeyCode::Key_Accept:
            /* проверка пароля и вывод сообщения */
            if(!memcmp(
              (void*)&dev_config.conf_user.password_user.pwd,
              &uc_pwd.str_pwd,
              sizeof(dev_config.conf_user.password_user.pwd)
            )) {
              mwindow->password.is_auth = true;
              fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_success;
              uc_lbl_msg.text = (char*)txt_msg_success;
            }
            else {
              fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_error;
            }
          break;
        default:
          break;
      }
    }
    else if(fsm_pauth == FSM_PWD_AUTH::fsmpa_msg_support) {
      switch((tKeyCode)code) {
        case tKeyCode::Key_Back:
          Window::GoToPage(Window::PageName::Page_Previous, true);
        break;
        case tKeyCode::Key_Accept:
          fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_pin_reset;
        break;
        default:
        break;
      }
    }
    else if(fsm_pauth == FSM_PWD_AUTH::fsmpa_msg_pin_reset) {
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_support;
          break;
        case tKeyCode::Key_Up:
            uc_pwd.Increment();
          break;
        case tKeyCode::Key_Down:
            uc_pwd.NextDigit();
          break;
        case tKeyCode::Key_Accept:
            /* проверка пароля и вывод сообщения */
            if(!memcmp(
              (void*)&pin_codes.rst_pin.data,
              &uc_pwd.str_pwd,
              sizeof(pin_codes.rst_pin.data)
            )) {
              mwindow->password.is_auth = true;
              mwindow->password.is_set  = false;
              memset(&dev_config.conf_user.password_user.pwd, 0, sizeof(dev_config.conf_user.password_user.pwd));
              dev_config.conf_user.password_user.private_key = PIN4Reset(
                pin_codes.dev_serial, 
                pin_codes.private_key, 
                pin_codes.public_key)
              .GetNewPrivateKey();
              // dev_config.Save();
              GlobalUsings::request_flash_save = true;
              fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_success;
              uc_lbl_msg.text = (char*)txt_msg_reset_success;
            }
            else {
              fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_error;
            }
          break;
        default:
          break;
      }
    }
  }
  void IOB_PasswordAuth::Loop(){
    mwindow->Clear();

    switch(fsm_pauth) {
      case FSM_PWD_AUTH::fsmpa_msg_null:
        title.Draw();
        // btn_marks[BTN_MARK::BTN_RU].image_alias = Images::ImageAlias::img_butt_up;
        // btn_marks[BTN_MARK::BTN_RD].image_alias = Images::ImageAlias::img_butt_down;
        btn_marks[BTN_MARK::BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
        btn_marks[BTN_MARK::BTN_RD].image_alias = Images::ImageAlias::img_butt_rloop;
        for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) btn_marks[i].Draw();
        uc_pwd.Draw();
      break;
      case FSM_PWD_AUTH::fsmpa_msg_success: 
        // uc_lbl_msg.text = (char*)txt_msg_success;
        uc_lbl_msg.Draw();
        msg_iteration++;
        if(msg_iteration >= 100) {
          msg_iteration = 0;
          fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_null;
          Window::GoToPage(Window::PageName::Page_Previous, true);
        }
      break;
      case FSM_PWD_AUTH::fsmpa_msg_error:
        if(pin_codes.err_auth_cnt >= 3) {
          fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_support;
          msg_iteration = 0;
          break;
        }
        uc_lbl_msg.text = (char*)txt_msg_error;
        uc_lbl_msg.Draw();
        msg_iteration++;
        if(msg_iteration >= IOB_PWD_MSG_ITER) {
          pin_codes.err_auth_cnt++;
          msg_iteration = 0;
          fsm_pauth = FSM_PWD_AUTH::fsmpa_msg_null;
        }
      break;
      case FSM_PWD_AUTH::fsmpa_msg_support:
        btn_marks[BTN_MARK::BTN_LD].Draw();
        btn_marks[BTN_MARK::BTN_LU].Draw();
        uc_title_1.Draw();
        uc_title_2.Draw();
        uc_mesh.Draw();
      break;
      case FSM_PWD_AUTH::fsmpa_msg_pin_reset:
        btn_marks[BTN_MARK::BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
        btn_marks[BTN_MARK::BTN_RD].image_alias = Images::ImageAlias::img_butt_rloop;
        for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) btn_marks[i].Draw();
        uc_title_rst.Draw();
        uc_pwd.Draw();
      break;
      default:
      break;
    }

    mwindow->display->Update(0,0);
  }

#pragma endregion [PIN_AUTH]