#ifndef _MBU_STATE_H_
  #define _MBU_STATE_H_

  #include <cstdint>
  #include "Window.h"
  #include "IOBoards.h"

  class MBU_Page_State : public IPage {
    #define IOB_RSV_MSG_ITER (40)
    /*
      
    */
    public:
      #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
      /* Переопределение клавиши для текущей страницы */
      typedef enum DEFINE_KEY_ABOUT : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "Статус системы" };

      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      /*!
        <PAGES:>
          <HEADER:>
            "Связь с контроллером" :=> подключено, неподключено
          </HEADER:>
          <MBODY:>
            <PRERELEASE:>
              Кол-во ошибок,                    _statistics->cnt_error_no_cmd + _statistics->cnt_error_no_read    Убрать
              Кол-во сообщений в приемнике,     _statistics->que_quantity_spi_rx          нужный параметр.- кол-во сообщ. MCURX
              Кол-во сообщений на передачу,     _statistics->que_quantity_spi_tx          нужный параметр.- кол-во сообщ. MCUTX
              Кол-во необработанных сообщений,  _statistics->que_quantity_can_rx          нужный параметр.- кол-во сообщ. CANRX
              Максимальное кол-во сообщений
            </PRERELEASE:>
            <DEBUG:>
              PICuyan::SPILineTask::mbu_debug_errors.
                [vlcanr] .max_vol_can_rx         Кол-во сообщений в очереди CAN-RX                       нужный параметр.- Макс. кол-во сообщ. CANRX
                [vlspir] .max_vol_spi_rx         Кол-во сообщений в очереди SPI_RX                       нужный параметр.- Макс. кол-во сообщ. MCURX
                [vlspit] .max_vol_spi_tx         Кол-во сообщений в очереди SPI_TX                       нужный параметр.- Макс. кол-во сообщ. MCUTX
                [canful] .can_max_stx            Счетчик максимального заполнения CAN_TX                 Убрать.
                [clspi]  .cnt_clear_tx_buffs     Счетчик сервисной команды для очистки буфера spi_tx     Убрать.
                [canrq]  .cnt_can_req_reboot     Счетчик запросов на перезапуск CAN                      нужный параметр.- Кол-во перезапусков CAN.
                [nocmd]  .cnt_no_cmd             Счетчик ошибок "нет команд от главного контроллера"     убрать. -> связанно с "связью с контроллером".
                [nohrt]  .cnt_no_heart_beat      Счетчик ошибок "Перезапуск по истечению heart_beat"     убрать. -> связанно с "связью с контроллером".
                [nord]   .cnt_no_read            Счетчик ошибок "Нет чтения"                             убрать. -> связанно с "связью с контроллером".
                [blck]   .cnt_que_tx_block       Счетчик ошибок "Кол-во блокировок очереди"              убрать. -> связанно с "связью с контроллером".
            </DEBUG:>
            <RELEASE:>
              _statistics->que_quantity_spi_rx          нужный параметр.- [Кол-во сообщ. MCURX] _OR_ [Кол-во сообщений в приемнике]     
              _statistics->que_quantity_spi_tx          нужный параметр.- [Кол-во сообщ. MCUTX] _OR_ [Кол-во сообщений на передачу]  
              _statistics->que_quantity_can_rx          нужный параметр.- [Кол-во сообщ. CANRX] _OR_ [Кол-во необработанных сообщений]  
              PICuyan::SPILineTask::mbu_debug_errors.
                [vlcanr] .max_vol_can_rx         Кол-во сообщений в очереди CAN-RX        нужный параметр.- Макс. кол-во сообщ. CANRX
                [vlspir] .max_vol_spi_rx         Кол-во сообщений в очереди SPI_RX        нужный параметр.- Макс. кол-во сообщ. MCURX
                [vlspit] .max_vol_spi_tx         Кол-во сообщений в очереди SPI_TX        нужный параметр.- Макс. кол-во сообщ. MCUTX
                [canrq]  .cnt_can_req_reboot     Счетчик запросов на перезапуск CAN       нужный параметр.- Кол-во перезапусков CAN.
            </RELEASE:>
          </MBODY:>
        </PAGES:>
      */
      enum rec_index {
        MREC_MCUCON,
        MREC_MAX_CANRX,
        MREC_MAX_MCURX,
        MREC_MAX_MCUTX,
        MREC_RLD_CAN,
        MREC_MCURX,
        MREC_MCUTX,
        MREC_CANRX,
      };
      UCPrime::RecordString  records[8] {
        {create_gui_apis_refs, {}, (char*)"Связь с контроллером"},
        {create_gui_apis_refs, {}, (char*)"Макс. кол-во сообщ. CANRX"},
        {create_gui_apis_refs, {}, (char*)"Макс. кол-во сообщ. MCURX"},
        {create_gui_apis_refs, {}, (char*)"Макс. кол-во сообщ. MCUTX"},
        {create_gui_apis_refs, {}, (char*)"Кол-во перезагрузок CAN"},
        {create_gui_apis_refs, {}, (char*)"Кол-во сообщ. MCURX"},
        {create_gui_apis_refs, {}, (char*)"Кол-во сообщ. MCUTX"},
        {create_gui_apis_refs, {}, (char*)"Кол-во сообщ. CANRX"},
      };
      UCPrime::Grid uc_mesh {
        create_gui_apis_refs, { {16, 14}, 224, 64-14 }
      };
      #define MBU_STATE_RECORDS_SIZE (sizeof(records))

      struct string_bufs {
        const char* conn[2];
        const char* err;
        uint8_t  mcurx[10]      {};
        uint8_t  mcutx[10]      {};
        uint8_t  canrx[10]      {};
        uint8_t  max_canrx[10]  {};
        uint8_t  max_mcurx[10]  {};
        uint8_t  max_mcutx[10]  {};
        uint8_t  rld_can[10]    {};
      } lbl_strings {
        .conn = {"Отсутствует", "Подключено"},
        .err  = "Ошибка"
      };

      MBU_Page_State(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;

  };//__class IOB_Page_WLTS
  #define IOB_PAGE_WLTS_Size (sizeof(MBU_Page_State))

#endif //_MBU_STATE_H_