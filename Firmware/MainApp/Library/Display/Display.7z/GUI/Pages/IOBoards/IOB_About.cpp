#include "IOB_About.h"
#include "SBerryConfig.h"

#ifndef GLOB_FW_VERS
  #define GLOB_FW_VERS ("Неизвестно")
#endif

using tSBerryBoard = SBerryCore::CFGParam::tSBerryBoard;

IOBPageAbout::IOBPageAbout(Window* window) : IPage(window) 
  /* Inits:: */
  /* Method:: */{
  io_board = IOBoards::TaskIOBoards::GetDecriptBoard();
  
  uc_mesh.vol_horizontal_line = 1;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.align_h = UCPrime::tHrzAlign::h_align_left;
  uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;
  uc_mesh.volume = 5;
  for(uint8_t i = 0; i < uc_mesh.volume; ++i) {
    uc_mesh.components[i]         = &records[i];
    records[i].lbl_separator.text = (char*)"-";
  }

  switch (dev_config.conf_prod.tasks.main_board) {
    case tSBerryBoard::MainBoard_MBU_PIC:
        records[0].lbl_value.text = (char*)"MBU";
        uc_mesh.volume = 4; /* Зануляем CAN строку */
      break;
    case tSBerryBoard::MainBoard_IOB_UNITA:
        records[0].lbl_value.text = (char*)"PM-A-1";
      break;
    case tSBerryBoard::MainBoard_IOB_UNITB:
        records[0].lbl_value.text = (char*)"PM-B-1";
      break;
    case tSBerryBoard::MainBoard_IOB_WLTS:
        records[0].lbl_value.text = (char*)"PM-LBS-1";
      break;
    default:
        records[0].lbl_value.text = (char*)"Ошибка";
      break;
  }

  // StringConverter::IntToString()

  StringConverter::IntToString((uint8_t*)&lbl_strings.serial, sizeof(lbl_strings.serial), (int32_t)dev_config.conf_prod.serial.serial);
  StringConverter::IntToString((uint8_t*)&lbl_strings.can_addr, sizeof(lbl_strings.can_addr), (int32_t)dev_config.conf_user.io_board.board_addr + 1);
  
  int32_t tmp_var {};
  uint8_t tmp_len {};
    tmp_var = dev_config.conf_prod.date.day;
    StringConverter::IntToString((uint8_t*)&lbl_strings.date, sizeof(lbl_strings.date), tmp_var);
    tmp_len = strlen((char*)lbl_strings.date);
    lbl_strings.date[tmp_len] = '.';
    tmp_len++;
    
    tmp_var = dev_config.conf_prod.date.month;
    StringConverter::IntToString((uint8_t*)&lbl_strings.date[tmp_len], sizeof(lbl_strings.date) - tmp_len, tmp_var);
    tmp_len = strlen((char*)lbl_strings.date);
    lbl_strings.date[tmp_len] = '.';
    tmp_len++;
    
    tmp_var = dev_config.conf_prod.date.year;
    StringConverter::IntToString((uint8_t*)&lbl_strings.date[tmp_len], sizeof(lbl_strings.date) - tmp_len, tmp_var);


  records[1].lbl_value.text = (char*)&lbl_strings.serial;
  records[2].lbl_value.text = (char*)GLOB_FW_VERS;
  records[3].lbl_value.text = (char*)&lbl_strings.date;
  records[4].lbl_value.text = (char*)&lbl_strings.can_addr;

  uc_mesh.AlignComponents();
}

void IOBPageAbout::Init() {
}

void IOBPageAbout::ClickHandl(uint32_t code) {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
        Window::GoToPage(Window::PageName::Page_Root, true);
      break;
    case tKeyCode::Key_Up:
        uc_mesh.PreviousGroup();
      break;
    case tKeyCode::Key_Down:
        uc_mesh.NextGroup();
      break;
    case tKeyCode::Key_Accept:
      break;
    default:
      break;
  }
}

void IOBPageAbout::Loop() {
  mwindow->Clear();
  title.Draw();
  for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i){
    btn_marks[i].Draw();
  }
  uc_mesh.Draw();
  mwindow->display->Update(0,0);
}