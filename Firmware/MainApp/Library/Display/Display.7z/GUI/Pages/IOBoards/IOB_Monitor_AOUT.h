#ifndef _IOB_MONITOR_AOUT_H_
#define _IOB_MONITOR_AOUT_H_ 

  #include <cstdint>
  #include "Window.h"
  #include "SBerryConfig.h"
  #include "IOBoards.h"

  class PageIOMonitor_AOUT : public IPage {
    public:
      #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
      /* Переопределение клавиши для текщей страницы */
      typedef enum RootDIRKK : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "Монитор аналоговых выходов" };

      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      UCPrime::tProportion proportion {
        0.45f,
        1.0f,
        2.0f,
        1.0f,
      };

      float stabs[16] {
        0.625f, 1.2f, 2.435f, 4.875f, 6.5f, 7.0f, 7.675f, 9.125f, 10.0f
      };
      UCPrime::RecordValue  ain_records[16] {
        {create_gui_apis_refs, {}, (char*)"1"},
        {create_gui_apis_refs, {}, (char*)"2"},
        {create_gui_apis_refs, {}, (char*)"3"},
        {create_gui_apis_refs, {}, (char*)"4"},
        {create_gui_apis_refs, {}, (char*)"5"},
        {create_gui_apis_refs, {}, (char*)"6"},
        {create_gui_apis_refs, {}, (char*)"7"},
        {create_gui_apis_refs, {}, (char*)"8"},
        {create_gui_apis_refs, {}, (char*)"9"},
        {create_gui_apis_refs, {}, (char*)"10"},
        {create_gui_apis_refs, {}, (char*)"11"},
        {create_gui_apis_refs, {}, (char*)"12"},
        {create_gui_apis_refs, {}, (char*)"13"},
        {create_gui_apis_refs, {}, (char*)"14"},
        {create_gui_apis_refs, {}, (char*)"15"},
        {create_gui_apis_refs, {}, (char*)"16"},
      };
      UCPrime::Grid uc_mesh {
        create_gui_apis_refs, { {16, 14}, 224, 64-14 }
      };

      IOBoards::IOBCObject* io_board;

      PageIOMonitor_AOUT(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };

  #define IOBPage_MONITOR_AOUT (sizeof(PageIOMonitor_AOUT))

#endif