#ifndef _IOB_SETTINGS_H_
#define _IOB_SETTINGS_H_

  #include <cstdint>
  #include "Window.h"
  #include "SBerryConfig.h"
  #include "IOBoards.h"

  class IOB_SettingsPage : public IPage {
    public:
      #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
      /* Переопределение клавиши для текщей страницы */
      typedef enum DEFINE_KEY_Settings : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "Настройки" };

      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      #define USER_BUTTONS (2) /* Количество элементов */
      UCPrime::Label labels[USER_BUTTONS] {
        { create_gui_apis_refs, (char*)"Пароль"},
        { create_gui_apis_refs, (char*)"Адрес" },
        // {create_gui_apis_refs, (char*)"Дисплей"},
      };             
      UCPrime::Button<void(*)()>  buttons[USER_BUTTONS] {
        {create_gui_apis_refs, (UCPrime::Component*)&labels[0]},
        {create_gui_apis_refs, (UCPrime::Component*)&labels[1]},
      };

      IOB_SettingsPage(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };
  #define PAGE_IOSettings_Size (sizeof(IOB_SettingsPage))

#endif //_IOB_SETTINGS_H_