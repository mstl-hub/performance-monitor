#include "IOB_Monitor_DOUT.h"

PageIOMonitor_DOUT::PageIOMonitor_DOUT(Window* window) : IPage(window)
/* Init internal objects:: */
/* Method:: */ {
  io_board = IOBoards::TaskIOBoards::GetDecriptBoard();
  
  uc_mesh.volume = io_board != nullptr ? io_board->ucrop_iob_descript->quant_douts : 0;
  
  uc_mesh.vol_horizontal_line = 3;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.p_value   = io_board != nullptr ? &io_board->ios.digital_outputs.value : nullptr;
  uc_mesh.txt_on    = (char*)"Вкл.";
  uc_mesh.txt_off   = (char*)"Выкл.";
  uc_mesh.txt_separator = (char*)":";
  uc_mesh.proportion    = &proportion;
}

void PageIOMonitor_DOUT::Init() {}

void PageIOMonitor_DOUT::ClickHandl(uint32_t code) {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
        Window::GoToPage(Window::PageName::Page_MonitorRoot, true);
      break;
    case tKeyCode::Key_Up:
        uc_mesh.PreviousGroup();
      break;
    case tKeyCode::Key_Down:
        uc_mesh.NextGroup();
      break;
    case tKeyCode::Key_Accept:
      break;
    // case tKeyCode::Key_Back | tKeyCode::Key_Up:  
    //   break;
    // case tKeyCode::Key_Back | tKeyCode::Key_Down:
    //   break;
    default:
      break;
  }
} 

void PageIOMonitor_DOUT::Loop() {
  mwindow->Clear();

  title.Draw();
  for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) {
    btn_marks[i].Draw();
  }
  uc_mesh.Draw();

  mwindow->display->Update(0,0);
}