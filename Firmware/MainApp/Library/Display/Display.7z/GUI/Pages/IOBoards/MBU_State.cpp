#include "MBU_State.h"
#include "PICTransport.h"

MBU_Page_State::MBU_Page_State(Window* window)
  /* Init:: */
  : IPage(window)
  /* Method:: */{

  uc_mesh.vol_horizontal_line = 1;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.align_h = UCPrime::tHrzAlign::h_align_left;
  uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;
  uc_mesh.volume = 5;
  for(uint8_t i = 0; i < uc_mesh.volume; ++i) {
    uc_mesh.components[i]         = &records[i];
    records[i].lbl_separator.text = (char*)"-";
    records[i].proportion         = 1.4f;
  }

  records[rec_index::MREC_MCUCON].lbl_value.text = (char*)lbl_strings.conn[0];
  records[rec_index::MREC_MCURX].lbl_value.text = (char*)&lbl_strings.mcurx;
  records[rec_index::MREC_MCUTX].lbl_value.text = (char*)&lbl_strings.mcutx;
  records[rec_index::MREC_CANRX].lbl_value.text = (char*)&lbl_strings.canrx;
  records[rec_index::MREC_RLD_CAN].lbl_value.text = (char*)&lbl_strings.rld_can;
  records[rec_index::MREC_MAX_CANRX].lbl_value.text = (char*)&lbl_strings.max_canrx;
  records[rec_index::MREC_MAX_MCURX].lbl_value.text = (char*)&lbl_strings.max_mcurx;
  records[rec_index::MREC_MAX_MCUTX].lbl_value.text = (char*)&lbl_strings.max_mcutx;

  uc_mesh.AlignComponents();
}
void MBU_Page_State::Init() {}
void MBU_Page_State::ClickHandl(uint32_t code){
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
      Window::GoToPage(Window::PageName::Page_Root, true);
    break;
    case tKeyCode::Key_Up:
      uc_mesh.PreviousGroup();
    break;
    case tKeyCode::Key_Down:
      uc_mesh.NextGroup();
    break;
    case tKeyCode::Key_Accept:
    break;
    default:
      break;
  }
}
void MBU_Page_State::Loop(){
  auto str_convert = [&](uint8_t* out_buffs, uint16_t length, int32_t value) -> char*
  {
    char* result { nullptr };
    if(StringConverter::IntToString(out_buffs, length, value)){
      result = (char*)out_buffs;
    }
    else {
      result = (char*)lbl_strings.err;
    }
    return result;
  }; 

  mwindow->Clear();

  PICuyan::SPILineTask::tStatistics* _statistics = PICuyan::SPILineTask::GetStatistic();
  records[rec_index::MREC_MCUCON].lbl_value.text = (char*)lbl_strings.conn[_statistics->is_connect];

  // records[rec_index::MREC_MCURX].lbl_value.text     = str_convert(lbl_strings.mcurx, sizeof(lbl_strings.mcurx), _statistics->que_spi_rx);
  // records[rec_index::MREC_MCUTX].lbl_value.text     = str_convert(lbl_strings.mcutx, sizeof(lbl_strings.mcutx), _statistics->que_spi_tx);
  // records[rec_index::MREC_CANRX].lbl_value.text     = str_convert(lbl_strings.canrx, sizeof(lbl_strings.canrx), _statistics->que_can_rx);
  records[rec_index::MREC_MAX_CANRX].lbl_value.text = str_convert(lbl_strings.max_canrx, sizeof(lbl_strings.max_canrx), _statistics->que_quantity_can_rx);
  records[rec_index::MREC_MAX_MCURX].lbl_value.text = str_convert(lbl_strings.max_mcurx, sizeof(lbl_strings.max_mcurx), _statistics->que_quantity_spi_rx);
  records[rec_index::MREC_MAX_MCUTX].lbl_value.text = str_convert(lbl_strings.max_mcutx, sizeof(lbl_strings.max_mcutx), _statistics->que_quantity_spi_tx);
  records[rec_index::MREC_RLD_CAN].lbl_value.text   = str_convert(lbl_strings.rld_can, sizeof(lbl_strings.rld_can), _statistics->reboot_can_rx);
  
  title.Draw();
  for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) { btn_marks[i].Draw(); }
  uc_mesh.Draw();

  mwindow->display->Update(0,0);
}