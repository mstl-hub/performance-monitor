#include "IOB_Monitor.h"
#include "SBerryConfig.h"
#include "IOBoards.h"

PageIOMonitor::PageIOMonitor(Window* window) : IPage(window)
  /* Initialize internals gui object:: */
  /* Methods:: */ {
  btn_goto_page_ains.click_handler  = [](){ Window::GoToPage(Window::PageName::Page_Monitor_AIN, true); };
  btn_goto_page_dins.click_handler  = [](){ Window::GoToPage(Window::PageName::Page_Monitor_DIN, true); };
  btn_goto_page_aouts.click_handler = [](){ Window::GoToPage(Window::PageName::Page_Monitor_AOUT, true); };
  btn_goto_page_douts.click_handler = [](){ Window::GoToPage(Window::PageName::Page_Monitor_DOUT, true); };

  // dev_config.conf_prod.conf_product.tasks.board_id_spi == SBerryCore::tMooij_idboard::SPIidBoard_IO0616;

  IOBoards::IOBCObject* io_board = IOBoards::TaskIOBoards::GetDecriptBoard();

  uc_mesh.vol_horizontal_line = 1;
  uc_mesh.vol_vertical_line   = 4;
  uc_mesh.align_h = UCPrime::tHrzAlign::h_align_centr;
  uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;
  uint8_t index {0};
  if(io_board != nullptr && io_board->ucrop_iob_descript->quant_ains > 0) {
    uc_mesh.components[index++] = &btn_goto_page_ains;
    uc_mesh.volume++;
  }
  if(io_board != nullptr && io_board->ucrop_iob_descript->quant_dins > 0) {
    uc_mesh.components[index++] = &btn_goto_page_dins;
    uc_mesh.volume++;
  }
  if(io_board != nullptr && io_board->ucrop_iob_descript->quant_aouts > 0) {
    uc_mesh.components[index++] = &btn_goto_page_aouts;
    uc_mesh.volume++;
  }
  if(io_board != nullptr && io_board->ucrop_iob_descript->quant_douts > 0) {
    uc_mesh.components[index++] = &btn_goto_page_douts;
    uc_mesh.volume++;
  }
  uc_mesh.AlignComponents();
  uc_mesh.index = 0;
  uc_mesh.components[0]->is_brigth = true;
}

void PageIOMonitor::Init() {}

void PageIOMonitor::ClickHandl(uint32_t code) {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
        Window::GoToPage(Window::PageName::Page_Root, true);
      break;
    case tKeyCode::Key_Up:
        uc_mesh.Previous();
      break;
    case tKeyCode::Key_Down:
        uc_mesh.Next();
      break;
    case tKeyCode::Key_Accept:
        if(uc_mesh.components[uc_mesh.index] != nullptr) {
          ((UCPrime::Button<void(*)()>*)uc_mesh.components[uc_mesh.index])->click_handler();
        }
      break;
    default:
      break;
  }
} 

void PageIOMonitor::Loop() {
  mwindow->Clear();

  title.Draw();
  for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i) {
    btn_marks[i].Draw();
  }
  uc_mesh.Draw();

  mwindow->display->Update(0,0);
}