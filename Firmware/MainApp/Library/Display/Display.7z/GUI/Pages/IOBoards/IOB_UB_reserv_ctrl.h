#ifndef _IOB_UB_RESERV_CTRL_H_
  #define _IOB_UB_RESERV_CTRL_H_

  #include <cstdint>
  #include "Window.h"
  #include "IOBoards.h"

  class IOB_Page_UBRsvCtrl : public IPage {
    #define IOB_RSV_MSG_ITER (40)
    /*
      - включить.   ва
      - таймаут.    ва
      - битовое поле состояний
    */
    public:
      #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
      /* Переопределение клавиши для текщей страницы */
      typedef enum DEFINE_KEY_ABOUT : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      /// @brief FSM для текущей страницы
      enum FSM_RSV : uint8_t {
        fsm_rsv_root,
        fsm_rsv_set_state,
        fsm_rsv_set_timeout,
        fsm_rsv_set_bitfield,
        fsm_rsv_popup_msg,
      } page_fsm {
        fsm_rsv_root
      };

      /// @brief Текущий индекс заголовка
      enum PAGE_RSV_Titles : uint8_t {
        rsv_title_root,
        rsv_title_set_state,
        rsv_title_set_tout,
        rsv_title_set_bfield,
      } page_title_index {
        rsv_title_root
      };
      const char* txt_titels[4] {
        (char*)"Резервное управление",
        (char*)"Установите статус",
        (char*)"Установите задержку срабатывания, с",
        (char*)"Установите состояния цифровых выходов",
      };

      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, txt_titels[PAGE_RSV_Titles::rsv_title_root] };

      /// @brief Индексы кнопок в btn_marks
      enum BTN_MARK : uint8_t {
        BTN_LU = 0,
        BTN_LD = 1,
        BTN_RU = 2,
        BTN_RD = 3
      };
      UCPrime::Mark               btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      #define RSV_BTNS_VOL (3)
      /// @brief Индексы click_buttons
      enum IDX_CLBTN : uint8_t {
        btn_idx_rsv_set_state,
        btn_idx_rsv_set_delay,
        btn_idx_rsv_set_digout,
      };
      struct ClickButton {
        UCPrime::Label                                          label;
        UCPrime::Button<void(*)(Window*, IOB_Page_UBRsvCtrl*)>  button;
      }
      click_buttons[RSV_BTNS_VOL] {
        {.label = {create_gui_apis_refs, (char*)"Статус"},          .button = {create_gui_apis_refs}},    /*  */
        {.label = {create_gui_apis_refs, (char*)"Задержка"},        .button = {create_gui_apis_refs}},    /*  */
        {.label = {create_gui_apis_refs, (char*)"Цифровые выходы"}, .button = {create_gui_apis_refs}},    /*  */
      };
      #define CLICK_BUTTONS_Size (sizeof(click_buttons))

      /* 
        Компоненты:
          - включить - отключить
          - установка задержки UCPrime::UMDValue
          - установка состояний цифровых выходов
      */

      uint32_t              uc_bit_mesh_cache {};
      UCPrime::tProportion proportion {
        0.38f,//0.4
        1.0f,//1.0
        3.6f,//3.6
        1.0f,//1.0
      };
      UCPrime::Grid         uc_mesh       {create_gui_apis_refs, {{16, 14}, 224, 64-14}};
      UCPrime::UBoolValue   uc_b_state    {create_gui_apis_refs, {{16, 16}, 224, 64-16}};     /* статус системыЖ вкл/выкл */
      const char* lbl_boolean[2] {
        (char*)"Выключено",
        (char*)"Включено",
      };
      UCPrime::UMDValue       uc_delay     {create_gui_apis_refs, {{16, 16}, 224, 64-16}};     /* в конфигурации [мс], у нас [с] */
      UCPrime::GridBitValues  uc_bit_mesh  {create_gui_apis_refs, {{16, 15}, 224, 50}};        /* Сетка с цифровыми значениями */

      UCPrime::Label    uc_lbl_popup_msg  {create_gui_apis_refs, {{16, 16}, 224, 64-16}, (char*)"Параметры сохранены!"};   /* Текст всплывающего сообщения */
      uint16_t          msg_iteration     {0};    /* Кол-во итер-й цикла для отображения всплывающего сообщения */

      IOB_Page_UBRsvCtrl(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };//__class IOB_Page_UBRsvCtrl
  #define IOBPage_UBReservCtrl (sizeof(IOB_Page_UBRsvCtrl)) 

#endif//_IOB_UB_RESERV_CTRL_H_