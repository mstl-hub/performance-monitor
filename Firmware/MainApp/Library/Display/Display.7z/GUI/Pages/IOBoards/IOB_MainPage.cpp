#include "IOB_MainPage.h"

#include "GFX.h"
#include "SBerryBoard.h"
#include "SBDelay.h"
#include "Images.h"
#include "IOBoards.h"
#include "SBerryConfig.h"

using tImageAlias = Images::tImageAlias;      /* Псевдонимы изображений */

IOBoards_MainPage::IOBoards_MainPage(Window* window) : IPage(window) { }

void IOBoards_MainPage::Init() {
  // window->display_memory;
  // AINS = UnitALineTasl.GetPtrAnalogInputs()
  // boards_ains = UnitWLTS_Line::UnitWLTSLineTask::GetAInsPointer();
  // StringConverter::
}

void IOBoards_MainPage::ClickHandl(uint32_t code)  { }

void IOBoards_MainPage::Loop() {
  mwindow->Clear();

  /* Раскидываем значения с AINS */
  uint8_t   num_label[15] { };
  uint8_t   y_high = 0;
  char*     rus_string      = StringConverter::UTF8ToCP1251("ТЕСТ");
  uint16_t  rus_string_len  = mwindow->font.GetWidth(rus_string);
  mwindow->font.DrawText(rus_string, (256 / 2) - (rus_string_len / 2) , y_high, 1);


  rus_string      = StringConverter::UTF8ToCP1251("Сетевой адрес: ");
  rus_string_len  = mwindow->font.GetWidth(rus_string);
  y_high += mwindow->font.GetHigh();
  mwindow->font.DrawText(rus_string, 19, y_high, 1);
  // StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), IOBoards::prod_config.board_addr + 1);
  StringConverter::IntToString((uint8_t*)num_label, sizeof(num_label), dev_config.conf_user.io_board.board_addr + 1);
  mwindow->font.DrawText((char*)num_label, 19 + rus_string_len, y_high, 1);

  mwindow->gfx.DrawVLine(16, 0, 63, 1);
  mwindow->gfx.DrawHLine(31, 0, 16, 1);
  mwindow->gfx.DrawHLine(32, 0, 16, 1);
  mwindow->images.SetImage(tImageAlias::img_butt_accept);
  mwindow->images.DrawImage(0, 16 - mwindow->images.GetHigh()/2);
  mwindow->images.SetImage(tImageAlias::img_butt_back);
  mwindow->images.DrawImage(0, 48 - mwindow->images.GetHigh()/2);
  
  mwindow->gfx.DrawVLine(256-16, 0, 63, 1);
  mwindow->gfx.DrawHLine(31, 256-16, 255, 1);
  mwindow->gfx.DrawHLine(32, 256-16, 255, 1);
  mwindow->images.SetImage(tImageAlias::img_butt_up);
  mwindow->images.DrawImage(256-16, 16 - mwindow->images.GetHigh()/2);
  mwindow->images.SetImage(tImageAlias::img_butt_down);
  mwindow->images.DrawImage(256-16, 48 - mwindow->images.GetHigh()/2);

  mwindow->display->Update(0,0);
}