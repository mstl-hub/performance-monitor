#ifndef _IOB_CANBUS_H_
  #define _IOB_CANBUS_H_

  #include <cstdint>
  #include "Window.h"
  #include "IOBoards.h"

  #define IOB_CAN_MSG_ITER (40)

  class IOB_PageCANBus : public IPage {
    #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
    public:
      /* Переопределение клавиши для текщей страницы */
      typedef enum DEFINE_KEY_Settings : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      /// @brief Главный FSM для страницы 
      enum FSM_CBUS : uint8_t {
        fsmcb_root,         /* корневое меню установки пароля */
        fsmcb_entry,        /* ввод             */
        fsmcb_popup_msg,    /* вывод сообщения  */
      } fsm_page {
        fsmcb_root
      };
      /// @brief FSM для popup message
      enum FSM_CAN_POPUP_MSG {
        fsmcan_msg_null,
        fsmcan_msg_success,
        fsmcan_msg_error
      } fsm_can_msg {
        fsmcan_msg_null
      };

      /// @brief Индексы заголовков
      enum CANBusTitles : uint8_t {
        cbus_title_root,
        cbus_title_set_addr,
        cbus_title_set_brate,
      } titles {
        cbus_title_root
      };
      const char* txt_titles[3] {
        (char*)"CAN шина",
        (char*)"Установите адрес",
        (char*)"Установите скорость",
      };
      UCPrime::Title title {create_gui_apis_refs, {{ 16, 0 }, 224, 14}, txt_titles[titles]};
      
      /// @brief Индексы кнопок в btn_marks
      enum BTN_MARK : uint8_t {
        BTN_LU = 0,
        BTN_LD = 1,
        BTN_RU = 2,
        BTN_RD = 3
      };
      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      #define PWD_BTNS_VOL (2)
      /// @brief Индексы click_buttons
      enum IDX_CLBTN : uint8_t {
        idx_can_addr,
        idx_can_brate,
      };
      struct ClickButton {
        UCPrime::Label                                      label;
        UCPrime::Button<void(*)(Window*, IOB_PageCANBus*)>  button;
      }
      click_buttons[PWD_BTNS_VOL] {
        {.label = {create_gui_apis_refs, (char*)"Адрес"},     .button = {create_gui_apis_refs}},    /*  */
        {.label = {create_gui_apis_refs, (char*)"Скорость"},  .button = {create_gui_apis_refs}},    /*  */
      };
      #define CLICK_BUTTONS_Size (sizeof(click_buttons))

      UCPrime::Grid         uc_mesh         {create_gui_apis_refs, {{16, 14}, 224, 64-14}};
      UCPrime::UMDValue*    uc_curr_u2dv    {nullptr};
      UCPrime::UMDValue     uc_canaddr      {create_gui_apis_refs, {{16, 16}, 224, 64-16}};
      
      enum PopupENum : uint8_t {
        PopUp_Success,
        PopUp_Error,
      };
      const char* txt_popup_msgs[2] {
        (char*)"Успешно",
        (char*)"Ошибка",
      };
      UCPrime::Label        uc_lbl_msg      {create_gui_apis_refs, {{16, 16}, 224, 64-16}, (char*)txt_popup_msgs[PopupENum::PopUp_Success]};   /* Текст всплывающего сообщения */
      uint16_t              msg_iteration   {0};    /* Кол-во итер-й цикла для отображения всплывающего сообщения */

      IOB_PageCANBus(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };
  #define PAGE_CANBusPage_Size (sizeof(IOB_PageCANBus))

#endif//_IOB_PASSWORD_H_