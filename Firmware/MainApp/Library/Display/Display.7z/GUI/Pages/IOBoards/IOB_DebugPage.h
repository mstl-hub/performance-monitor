#ifndef _IOB_DEBUGPAGE_H_
#define _IOB_DEBUGPAGE_H_

  #include <cstdint>
  #include "Window.h"
  #include "Images.h"
  #include <functional>   // для std::function  std::mem_fn

  class IOBDebugPage : public IPage {
      #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images } 
    public:
      /* Переопределение клавиши для текщей страницы */
      typedef enum RootDIR : uint32_t {
        Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
        Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
        Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
        Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
      } tKeyCode;

      UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "debug_page" };
      UCPrime::Mark btn_marks[4] {
        { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
        { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
        { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
        { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
      };

      
      UCPrime::U4DPassword pwd { create_gui_apis_refs, {{ 16, 16 }, 224, 64-16} };


      IOBDebugPage(Window* window);
      virtual void Init() override;
      virtual void ClickHandl(uint32_t code) override;
      virtual void Loop() override;
  };
  #define IOBDebugPageSize (sizeof(IOBDebugPage)) 

#endif //__IOB_DEBUGPAGE_H_