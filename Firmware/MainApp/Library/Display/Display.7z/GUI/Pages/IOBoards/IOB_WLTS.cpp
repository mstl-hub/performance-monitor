#include "IOB_WLTS.h"
#include "SBerryConfig.h"
#include "Global_Usings.h"

#pragma region    [PAGE_ROOT]

  IOB_Page_WLTS_Root::IOB_Page_WLTS_Root(Window* window)
  /* Inits::*/
    : IPage(window)
  /* Methods::*/{
    for(uint8_t i = 0; i < WLTS_ROOT_BTNS_VOL; ++i){
      click_buttons[i].button.child_component = &click_buttons[i].label;
    }
    /* Обработчик нажатия клавиши -  */
    click_buttons[IDX_CLBTN::btn_idx_wlts_sens].button.click_handler = [](Window* win){
      Window::GoToPage(Window::PageName::Page_WLTS_Sens, true);
    };
    /* Обработчик нажатия клавиши -  */
    click_buttons[IDX_CLBTN::btn_idx_wlts_search].button.click_handler = [](Window* win){
      Window::GoToPage(Window::PageName::Page_WLTS_Search, true);
    };
    uc_mesh.vol_horizontal_line = 1;
    uc_mesh.vol_vertical_line   = 4;
    uc_mesh.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_mesh.align_v = UCPrime::tVrtAlign::v_align_up;

    uint8_t index { 0 };
    uc_mesh.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wlts_sens].button;
    uc_mesh.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wlts_search].button;
    uc_mesh.volume = index;
    uc_mesh.AlignComponents();

    uc_mesh.index = 0;
    uc_mesh.components[0]->is_brigth = true;
  }
  void IOB_Page_WLTS_Root::Init(){

  }
  void IOB_Page_WLTS_Root::ClickHandl(uint32_t code){
    switch ((tKeyCode)code) {
      case tKeyCode::Key_Back:
          Window::GoToPage(Window::PageName::Page_Root, true);
        break;
      case tKeyCode::Key_Up:
          uc_mesh.Previous();
        break;
      case tKeyCode::Key_Down:
          uc_mesh.Next();
        break;
      case tKeyCode::Key_Accept:
          if(uc_mesh.components[uc_mesh.index] != nullptr) {
            ((UCPrime::Button<void(*)(Window*)>*)uc_mesh.components[uc_mesh.index])->click_handler(mwindow);
          }
        break;
      default:
        break;
    }
  }
  void IOB_Page_WLTS_Root::Loop(){
    mwindow->Clear();

    title.Draw();
    for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i){btn_marks[i].Draw();}
    uc_mesh.Draw();

    mwindow->display->Update(0,0);
  }

#pragma endregion [PAGE_ROOT]

#pragma region    [PAGE_SENS]

  IOB_Page_WLTS_Sensors::IOB_Page_WLTS_Sensors(Window* window)
    /* Init:: */
    : IPage(window)
    /* Method:: */{

    for(uint8_t i = 0; i < IDX_CLBTN::btn_idx_wsens_size; ++i){
      click_buttons[i].button.child_component = &click_buttons[i].label;
    }
    /*! HADNLER: Обработчик нажатия клавиши: ввод серийного номера */
    click_buttons[IDX_CLBTN::btn_idx_wsens_enter_ser].button.click_handler = [](Window* win, IOB_Page_WLTS_Sensors* page){
      auto go = [&](){
        page->page_fsm          = FSM_WLSens::fsm_wlsens_enter_ser;
        page->page_title_index  = PAGE_WLSens_Titles::wlsens_title_enter_ser;
      };
      if(win->password.is_set) {
        if(win->password.is_auth) go();
        else                      Window::GoToPage(Window::PageName::Page_WLTS_Sens, Window::PageName::Page_PasswordAuth, true);
      }
      else if(!win->password.is_set) {
        go();
      }
    };
    /*! HADNLER: Обработчик нажатия клавиши: удаление серийного номера */
    click_buttons[IDX_CLBTN::btn_idx_wsens_delete].button.click_handler = [](Window* win, IOB_Page_WLTS_Sensors* page){
      auto go = [&](){
        page->page_fsm          = FSM_WLSens::fsm_wlsens_ack_delete;
        page->page_title_index  = PAGE_WLSens_Titles::wlsens_title_ack_delete;
      };
      if(win->password.is_set) {
        if(win->password.is_auth) go();
        else                      Window::GoToPage(Window::PageName::Page_WLTS_Sens, Window::PageName::Page_PasswordAuth, true);
      }
      else if(!win->password.is_set) {
        go();
      }
    };
    /*! HADNLER: Обработчик нажатия клавиши: подтверждение удаления серийного номера -> YES */
    click_buttons[IDX_CLBTN::btn_idx_wsens_del_yes].button.click_handler = [](Window* win, IOB_Page_WLTS_Sensors* page){
      auto go = [&](){
        /* Удаление серийника по номеру входу */
        page->table_sensors[page->index_sensors].serial = 0;
        page->table_sensors[page->index_sensors].temp   = -100.0f;
        /* Сохранение конфигурации */
        dev_config.conf_user.wlts_serials.serial[page->index_sensors] = 0; 
        // dev_config.Save();
        GlobalUsings::request_flash_save = true;
        /* Обновить таблицу */
        memcpy(page->table_sensors_render, (void*)&page->table_sensors[(page->index_sensors/3)*3], sizeof(page->table_sensors_render));
        /* Переход в корень */
        page->page_fsm          = FSM_WLSens::fsm_wlsens_root;
        page->page_title_index  = PAGE_WLSens_Titles::wlsens_title_root;
      };
      if(win->password.is_set) {
        if(win->password.is_auth) go();
        else                      Window::GoToPage(Window::PageName::Page_WLTS_Sens, Window::PageName::Page_PasswordAuth, true);
      }
      else if(!win->password.is_set) {
        go();
      }
    };
    /*! HADNLER: Обработчик нажатия клавиши: подтверждение удаления серийного номера -> NO */
    click_buttons[IDX_CLBTN::btn_idx_wsens_del_no].button.click_handler = [](Window* win, IOB_Page_WLTS_Sensors* page){
      auto go = [&](){
        page->page_fsm          = FSM_WLSens::fsm_wlsens_choose;
        page->page_title_index  = PAGE_WLSens_Titles::wlsens_title_choose;
      };
      if(win->password.is_set) {
        if(win->password.is_auth) {
          go();
        }
        else {
          Window::GoToPage(Window::PageName::Page_WLTS_Sens, Window::PageName::Page_PasswordAuth, true);
        }
      }
      else if(!win->password.is_set) {
        go();
      }
    };
    
    uc_mesh_butt_choose.vol_horizontal_line = 1;
    uc_mesh_butt_choose.vol_vertical_line   = 4;
    uc_mesh_butt_choose.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_mesh_butt_choose.align_v = UCPrime::tVrtAlign::v_align_up;
    uint8_t index { 0 };
    uc_mesh_butt_choose.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wsens_enter_ser].button;
    uc_mesh_butt_choose.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wsens_delete].button;
    uc_mesh_butt_choose.volume = index;
    uc_mesh_butt_choose.AlignComponents();
    uc_mesh_butt_choose.index = 0;
    uc_mesh_butt_choose.components[0]->is_brigth = true;

    uc_mesh_butt_ack.vol_horizontal_line = 1;
    uc_mesh_butt_ack.vol_vertical_line   = 4;
    uc_mesh_butt_ack.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_mesh_butt_ack.align_v = UCPrime::tVrtAlign::v_align_up;
    index = 0;
    uc_mesh_butt_ack.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wsens_del_yes].button;
    uc_mesh_butt_ack.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wsens_del_no].button;
    uc_mesh_butt_ack.volume = index;
    uc_mesh_butt_ack.AlignComponents();
    uc_mesh_butt_ack.index = 0;
    uc_mesh_butt_ack.components[0]->is_brigth = true;

    uc_mvalue.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_mvalue.align_v = UCPrime::tVrtAlign::v_align_centr;

    uc_table_wlts.row_header.lbl_num.text     = (char*)"Вход";//Номер
    uc_table_wlts.row_header.lbl_serial.text  = (char*)"Сер.Ном.";
    uc_table_wlts.row_header.lbl_value.text   = (char*)"Температура";
    uc_table_wlts.row_header.lbl_volt.text    = (char*)"Заряд";
    uc_table_wlts.row_header.lbl_rssi.text    = (char*)"RSSI";
    uc_table_wlts.volume                      = 3;
    uc_table_wlts.is_brigth                   = true;
    uc_table_wlts.index_display_offs          = 1;
    uc_table_wlts.index                       = 0;
    uc_table_wlts.vals_table                  = table_sensors_render;
    
    /* Запрашиваем  ссылку на плату с lora-gateway  */
    IOBoards::TaskIOBoards::IOBoardR req_io_board {};
    req_io_board = IOBoards::TaskIOBoards::GetBoard();
    if(req_io_board.board != nullptr && req_io_board.type == SBerryCore::CFGParam::tSBerryBoard::MainBoard_IOB_WLTS) {
      io_board_wlbs = (IOBoards::IOB_classWLTS*)req_io_board.board;
    }
    else {
      io_board_wlbs = nullptr;
    }
    /* Формируем таблицу */
    if(io_board_wlbs != nullptr) {
      for(uint8_t i = 0; i < cnt_sensors; ++i){
        table_sensors[i].serial = dev_config.conf_user.wlts_serials.serial[i];//io_board_wlbs->wlbase.link_sens_data[i].serial;
        table_sensors[i].temp   = io_board_wlbs->wlbase.link_sens_data[i].value;
        table_sensors[i].volt   = io_board_wlbs->wlbase.link_sens_data[i].volts;
        table_sensors[i].rssi   = io_board_wlbs->wlbase.link_sens_data[i].rssi;
      }
    }
    /*! WARN: Copy values of sensors for rendering */
    memcpy(table_sensors_render, (void*)&table_sensors[index_sensors], sizeof(table_sensors_render));
  }
  void IOB_Page_WLTS_Sensors::Init() {

  }
  void IOB_Page_WLTS_Sensors::ClickHandl(uint32_t code){
    auto click_handl_root = [&](){
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            Window::GoToPage(Window::PageName::Page_WLTS_Root, true);
          break;
        case tKeyCode::Key_Up:
            if(index_sensors > 0) {
              index_sensors--;
              if(((index_sensors+1)%3)==0) {
                memcpy(table_sensors_render, (void*)&table_sensors[(index_sensors/3)*3], sizeof(table_sensors_render));
              }
            }
            else { 
              memcpy(table_sensors_render, (void*)&table_sensors[cnt_sensors - 3], sizeof(table_sensors_render));
              index_sensors = cnt_sensors - 1;
            }
            uc_table_wlts.PreviuosItem();
            uc_table_wlts.index_display_offs = (index_sensors/3)*3 + 1;
          break;
        case tKeyCode::Key_Down:
            if(index_sensors < (cnt_sensors-1)) {
              index_sensors++;
              if((index_sensors%3)==0) {
                memcpy(table_sensors_render, (void*)&table_sensors[(index_sensors/3)*3], sizeof(table_sensors_render));
              }
            }
            else {
              memcpy(table_sensors_render, (void*)&table_sensors[0], sizeof(table_sensors_render));
              index_sensors = 0;
            }
            uc_table_wlts.NextItem();
            uc_table_wlts.index_display_offs = (index_sensors/3)*3 + 1;
          break;
        case tKeyCode::Key_Accept:
            page_title_index = PAGE_WLSens_Titles::wlsens_title_choose;
            page_fsm = FSM_WLSens::fsm_wlsens_choose;
          break;
        default:
          break;
      }
    };
    auto click_handl_choose = [&](){
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            page_fsm = FSM_WLSens::fsm_wlsens_root;
            page_title_index = PAGE_WLSens_Titles::wlsens_title_root;
          break;
        case tKeyCode::Key_Up:
            uc_mesh_butt_choose.Previous();
          break;
        case tKeyCode::Key_Down:
            uc_mesh_butt_choose.Next();
          break;
        case tKeyCode::Key_Accept:
            if(uc_mesh_butt_choose.components[uc_mesh_butt_choose.index] != nullptr) {
              ((UCPrime::Button<void(*)(Window*, IOB_Page_WLTS_Sensors*)>*)
              uc_mesh_butt_choose.components[uc_mesh_butt_choose.index])->click_handler(mwindow, this);
            }
          break;
        default:
          break;
      }
    };
    auto click_handl_enter_serial = [&](){
      volatile int serial_numb {};
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            page_fsm          = FSM_WLSens::fsm_wlsens_choose;
            page_title_index  = PAGE_WLSens_Titles::wlsens_title_choose;
          break;
        case tKeyCode::Key_Up:
            uc_mvalue.Increment();
          break;
        case tKeyCode::Key_Down:
            uc_mvalue.NextDigit();
          break;
        case tKeyCode::Key_Accept:
            /* Извлечение значения серийника из компонента uc_mvalue */
            serial_numb = uc_mvalue.Getvalue();
            /* Привязка ко входу */
            table_sensors[index_sensors].serial = serial_numb;
            /* Сохранение конфигурации */
            dev_config.conf_user.wlts_serials.serial[index_sensors] = serial_numb;
            // dev_config.Save(); 
            GlobalUsings::request_flash_save = true;
            /* Обновить таблицу */
            memcpy(table_sensors_render, (void*)&table_sensors[(index_sensors/3)*3], sizeof(table_sensors_render));
            /* Переход обратно в меню... */
            page_fsm          = FSM_WLSens::fsm_wlsens_root;
            page_title_index  = PAGE_WLSens_Titles::wlsens_title_root;
          break;
        default:
          break;
      }
    };
    auto click_handl_ack_delete = [&](){
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            page_fsm          = FSM_WLSens::fsm_wlsens_choose;
            page_title_index  = PAGE_WLSens_Titles::wlsens_title_choose;
          break;
        case tKeyCode::Key_Up:
            uc_mesh_butt_ack.Previous();
          break;
        case tKeyCode::Key_Down:
            uc_mesh_butt_ack.Next();
          break;
        case tKeyCode::Key_Accept:
            if(uc_mesh_butt_ack.components[uc_mesh_butt_ack.index] != nullptr) {
              ((UCPrime::Button<void(*)(Window*, IOB_Page_WLTS_Sensors*)>*)
              uc_mesh_butt_ack.components[uc_mesh_butt_ack.index])->click_handler(mwindow, this);
            }
          break;
        default:
          break;
      }
    };

    switch(page_fsm){
      case FSM_WLSens::fsm_wlsens_root:       click_handl_root();         break;
      case FSM_WLSens::fsm_wlsens_choose:     click_handl_choose();       break;
      case FSM_WLSens::fsm_wlsens_enter_ser:  click_handl_enter_serial(); break;
      case FSM_WLSens::fsm_wlsens_ack_delete: click_handl_ack_delete();   break;
      default: break;
    }
    
  }
  void IOB_Page_WLTS_Sensors::Loop(){
    auto draw_base = [&](){
      title.text = (char*)page_titles[page_title_index];
      title.Draw();
      for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i){btn_marks[i].Draw();}
    };

    mwindow->Clear();

    btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_up;
    btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_down;

    /* Обновление таблицы */
    /* Формируем таблицу */
    if(io_board_wlbs != nullptr) {
      for(uint8_t i = 0; i < cnt_sensors; ++i){
        table_sensors[i].serial = io_board_wlbs->wlbase.link_sens_data[i].serial;
        table_sensors[i].temp   = io_board_wlbs->wlbase.link_sens_data[i].value;
        table_sensors[i].volt   = io_board_wlbs->wlbase.link_sens_data[i].volts;
        table_sensors[i].rssi   = io_board_wlbs->wlbase.link_sens_data[i].rssi;
      }
    }
    memcpy(table_sensors_render, (void*)&table_sensors[(index_sensors/3)*3], sizeof(table_sensors_render));

    switch(page_fsm){
      case FSM_WLSens::fsm_wlsens_root:
          draw_base();
          uc_table_wlts.Draw();
        break;
      case FSM_WLSens::fsm_wlsens_choose:
          draw_base();
          uc_mesh_butt_choose.Draw();
        break;
      case FSM_WLSens::fsm_wlsens_enter_ser:
          btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
          btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_rloop;
          draw_base();
          uc_mvalue.Draw();
        break;
      case FSM_WLSens::fsm_wlsens_ack_delete:
          draw_base();
          uc_mesh_butt_ack.Draw();
        break;
      case FSM_WLSens::fsm_wlsens_popup_msg:
        break;
      default:
      break;
    }

    mwindow->display->Update(0,0);
  }

#pragma endregion [PAGE_SENS]

#pragma region    [PAGE_SEARCH]

  IOB_Page_WLTS_Search::IOB_Page_WLTS_Search(Window* window)
  /* Init:: */
  : IPage(window)
  /* Method:: */{
    uc_table_wlts.row_header.lbl_num.text     = (char*)"Номер";
    uc_table_wlts.row_header.lbl_serial.text  = (char*)"Сер.Ном.";
    uc_table_wlts.row_header.lbl_value.text   = (char*)"Температура";
    uc_table_wlts.row_header.lbl_volt.text    = (char*)"Заряд";
    uc_table_wlts.row_header.lbl_rssi.text    = (char*)"RSSI";
    uc_table_wlts.volume                      = 3;
    uc_table_wlts.is_brigth                   = true;
    uc_table_wlts.index_display_offs          = 1;
    uc_table_wlts.index                       = 0;
    uc_table_wlts.vals_table                  = sensors_table_buffer;

    uc_io_choose.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_io_choose.align_v = UCPrime::tVrtAlign::v_align_centr;
    uc_io_choose.limit_low = 1;
    uc_io_choose.limit_up  = 12;
    uc_io_choose.value     = 1;

    for(uint8_t i = 0; i < IDX_CLBTN::btn_idx_wlsearch_size; ++i){
      click_buttons[i].button.child_component = &click_buttons[i].label;
    }
    /*! HADNLER: Обработчик нажатия клавиши: переназначение номера ввода (серийника датчика), ДА */
    click_buttons[IDX_CLBTN::btn_idx_wlsearch_reassign_yes].button.click_handler = [](Window* win, IOB_Page_WLTS_Search* page){
      /* дела, затем выход */
      uint8_t n_io = page->uc_io_choose.value - 1;
      if(n_io < 16) {
        /* Назначаем */
        dev_config.conf_user.wlts_serials.serial[n_io] = page->sensors_table_buffer[page->uc_table_wlts.index].serial;
        /* Сохраняем */
        // dev_config.Save();
        GlobalUsings::request_flash_save = true;
      }
      page->page_fsm = FSM_WLSearch::fsm_wlsearch_popup_msg;
      page->page_title_index = PAGE_WLSearch_Titles::wlsearch_title_root;
    };
    /*! HADNLER: Обработчик нажатия клавиши: переназначение номера ввода (серийника датчика), НЕТ */
    click_buttons[IDX_CLBTN::btn_idx_wlsearch_reassign_no].button.click_handler = [](Window* win, IOB_Page_WLTS_Search* page){
      /* Выход */
      page->page_fsm = FSM_WLSearch::fsm_wlsearch_root;
      page->page_title_index = PAGE_WLSearch_Titles::wlsearch_title_root;
    };

    uc_mesh_choose_io.vol_horizontal_line = 1;
    uc_mesh_choose_io.vol_vertical_line   = 4;
    uc_mesh_choose_io.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_mesh_choose_io.align_v = UCPrime::tVrtAlign::v_align_up;
    uint8_t index { 0 };
    uc_mesh_choose_io.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wlsearch_reassign_yes].button;
    uc_mesh_choose_io.components[index++] = &click_buttons[IDX_CLBTN::btn_idx_wlsearch_reassign_no].button;
    uc_mesh_choose_io.volume = index;
    uc_mesh_choose_io.AlignComponents();
    uc_mesh_choose_io.index = 0;
    uc_mesh_choose_io.components[0]->is_brigth = true;

    uc_popup_msg.align_h = UCPrime::tHrzAlign::h_align_centr;
    uc_popup_msg.align_v = UCPrime::tVrtAlign::v_align_centr;

    /* Запрашиваем  ссылку на плату с lora-gateway  */
    IOBoards::TaskIOBoards::IOBoardR req_io_board {};
    req_io_board = IOBoards::TaskIOBoards::GetBoard();
    if(req_io_board.board != nullptr && req_io_board.type == SBerryCore::CFGParam::tSBerryBoard::MainBoard_IOB_WLTS) {
      io_board_wlbs = (IOBoards::IOB_classWLTS*)req_io_board.board;
    }
    else {
      io_board_wlbs = nullptr;
    }
  }
  void IOB_Page_WLTS_Search::Init() {

  }
  void IOB_Page_WLTS_Search::ClickHandl(uint32_t code){
    auto click_handl_root = [&](){
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            Window::GoToPage(Window::PageName::Page_WLTS_Root, true);
          break;
        case tKeyCode::Key_Up:
            UpdateRealTableIndex();
            DecrementSensTableIndex();
            UpdateGUITable();
            uc_table_wlts.index = r_sens_cur_idx%3;// uc_table_wlts.PreviuosItem();
          break;
        case tKeyCode::Key_Down:
            UpdateRealTableIndex();
            IncrementSensTableIndex();
            UpdateGUITable();
            uc_table_wlts.index = r_sens_cur_idx%3;// uc_table_wlts.NextItem();
          break;
        case tKeyCode::Key_Accept:
            if(mwindow->password.is_set) {
              if(mwindow->password.is_auth) {
                page_fsm = FSM_WLSearch::fsm_wlsearch_choose_io;
                page_title_index = PAGE_WLSearch_Titles::wlsearch_title_choose_io;
              }
              else {
                Window::GoToPage(Window::PageName::Page_WLTS_Search, Window::PageName::Page_PasswordAuth, true);
              }
            }
            else if(!mwindow->password.is_set) {
              page_fsm = FSM_WLSearch::fsm_wlsearch_choose_io;
              page_title_index = PAGE_WLSearch_Titles::wlsearch_title_choose_io;
            }
            
          break;
          #if 0 //! DEBUG:
            case (tKeyCode::Key_Accept | tKeyCode::Key_Up):
                dbg_sensor_quant_found++;
                if(dbg_sensor_quant_found >= 12) dbg_sensor_quant_found = 0;
              break;
            case (tKeyCode::Key_Accept | tKeyCode::Key_Down):
                if(dbg_sensor_quant_found > 0)  dbg_sensor_quant_found--;
                else                            dbg_sensor_quant_found = 12;
              break;
          #endif
        default:
          break;
      }
    };
    auto click_handl_choose_io = [&](){
      uint8_t n_io {};
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            page_fsm = FSM_WLSearch::fsm_wlsearch_root;
            page_title_index = PAGE_WLSearch_Titles::wlsearch_title_root;
          break;
        case tKeyCode::Key_Up:
            uc_io_choose.Increment();
          break;
        case tKeyCode::Key_Down: 
            uc_io_choose.Decrement();
          break;
        case tKeyCode::Key_Accept:
            /* если вход занят, то на fsm_преназначение, если нет, то дела */
            n_io = uc_io_choose.value - 1;
            if(n_io < 16) {
              if(dev_config.conf_user.wlts_serials.serial[n_io] == 0) {
                /* Назначаем */
                dev_config.conf_user.wlts_serials.serial[n_io] = sensors_table_buffer[uc_table_wlts.index].serial;
                // dev_config.Save();
                GlobalUsings::request_flash_save = true;
                page_fsm = FSM_WLSearch::fsm_wlsearch_popup_msg;
                page_title_index = PAGE_WLSearch_Titles::wlsearch_title_root;
              }
              else {
                /* Переназначаем */
                page_fsm = FSM_WLSearch::fsm_wlsearch_reassign;
                page_title_index = PAGE_WLSearch_Titles::wlsearch_title_reassign;
              }
            }
          break;
        default:
          break;
      }
    };
    auto click_handl_reassign = [&](){
      switch ((tKeyCode)code) {
        case tKeyCode::Key_Back:
            page_fsm = FSM_WLSearch::fsm_wlsearch_choose_io;
            page_title_index = PAGE_WLSearch_Titles::wlsearch_title_choose_io;
          break;
        case tKeyCode::Key_Up:
            uc_mesh_choose_io.Previous();
          break;
        case tKeyCode::Key_Down:
            uc_mesh_choose_io.Next();
          break;
        case tKeyCode::Key_Accept:
            if(uc_mesh_choose_io.components[uc_mesh_choose_io.index] != nullptr) {
              ((UCPrime::Button<void(*)(Window*, IOB_Page_WLTS_Search*)>*)
              uc_mesh_choose_io.components[uc_mesh_choose_io.index])->click_handler(mwindow, this);
            }
          break;
        default:
          break;
      }
    };

    switch(page_fsm) {
      case FSM_WLSearch::fsm_wlsearch_root:       click_handl_root();       break;
      case FSM_WLSearch::fsm_wlsearch_choose_io:  click_handl_choose_io();  break;
      case FSM_WLSearch::fsm_wlsearch_reassign:   click_handl_reassign();   break;
      case FSM_WLSearch::fsm_wlsearch_popup_msg:  break;
      default: break;
    }
    
  }
  void IOB_Page_WLTS_Search::Loop(){
    mwindow->Clear();

    btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_up;
    btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_down;
    title.text = (char*)page_titles[page_title_index];

    switch(page_fsm) {
      case FSM_WLSearch::fsm_wlsearch_root: 
          UpdateRealTableIndex();
          UpdateGUITable();
          title.text = title_found_sens;
          for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i){btn_marks[i].Draw();}
          uc_table_wlts.Draw();
          title.Draw();
        break;
      case FSM_WLSearch::fsm_wlsearch_choose_io:
          btn_marks[BTN_RU].image_alias = Images::ImageAlias::img_butt_increment;
          btn_marks[BTN_RD].image_alias = Images::ImageAlias::img_butt_decrement;
          for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i){btn_marks[i].Draw();}
          uc_io_choose.Draw();
          title.Draw();
        break;
      case FSM_WLSearch::fsm_wlsearch_reassign:
          for(uint8_t i = 0; i < (sizeof(btn_marks)/sizeof(UCPrime::Mark)); ++i){btn_marks[i].Draw();}
          uc_mesh_choose_io.Draw();
          title.Draw();
        break;
      case FSM_WLSearch::fsm_wlsearch_popup_msg:
          uc_popup_msg.Draw();
          uc_popup_msg_iter++;
          if(uc_popup_msg_iter >= IOB_WLTS_MSG_ITER) {
            uc_popup_msg_iter = 0;
            page_fsm = FSM_WLSearch::fsm_wlsearch_root;
          }
        break;
      default:
      break;
    }

    mwindow->display->Update(0,0);
  }

  void IOB_Page_WLTS_Search::UpdateTitle() {
    // char*   temp_str  = StringConverter::UTF8ToCP1251(str_title); // Нельзя преобразование кодировки второй раз ломает символы
    size_t  str_len   = strlen(page_titles[wlsearch_title_root]);
    // memcpy((void*)title_found_sens, (void*)&str_title[0], sizeof(str_len)); // Не работает, копирует два символа!
    for(uint16_t i = 0; i < str_len; ++i) { title_found_sens[i] = (page_titles[wlsearch_title_root])[i]; }
    title_found_sens[str_len++] = ' ';
    StringConverter::IntToString((uint8_t*)&title_found_sens[str_len], sizeof(title_found_sens) - str_len, (int32_t)r_sens_vol);
  }
  void IOB_Page_WLTS_Search::UpdateRealTableIndex() {
    //! DEBUG:: r_sens_vol = GetQuantityFoundSens();
    r_sens_vol = io_board_wlbs != nullptr ? io_board_wlbs->wlbase.search.numb_found_sens : 0;
    if(r_sens_vol > 0)  r_sens_end_idx = r_sens_vol - 1;
    else                r_sens_end_idx = 0;
    if(r_sens_cur_idx > r_sens_end_idx)   { r_sens_cur_idx = r_sens_end_idx; uc_table_wlts.index = r_sens_cur_idx%3; }
    if(win_sens_end_idx > r_sens_end_idx) win_sens_end_idx = r_sens_end_idx;
    UpdateTitle();
  }
  void IOB_Page_WLTS_Search::IncrementSensTableIndex() {
    if(r_sens_cur_idx < r_sens_end_idx) r_sens_cur_idx++;
    else                                r_sens_cur_idx = 0;
  }
  void IOB_Page_WLTS_Search::DecrementSensTableIndex(){
    if(r_sens_cur_idx > 0) r_sens_cur_idx--;
    else                   r_sens_cur_idx = r_sens_end_idx;
  }
  void IOB_Page_WLTS_Search::UpdateGUITable() {
    if(r_sens_vol > 0) { 
      /* Определяем конечный и начальные индексы реальной таблицы датчиков, относительно текущего */
      win_sens_beg_idx = r_sens_cur_idx/3 * 3;
      win_sens_end_idx = win_sens_beg_idx + 3;
      if(win_sens_end_idx >= r_sens_vol)
        win_sens_end_idx = r_sens_vol /* - 1 */;
      /* Устанавливаем смещение отображение номера */
      uc_table_wlts.index_display_offs = win_sens_beg_idx + 1;
      /* Загружаем в реальную таблицу */
      if(io_board_wlbs != nullptr) {
        for(uint8_t i = win_sens_beg_idx, j = 0; i < win_sens_end_idx; ++i, ++j){
          if(j < 3) {
            //! DEBUG:: GetSensorData(i, &sensors_table_buffer[j].serial, &sensors_table_buffer[j].temp, &sensors_table_buffer[j].rssi);
            sensors_table_buffer[j].serial  = io_board_wlbs->wlbase.search.sens_data[i].serial;
            sensors_table_buffer[j].temp    = io_board_wlbs->wlbase.search.sens_data[i].value;
            sensors_table_buffer[j].rssi    = io_board_wlbs->wlbase.search.sens_data[i].rssi;
            sensors_table_buffer[j].volt    = io_board_wlbs->wlbase.search.sens_data[i].volts;
            // sensors_table_buffer[j].time = io_board_wlbs->wlbase.search.sens_data[i].ltu_time;
          }
        }
      }
      uc_table_wlts.volume = win_sens_end_idx - win_sens_beg_idx;
    }
    else {
      /* Обнуляем */
      uc_table_wlts.volume = 0;
      memset(&sensors_table_buffer, 0, sizeof(sensors_table_buffer));
    }
  }

#pragma endregion [PAGE_SEARCH]