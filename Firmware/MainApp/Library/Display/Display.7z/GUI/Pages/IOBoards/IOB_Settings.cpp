#include "IOB_Settings.h"

IOB_SettingsPage::IOB_SettingsPage(Window* window) : IPage(window) {}

void IOB_SettingsPage::Init() {

}

void IOB_SettingsPage::ClickHandl(uint32_t code) {
  switch ((tKeyCode)code) {
    case tKeyCode::Key_Back:
        Window::GoToPage(Window::PageName::Page_Root, true);
      break;
    case tKeyCode::Key_Up:
        // uc_mesh.PreviousGroup();
      break;
    case tKeyCode::Key_Down:
        // uc_mesh.NextGroup();
      break;
    case tKeyCode::Key_Accept:
      break;
    default:
      break;
  }
}

void IOB_SettingsPage::Loop() {

}