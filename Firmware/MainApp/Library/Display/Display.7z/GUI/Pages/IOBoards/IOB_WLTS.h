#ifndef _IOB_WLTS_H_
  #define _IOB_WLTS_H_

  #include <cstdint>
  #include "Window.h"
  #include "IOBoards.h"

  // class IOB_Page_WLTS_IOPare; -> manual & delete;
  // class IOB_Page_WLTS_Search; -> to io_num
  #define IOB_WLTS_MSG_ITER (40)

  #pragma region    [PAGE_ROOT]

    class IOB_Page_WLTS_Root : public IPage {
      public:
        #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
        /* Переопределение клавиши для текщей страницы */
        typedef enum DEFINE_KEY_ABOUT : uint32_t {
          Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
          Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
          Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
          Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
        } tKeyCode;

        UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, "Беспроводные датчики" };/* Найдено 2, показаны 1 - 2 */

        UCPrime::Mark btn_marks[4] {
          { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
          { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
          { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
          { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
        };

        #define WLTS_ROOT_BTNS_VOL (2)
        /// @brief Индексы click_buttons
        enum IDX_CLBTN : uint8_t {
          btn_idx_wlts_sens,
          btn_idx_wlts_search,
        };
        struct ClickButton {
          UCPrime::Label                     label;
          UCPrime::Button<void(*)(Window*)>  button;
        }
        click_buttons[WLTS_ROOT_BTNS_VOL] {
          {.label = {create_gui_apis_refs, (char*)"Датчики"},  .button = {create_gui_apis_refs}},    /*  */
          {.label = {create_gui_apis_refs, (char*)"Поиск"},    .button = {create_gui_apis_refs}},    /*  */
        };
        #define CLICK_BUTTONS_Size (sizeof(click_buttons))

        UCPrime::Grid         uc_mesh       {create_gui_apis_refs, {{16, 14}, 224, 64-14}};

        IOB_Page_WLTS_Root(Window* window);
        virtual void Init() override;
        virtual void ClickHandl(uint32_t code) override;
        virtual void Loop() override;
    };//__class__IOB_Page_WLTS_Root
    #define IOB_PAGE_WLTS_ROOT_Size (sizeof(IOB_Page_WLTS_Root))
  
  #pragma endregion [PAGE_ROOT]

  #pragma region    [PAGE_SENS]

    class IOB_Page_WLTS_Sensors : public IPage {
      /*
        - привязка по серийному номеру 4 байта или u32
        - две таблицы: привязанные и найденные
        - нужен mutex для протокола обмена с базовой станцией
        страницы:
        - привязанные датчики ко входам: 
            12 элементов располагаются последовательно:
              I   номер входа - Серийный номер, Значение, RSSI, сек
              II  номер входа - Пусто
            если нажать, то отображаем кнопку отвязать и найденные датчики
        - поиск: 
          (таблица из 64 элементов) последовательно отображаем 
            номер элемента - серийный номер - значение - RSSI - сек
        Для экономии RAM - разработать п_элемент "виртуальная сетка" с привязкой к uint32 и индексу отображения 
        - добавить ввод вручную
        - в title добавить отображение кол-во датчиков "заголовок, 1 - 3 из 12"
      */
      public:
        #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
        /* Переопределение клавиши для текщей страницы */
        typedef enum DEFINE_KEY_ABOUT : uint32_t {
          Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
          Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
          Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
          Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
        } tKeyCode;

        /// @brief FSM для текущей страницы
        enum FSM_WLSens : uint8_t {
          fsm_wlsens_root,
          fsm_wlsens_choose,
          fsm_wlsens_enter_ser,
          fsm_wlsens_ack_delete,
          fsm_wlsens_popup_msg,
        } page_fsm {
          fsm_wlsens_root
        };

        /// @brief Текущий индекс заголовка
        enum PAGE_WLSens_Titles : uint8_t {
          wlsens_title_root,
          wlsens_title_choose,
          wlsens_title_enter_ser,
          wlsens_title_ack_delete,
          wlsens_title_size,
        } page_title_index {
          wlsens_title_root
        };
        const char* page_titles[PAGE_WLSens_Titles::wlsens_title_size] {
          (char*)"Беспроводные датчики",        /* table of sensors  */
          (char*)"Выберите операцию",           /* control of two buttons: set or delete  */
          (char*)"Установите серийный номер",   /* control of one uc_component            */
          (char*)"Удалить"                      /* control of two buttons: yes or not     */
        };
        UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, (char*)page_titles[page_title_index] };/* Найдено 2, показаны 1 - 2 */

        enum BTN_MARK : uint8_t    { BTN_LU = 0, BTN_LD = 1, BTN_RU = 2, BTN_RD = 3                     };
        UCPrime::Mark btn_marks[4] {
          { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
          { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
          { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
          { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
        };

        /// @brief Индексы click_buttons
        enum IDX_CLBTN : uint8_t {
          btn_idx_wsens_enter_ser,    /* Enter serial number      */
          btn_idx_wsens_delete,       /* Delete serial number     */
          btn_idx_wsens_del_yes,      /* acknowledge delete       */
          btn_idx_wsens_del_no,       /* acknowledge delete: no   */
          btn_idx_wsens_size,         /* acknowledge delete: yes  */
        };
        struct ClickButton {
          UCPrime::Label                                             label;
          UCPrime::Button<void(*)(Window*, IOB_Page_WLTS_Sensors*)>  button;
        }
        click_buttons[IDX_CLBTN::btn_idx_wsens_size] {
          {.label = {create_gui_apis_refs, (char*)"установить серийный номер"}, .button = {create_gui_apis_refs}},    /*  */
          {.label = {create_gui_apis_refs, (char*)"Удалить"},                   .button = {create_gui_apis_refs}},    /*  */
          {.label = {create_gui_apis_refs, (char*)"Да"},                        .button = {create_gui_apis_refs}},    /*  */
          {.label = {create_gui_apis_refs, (char*)"Нет"},                       .button = {create_gui_apis_refs}},    /*  */
        };
        #define CLICK_BUTTONS_Size (sizeof(click_buttons))

        UCPrime::Grid uc_mesh_butt_choose {create_gui_apis_refs, {{16, 14}, 224, 64-14}};
        UCPrime::Grid uc_mesh_butt_ack    {create_gui_apis_refs, {{16, 14}, 224, 64-14}};

        UCPrime::UMDEntryValue uc_mvalue {create_gui_apis_refs, {{16, 16}, 224, 64-16}};

        UCPrime::TableWLTS2V uc_table_wlts{create_gui_apis_refs, {{16, 14}, 224, 50}};
        /// @brief Буфер таблицы датчиков для "отрисовки"
        UCPrime::TableWLTS2V::table_rec_wlts table_sensors_render[3] {
          /* Таблица в которую копируем данные для отображения */
        };

        uint8_t index_sensors         {0};    /* индекс реальной таблицы    */
        const uint8_t cnt_sensors     {12};   /* индекс найденных датчиков  */
        /// @brief Буфер всей таблицы датчиков 
        UCPrime::TableWLTS2V::table_rec_wlts table_sensors[12] {
          { .serial = 100000001, .temp = 0.0f,    .volt = 0.1, .rssi =-127  },
          { .serial = 200000002, .temp = -300.0f, .volt = 0.1, .rssi =-127  },
          { .serial = 300000003, .temp = 20.0f,   .volt = 0.1, .rssi =-127  },
          { .serial = 400000004, .temp = 25.0f,   .volt = 0.1, .rssi =-127  },
          { .serial = 500000005, .temp = 27.0f,   .volt = 0.1, .rssi =-127  },
          { .serial = 600000006, .temp = 28.0f,   .volt = 0.1, .rssi =-127  },
          { .serial = 700000007, .temp = 40.0f,   .volt = 0.1, .rssi =-127  },
          { .serial = 800000008, .temp = 50.0f,   .volt = 0.1, .rssi =-127  },
          { .serial = 900000009, .temp = 1.0f,    .volt = 0.1, .rssi =-120  },
          { .serial = 100000010, .temp = 2.0f,    .volt = 0.1, .rssi =-110  },
          { .serial = 110000011, .temp = -2.0f,   .volt = 0.1, .rssi =-100  },
          { .serial = 120000012, .temp = 0.0f,    .volt = 0.1, .rssi =-98   },
        };
        #define VALUES_TABLE_Size (sizeof(table_sensors))
        /*! 
          TODO: Убрать таблицу, теперь можно значения копировать из платы 
        */

        IOBoards::IOB_classWLTS* io_board_wlbs;

        IOB_Page_WLTS_Sensors(Window* window);
        virtual void Init() override;
        virtual void ClickHandl(uint32_t code) override;
        virtual void Loop() override;

    };//__class IOB_Page_WLTS
    #define IOB_PAGE_WLTS_Sensors_Size (sizeof(IOB_Page_WLTS_Sensors))
  
  #pragma endregion [PAGE_SENS]

  #pragma region    [PAGE_SEARCH]

    class IOB_Page_WLTS_Search : public IPage {
      public:
        #define create_gui_apis_refs { .gfx = &mwindow->gfx, .font = &mwindow->font, .images = &mwindow->images }
        /* Переопределение клавиши для текщей страницы */
        typedef enum DEFINE_KEY_ABOUT : uint32_t {
          Key_Accept  = 1,     /* Левая верхняя  клавиша, Принять/Войти     */
          Key_Back    = 2,     /* Левая нижняя   клавиша, Отклонить/Назад   */
          Key_Up      = 4,     /* Правая верхняя клавиша, Верх              */
          Key_Down    = 8      /* Правая нижняя  клавиша, Вниз              */
        } tKeyCode;

        /// @brief FSM для текущей страницы
        enum FSM_WLSearch : uint8_t {
          fsm_wlsearch_root,
          fsm_wlsearch_choose_io,   /* Выбор номера входа 1 - 16 */
          fsm_wlsearch_reassign,    /* Warning of reassignment. Переход сюда если происходит переназначение номера вывода */
          fsm_wlsearch_popup_msg,   /*  */
        } page_fsm {
          fsm_wlsearch_root
        };

        /// @brief Текущий индекс заголовка
        enum PAGE_WLSearch_Titles : uint8_t {
          wlsearch_title_root,
          wlsearch_title_choose_io,
          wlsearch_title_reassign,
          wlsearch_title_size,
        } page_title_index {
          wlsearch_title_root
        };
        const char* page_titles[PAGE_WLSearch_Titles::wlsearch_title_size] {
          (char*)"Найдено датчиков",
          (char*)"Выберите номер входа",
          (char*)"Переназначить?"            
        };
        char title_found_sens[64] {};

        UCPrime::Title title { create_gui_apis_refs, {{ 16, 0 }, 224, 14}, (char*)page_titles[page_title_index]};

        enum BTN_MARK : uint8_t    { BTN_LU = 0, BTN_LD = 1, BTN_RU = 2, BTN_RD = 3                     };
        UCPrime::Mark btn_marks[4] {
          { create_gui_apis_refs, {{0,      16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_accept  },
          { create_gui_apis_refs, {{0,      48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_back    },
          { create_gui_apis_refs, {{256-16, 16 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_up      },
          { create_gui_apis_refs, {{256-16, 48 - 16/2}, 16, 16 }, Images::tImageAlias::img_butt_down    },
        };

        UCPrime::UMDValue uc_io_choose { create_gui_apis_refs, {{ 16, 0 }, 224, 50} };

        /// @brief Индексы click_buttons
        enum IDX_CLBTN : uint8_t {
          btn_idx_wlsearch_reassign_yes,
          btn_idx_wlsearch_reassign_no,
          btn_idx_wlsearch_size,
        };
        struct ClickButton {
          UCPrime::Label                                             label;
          UCPrime::Button<void(*)(Window*, IOB_Page_WLTS_Search*)>  button;
        }
        click_buttons[IDX_CLBTN::btn_idx_wlsearch_size] {
          {.label = {create_gui_apis_refs, (char*)"Да"},                        .button = {create_gui_apis_refs}},    /*  */
          {.label = {create_gui_apis_refs, (char*)"Нет"},                       .button = {create_gui_apis_refs}},    /*  */
        };
        #define CLICK_BUTTONS_Size (sizeof(click_buttons))
        UCPrime::Grid uc_mesh_choose_io {create_gui_apis_refs, {{16, 14}, 224, 64-14}};

        UCPrime::Label uc_popup_msg {create_gui_apis_refs, {{16, 14}, 224, 64-14}, (char*)"Успешно!"};
        uint16_t       uc_popup_msg_iter {};

        IOBoards::IOB_classWLTS* io_board_wlbs;

        IOB_Page_WLTS_Search(Window* window);
        virtual void Init() override;
        virtual void ClickHandl(uint32_t code) override;
        virtual void Loop() override;

      private:
        UCPrime::TableWLTS2V uc_table_wlts{create_gui_apis_refs, {{16, 14}, 224, 50}};
        UCPrime::TableWLTS2V::table_rec_wlts sensors_table_buffer[3] {
          /* Таблица в которую копируем данные в uc_table_wlts из списка найденных датчиков */
          /* Принцип скользящего окна по списку */
        };
        uint16_t r_sens_cur_idx   {};   /* Текущий индекс в списке найденных датчиков */
        uint16_t r_sens_end_idx   {};   /* Конечный индекс списка найденных датчиков */
        uint16_t r_sens_vol       {};   /* Кол-во найденных датчиков */
        uint16_t win_sens_beg_idx {};   /* Начальный индекс окна отображения датчиков относительно списка датчиков */
        uint16_t win_sens_end_idx {};   /* Конечный индекс (точнее длина) окна отображения датчиков относительно списка датчиков */
      
        void UpdateTitle();
        void UpdateRealTableIndex();
        void IncrementSensTableIndex();
        void DecrementSensTableIndex();
        void UpdateGUITable();
      private: /*! DEBUG:: insert to board_wlts:: */
        // uint16_t  dbg_sensor_index       {0};     /* индекс реальной таблицы    */
        // uint16_t  dbg_sensor_quant_found {1};     /* индекс найденных датчиков  */
        // UCPrime::TableWLTS::table_rec_wlts dbg_board_table_sensors[12] {
        //   /* Таблица доджна быть определена в задаче с платой */
        //   /* из которой копируем данные и индекс  */
        //   /* Таблицу в задаче постоянно сортируем */
        //   /*! WARN: Удалить после отладки */
        //   { .serial = 100000001, .temp = 0.0f,    .rssi =-127  },
        //   { .serial = 100000002, .temp = -300.0f, .rssi =-127  },
        //   { .serial = 100000003, .temp = 20.0f,   .rssi =-127  },
        //   { .serial = 100000004, .temp = 25.0f,   .rssi =-127  },
        //   { .serial = 100000005, .temp = 27.0f,   .rssi =-127  },
        //   { .serial = 100000006, .temp = 28.0f,   .rssi =-127  },
        //   { .serial = 100000007, .temp = 40.0f,   .rssi =-127  },
        //   { .serial = 100000008, .temp = 50.0f,   .rssi =-127  },
        //   { .serial = 100000009, .temp = 1.0f,    .rssi =-120  },
        //   { .serial = 100000010, .temp = 2.0f,    .rssi =-110  },
        //   { .serial = 100000011, .temp = -2.0f,   .rssi =-100  },
        //   { .serial = 100000012, .temp = 0.0f,    .rssi =-98   },
        // };
        // #define VALUES_TABLE_Size (sizeof(table_sensors))
        
        // bool GetSensorData(uint16_t i, uint32_t* serial, float* temp, int8_t* rssi) {
        //   bool result { false };
        //   if(serial == nullptr || temp == nullptr || rssi == nullptr || i >= dbg_sensor_quant_found)
        //   return false;
        //   (*serial) = dbg_board_table_sensors[i].serial;
        //   (*temp)   = dbg_board_table_sensors[i].temp;
        //   (*rssi)   = dbg_board_table_sensors[i].rssi;
        //   result = true;
        //   return result;
        // }
        // uint16_t GetQuantityFoundSens() {
        //   return dbg_sensor_quant_found;
        // }

    };//__class IOB_Page_WLTS
    #define IOB_PAGE_WLTS_Search_Size (sizeof(IOB_Page_WLTS_Search))
  
  #pragma endregion [PAGE_SEARCH]

#endif //___IOB_WLTS_H_