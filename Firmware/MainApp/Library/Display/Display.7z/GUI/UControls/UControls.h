#ifndef _UCONTROLS_H_
  #define _UCONTROLS_H_

  #include <cstdint>
  #include <type_traits>
  #include <concepts>
  #include <cstring>
  #include <functional>   // для std::function

  #include "GFX.h"
  #include "Fonts.h"
  #include "Images.h"
  #include "StringConverters.h"

  /// @brief User controls primitives
  namespace UCPrime {

    /// @brief Указатель на графические API
    typedef struct gui_apis {
      GFX*       gfx;
      FontV*     font;
      Images*    images;
    } tguiapis;

    /// @brief Выравниванивание по горизонтали
    typedef enum UC_horizontal_align { h_align_left, h_align_centr, h_align_rigth } tHrzAlign;
    /// @brief Выравнивание по вертикали
    typedef enum UC_vertical_align   { v_align_up, v_align_centr, v_align_down    } tVrtAlign;

    /// @brief Пропорция для RecordValue, ну может и для других 
    typedef struct Proportion {
      float   div_0;
      float   div_1;
      float   div_2;
      float   div_3;
    } tProportion;

    template<typename T>
    constexpr static uint32_t GetTSize() { return sizeof(T); } 

    /// @brief Вернуть длину в символах 
    /// @param [in] drv           :: Графические api
    /// @param [in] text          :: Начальная позиция в строке
    /// @param [in] pix_len_lim   :: Ограничение длины в пикселях 
    /// @return 
    uint8_t GetLastIndex(tguiapis* drv, const char* text, uint16_t pix_len_lim);

    /// @brief Координата 
    class Point {
      public:
        uint8_t x { 0 }, y { 0 };
        Point();
        Point(uint8_t x, uint8_t y);
        Point(const UCPrime::Point&);
        void operator=(const UCPrime::Point& p) {
          x = p.x;
          y = p.y;
        }
    };
    #define UC_Point (sizeof(Point))

    /// @brief Borders Rectangle 
    class BordersR {
      public:
        Point     p { };    /* Начальная координата, верхняя левая точка прямоугольника */
        uint8_t   width { 0 }, height { 0 };
        BordersR();
        BordersR(Point p, uint8_t w, uint8_t h);
        BordersR(Point p0, Point p1);
        BordersR(const UCPrime::BordersR& bordrs);
        void operator=(const UCPrime::BordersR& b) {
          p       = b.p;
          width   = b.width;
          height  = b.height;
        }
    };
    #define UC_BorderR (sizeof(BordersR))
    
    /* template<typename T> requires (std::is_base_of<Point, T>::value || std::is_base_of<Point*, T>::value) */

    /// @brief Базовый класс для простейших элементов пользователя
    class Component {
      public:
        static constexpr uint16_t limit_x { 255 };
        static constexpr uint16_t limit_y { 63 };
        BordersR  border;                     /* Границы    */
        bool      is_brigth;                  /* Подстветка */
        bool      auto_border { true };       /* Автограницы: выкл - отрисовка от точки, как есть, ограничение от ширины границы */
        tguiapis  gui_apis    { };
        tHrzAlign align_h     { tHrzAlign::h_align_left };
        tVrtAlign align_v     { tVrtAlign::v_align_up   };
        Component(tguiapis gui_apis);
        Component(tguiapis gui_apis, BordersR bordrs);
        virtual void Draw() = 0;
    };
    #define COMPONENT_Size (sizeof(Component))

    /// @brief Простая надпись с выводом 
    class Label : public Component {
      public:
        char*       text          { nullptr };  /* Указатель на текст */
        uint16_t    width_ofield  { 0 };        /* Ограничение длины поля вывода [в пикселях] */
        uint8_t     start_index   { 0 };        /* Стартовый индекс в строке вывода */
        uint8_t     end_index     { 0 };        /* Конечный  индекс в строке вывода  */
        uint8_t     iteration     { 0 };        /* Текущий цикл итерации */
        uint8_t     iterations    { 30 };       /* Кол-во повторений вывода текста для смещенения текста если он выходит за поле width_ofield */
        uint8_t     index_symb_brigth  {255};   /* индекс символа, который нужно подстветить */
        Label(tguiapis gui_apis);
        Label(tguiapis gui_apis, char* txt);
        Label(tguiapis gui_apis, BordersR bordrs);
        Label(tguiapis gui_apis, BordersR bordrs, char* txt);
        // Label(tguiapis gui_apis, Point p, char* txt);
        virtual void Draw() override;
    };
    #define LabelSizeT (sizeof(Label))

    // /// @brief Поле значения
    // class FieldValue : public Component {
    //   public:
    //     Label lbl;
    // };
    // #define UC_FIELDVALUE_Size (sizeof(FieldValue))

    /// @brief Заголовок с выравниванием по середине координат p0, p1
    class Title : public Label {
      public:
        Title(tguiapis gui_apis, BordersR bordrs, const char* txt);
        void SetText(const char* txt);
        void SetBorder(BordersR bordrs);
    };
    #define UC_Title_Size (sizeof(Title))

    // template<uint8_t t_buf_len = 15>
    
    /// @brief  Запись: текст, разделитель, значение
    ///         Внутренние элементы рисуются от базовых координат  
    class RecordValue : public Component {
      static constexpr uint8_t t_buf_len {15};
      static inline uint8_t string_value[t_buf_len];     /* Буфер для преобразованного числового значения */
      public:
        Label         lbl_name;                       /* Designation of the value. Обозначения/Имя числового значения */
        Label         lbl_separator;                  /* Разделитель между текстом и значением */
        Label         lbl_value;                      /* Числовое значение в виде текста */
        tProportion*  proportion      { nullptr };    /* Указатель на пропорции полей  */
        int*          p_int_value     { nullptr };    /* Указатель на значение */
        float*        p_flt_value     { nullptr };    /* Указатель на значение */
        char*         err_value       { nullptr };    /* Ошибка измерения */
        char*         none_value      { nullptr };    /* Указатель на текст если значения нету */
        Images::ImageAlias  image_units   { Images::ImageAlias::img_null };   /* Единицы измерения в виде картинки */
        RecordValue(tguiapis gui_apis);
        RecordValue(tguiapis gui_apis, char* txt);
        RecordValue(tguiapis gui_apis, BordersR bordrs);
        RecordValue(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw() override;
    };
    #define UC_Record_Size (sizeof(RecordValue))

    /// @brief Запись: текст, разделитель, текст
    class RecordString : public Component {
      static constexpr uint8_t t_buf_len {20};
      static inline uint8_t string_value[t_buf_len];  /* Буфер для преобразованного числового значения */
      public:
        Label         lbl_name;                       /* Designation of the value. Обозначения/Имя числового значения */
        Label         lbl_separator;                  /* Разделитель между текстом и значением  */
        Label         lbl_value;                      /* Числовое значение в виде текста        */
        float         proportion      { 2.0f };       /* Коэф. пропорцинальности поля name      */
        RecordString(tguiapis gui_apis);
        RecordString(tguiapis gui_apis, char* txt);
        RecordString(tguiapis gui_apis, BordersR bordrs);
        RecordString(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw() override;
    };
    #define UC_RecordString_Size (sizeof(RecordString))

    /// @brief Запись для беспроводных датчиков
    class RecordWLTS : public Component {
      public:
        struct uc_rec_wlts_limits {
          uint8_t num;
          uint8_t ser;
          uint8_t val;
          uint8_t rssi;
          uint8_t bound;
        };
        Label lbl_num;
        Label lbl_serial;
        Label lbl_value;
        Label lbl_rssi;
        uc_rec_wlts_limits* limits;
        RecordWLTS(tguiapis gui_apis);
        RecordWLTS(tguiapis gui_apis, char* txt);
        RecordWLTS(tguiapis gui_apis, BordersR bordrs);
        RecordWLTS(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw() override;
    };
    #define UC_RECORD_WLTS_Size (sizeof(RecordWLTS))

    /// @brief Запись для беспроводных датчиков ()
    class RecordWLTS2V : public Component {
      public:
        struct uc_rec_wlts_limits {
          uint8_t num;
          uint8_t ser;
          uint8_t val;
          uint8_t volt;
          uint8_t rssi;
          uint8_t bound;
        };
        Label lbl_num;
        Label lbl_serial;
        Label lbl_value;
        Label lbl_volt;
        Label lbl_rssi;
        uc_rec_wlts_limits* limits;
        RecordWLTS2V(tguiapis gui_apis);
        RecordWLTS2V(tguiapis gui_apis, char* txt);
        RecordWLTS2V(tguiapis gui_apis, BordersR bordrs);
        RecordWLTS2V(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw() override;
    };
    #define UC_RECORD_WLTS2V_Size (sizeof(RecordWLTS2V))

    /// @brief Запись: текст, разделитель, цифровое значение
    class RecordBitField : public Component {
      public:
        Label         lbl_name;        /* Имя значение / Обозначение  */
        Label         lbl_separator;   /* Разделитель */
        Label         lbl_value;       /* Значение текстом */
        tProportion*  proportion      { nullptr };  /* Указатель на пропорции */
        uint32_t*     p_digi_value    { nullptr };  /* Указатель на битовое поле */
        uint8_t       index_value     { 0 };        /*  */
        char*         txt_cond_on     { nullptr };  /* Строка - состояние включено  */
        char*         txt_cond_off    { nullptr };  /* Строка - состояние выключено */
        RecordBitField(tguiapis gui_apis);
        RecordBitField(tguiapis gui_apis, char* txt);
        RecordBitField(tguiapis gui_apis, BordersR bordrs);
        RecordBitField(tguiapis gui_apis, BordersR bordrs, char* txt);
        /* ... */
        virtual void Draw() override;
    };
    #define UC_RecordDGValue_Size (sizeof(RecordBitField))

    /// @brief Интерфейс для полей с изменяющимся числами
    class IUXDigit {
      public:
        virtual void NextDigit() = 0;
        virtual void PrevDigit() = 0;
        virtual void Increment() = 0;
        virtual void Decrement() = 0;
    };

    /// @brief User 4_ Value Password
    class U4DPassword : public Component, IUXDigit {
      static constexpr uint8_t max_index {3};
      static constexpr uint8_t bound_low  { (uint8_t)'0' };
      static constexpr uint8_t bound_high { (uint8_t)'9' };
      public:
        char      str_pwd[6]  {"0000"}; /* 4 разряда + 2 нуля */
        Label     lbl_pwd;
        uint8_t   index         {};     /* Индекс текущего разряда */
        U4DPassword(tguiapis gui_apis);
        U4DPassword(tguiapis gui_apis, char* txt);
        U4DPassword(tguiapis gui_apis, BordersR bordrs);
        U4DPassword(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw() override;
        virtual void NextDigit() override;
        virtual void PrevDigit() override;
        virtual void Increment() override;
        virtual void Decrement() override;
        // void GetValue();
    };
    #define UC_U4VPASSWORD_Size (sizeof(U4DPassword))

    /// @brief User Multi_Value
    class UMDEntryValue : public Component, IUXDigit {
      static constexpr uint8_t max_index {8};//9
      static constexpr uint8_t bound_low  { (uint8_t)'0' };
      static constexpr uint8_t bound_high { (uint8_t)'9' };
      public:
        char      str_value[12]  {"000000000"}; /*  */
        Label     lbl_value;
        uint8_t   index         {};     /* Индекс текущего разряда */
        UMDEntryValue(tguiapis gui_apis);
        UMDEntryValue(tguiapis gui_apis, char* txt);
        UMDEntryValue(tguiapis gui_apis, BordersR bordrs);
        UMDEntryValue(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw() override;
        virtual void NextDigit() override;
        virtual void PrevDigit() override;
        virtual void Increment() override;
        virtual void Decrement() override;
        int Getvalue();
    };
    #define UC_UMVVALUE_Size (sizeof(UMDEntryValue))

    /// @brief Многоразрядное значение (int) до 15 символов
    class UMDValue : public Component, IUXDigit {
      static inline uint8_t str[15] {};
      public:
        int32_t   limit_low   {0};
        int32_t   limit_up    {15};
        int32_t   value;
        Label     lbl_value;
        UMDValue(tguiapis gui_apis);
        UMDValue(tguiapis gui_apis, char* txt);
        UMDValue(tguiapis gui_apis, BordersR bordrs);
        UMDValue(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw() override;
        virtual void NextDigit() override;
        virtual void PrevDigit() override;
        virtual void Increment() override;
        virtual void Decrement() override;
        // int GetValue();
    };
    #define UC_UMDVALUE_Size (sizeof(UMDValue))

    /// @brief Пользовательский компонент для бул-значения 
    class UBoolValue : public Component/* , IUXDigit */ {
      public:
        bool  value;
        Label lbl_value;
        char* b_str_true;
        char* b_str_false;
        UBoolValue(tguiapis gui_apis);
        UBoolValue(tguiapis gui_apis, char* txt);
        UBoolValue(tguiapis gui_apis, BordersR bordrs);
        UBoolValue(tguiapis gui_apis, BordersR bordrs, char* txt);
        virtual void Draw();
        // /* virtual */ void Increment() /* override */;
        /* virtual */ void Change() /* override */;
    };

    /// @brief Класс кнопка...
    // template<typename T> requires (std::is_base_of<Label, T>::value || std::is_base_of<RecordValue, T>::value)
    template<typename T>
    class Button : public Component {
      public:
        // T child; 
        Component* child_component;
        // std::function<void(void*)> ClickEvent;
        T click_handler;

        Button(tguiapis gui_apis);
        Button(tguiapis gui_apis, BordersR bordrs);
        Button(tguiapis gui_api,  Component* child);
        Button(tguiapis gui_apis, BordersR bordrs, Component* child);
        // Button(tguiapis gui_apis, Point arg_p0, Point arg_p1);
        // Button(tguiapis gui_apis, Point arg_p0, Point arg_p1, Component* child);

        // /// @brief События нажатия
        // /// @tparam T   
        // /// @param [in] obj  :: data 
        // template<typename T>
        // void ClickHandl(T* obj);
        // void ClickHandl();

        virtual void Draw() override;
    };
    #define UC_Button_Size  (sizeof(Button<void(*)()>));

    template<typename T>
    Button<T>::Button(tguiapis gui_api) : Component(gui_apis) {}
    template<typename T>
    Button<T>::Button(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs) {}
    // template<typename T>
    // Button<T>::Button(tguiapis gui_apis, Point arg_p0, Point arg_p1) : Component(gui_apis, arg_p0, arg_p1) {}
    template<typename T>
    Button<T>::Button(tguiapis gui_api, Component* child) : Component(gui_apis), child_component(child) {}
    template<typename T>
    Button<T>::Button(tguiapis gui_apis, BordersR bordrs, Component* child) : Component(gui_apis, bordrs), child_component(child) {}
    // template<typename T>
    // Button<T>::Button(tguiapis gui_apis, Point arg_p0, Point arg_p1, Component* child) : Component(gui_apis, arg_p0, arg_p1), child_component(child) {}
    template<typename T>
    void Button<T>::Draw() {
      if(child_component != nullptr) {
        child_component->border     = border;
        child_component->align_h    = align_h;
        child_component->align_v    = align_v;
        child_component->is_brigth  = is_brigth;
        // child_component->border  = border;
        child_component->Draw();
      }
    }

    /// @brief Схема заполнения
    typedef enum PlacementScheme {
      ShemeByRow,       /* Сначала заполняем по строкам */
      SchemeByColumn    /* Сначала заполняем по столбцам */
    } tScheme;

    /// @brief Сетка со списком компонентов, он же grid, он же scroll, он же list<T is USPrime::Component> 
    ///  scroll { 
    ///    grid {
    ///      list<T::Componnent>{
    ///      }
    ///    }
    ///  }
    class Grid : public Component {
      public:
        tScheme place_schema        { tScheme::ShemeByRow };  /* Схема размещения внутренних компонентов */
        uint8_t vol_horizontal_line {1};          /* Кол-во компонентов по горизонтали */
        uint8_t vol_vertical_line   {4};          /* Кол-во компонентов по вертикали */
        Component* components[16]   {};           /* Указатели на компоненты  */
        Component* component        { nullptr };  /* Указатель на текущий компонент для быстрого доступа */
        uint8_t    index            {};   /* Индекс текущего элемента */
        uint8_t    volume           {};   /* Объем компонентов */
        uint8_t    group            {};   /* Текущая группа компонентов Draw. [volume / (vol_hor * vol_vertical)] * numb_group  */

        Grid(tguiapis gui_apis);
        Grid(tguiapis gui_apis, BordersR bordrs);
        virtual void Draw() override;
        /// @brief Получить первоначальную точку отрисовки для элемента
        /// @param [in] index :: Индекс элемента 
        /// @return Координаты
        Point GetPoint(uint8_t index);
        /// @brief Получить границы поля для дочернего элемента (Верхнеую левую точку прямоугольгика, ширину, высоту)
        /// @param [in] index :: Индекс элемента в списке 
        /// @return Границы прямоугольного поля
        BordersR GetBorder(uint8_t index);
        /// @brief Выровнить компоненты по сетке, т.е. установить им координаты
        void AlignComponents();   
        /// @brief Переключить на следующий элемента
        void Next();
        /// @brief Переключить на предыдущий элемент
        void Previous();
        /// @brief Переключить на следующую группу
        void NextGroup();
        /// @brief Переключить на предыдущую группу
        void PreviousGroup();
    };
    #define Grid_Size (sizeof(Grid))

    /// @brief Стека с цифровыми значениями
    class GridBitValues : public Component {
      static constexpr uint8_t str_length {10};
      inline static    char    str[str_length];  
      public:
        tScheme       place_schema        { tScheme::ShemeByRow };  /* Схема размещения внутренних компонентов */
        uint8_t       vol_horizontal_line {1};          /* Кол-во компонентов по горизонтали */
        uint8_t       vol_vertical_line   {4};          /* Кол-во компонентов по вертикали */
        tProportion*  proportion          { nullptr };
        uint8_t       index               {};   /* Индекс текущего элемента */
        uint8_t       volume              {};   /* Объем компонентов */
        uint8_t       group               {};   /* Текущая группа компонентов Draw. [volume / (vol_hor * vol_vertical)] * numb_group  */
        uint32_t*     p_value;
        char*         txt_on;
        char*         txt_off;
        char*         txt_separator;
        RecordBitField lbl_record;
        // bool          is_brigth;
      
        GridBitValues(tguiapis gui_apis);
        GridBitValues(tguiapis gui_apis, BordersR bordrs);
        BordersR GetBorder(uint8_t index);
        virtual void Draw() override;
        void NextItem(bool change_brigth /* = false */);
        void NextItem();
        void PreviousItem(bool change_brigth/* = false */);
        void PreviousItem();
        void NextGroup(bool change_brigth /* = false */);
        void NextGroup();
        void PreviousGroup(bool change_brigth/* = false */);
        void PreviousGroup();
    };
    #define UC_GRIDDGVALUE_SIZE (sizeof(GridBitValues))

    /// @brief Сетка для WLTS
    class TableWLTS : public Component {
      public:
        RecordWLTS row_header;
        RecordWLTS row_record;
        RecordWLTS::uc_rec_wlts_limits limits {
          .num  = 40,
          .ser  = 96,
          .val  = 58,
          .rssi = 30,
          .bound  = 4
        };
        const uint8_t vol_horizontal_line {1};  /* Кол-во компонентов по горизонтали */
        const uint8_t vol_vertical_line   {4};  /* Кол-во компонентов по вертикали */
        const uint8_t vol_vertical_line_it{3};  /* Кол-во компонентов по вертикали */
        const uint8_t header_height       {14}; /* Высота заголовока */
        uint8_t       index               {};   /* Индекс текущего элемента */
        uint8_t       index_display_offs  {};   /* Смещение индекса отображения */
        uint8_t       volume              {};   /* Объем компонентов */
        uint8_t       group               {};   /* Текущая группа компонентов Draw. [volume / (vol_hor * vol_vertical)] * numb_group  */
        bool          is_br_rectangle {};
        struct table_rec_wlts {
          uint32_t serial;
          float    temp;
          int8_t   rssi;
        }* vals_table { 
          nullptr 
        };
        #define TABLE_RECS_Size (sizeof(vals_table))

        TableWLTS(tguiapis gui_api);
        TableWLTS(tguiapis gui_api, BordersR bordrs);
        virtual void Draw() override;
        BordersR GetBorder(uint8_t index);
        void NextItem();
        void PreviuosItem();
        void NextGroup();
        void PreviuosGroup();
    };
    #define UC_GRIDWLTS_Size (sizeof(TableWLTS))
    
    /// @brief Сетка для WLTS
    class TableWLTS2V : public Component {
      public:
        RecordWLTS2V row_header;
        RecordWLTS2V row_record;
        RecordWLTS2V::uc_rec_wlts_limits limits {
          .num    = 32,
          .ser    = 58,
          .val    = 54,
          .volt   = 48,
          .rssi   = 30,
          .bound  = 4
        };
        const uint8_t vol_horizontal_line {1};  /* Кол-во компонентов по горизонтали */
        const uint8_t vol_vertical_line   {4};  /* Кол-во компонентов по вертикали */
        const uint8_t vol_vertical_line_it{3};  /* Кол-во компонентов по вертикали */
        const uint8_t header_height       {14}; /* Высота заголовока */
        uint8_t       index               {};   /* Индекс текущего элемента */
        uint8_t       index_display_offs  {};   /* Смещение индекса отображения */
        uint8_t       volume              {};   /* Объем компонентов */
        uint8_t       group               {};   /* Текущая группа компонентов Draw. [volume / (vol_hor * vol_vertical)] * numb_group  */
        bool          is_br_rectangle {};
        struct table_rec_wlts {
          uint32_t serial;
          float    temp;
          float    volt;
          int8_t   rssi;
        }* vals_table { 
          nullptr 
        };
        #define TABLE_RECS_Size (sizeof(vals_table))

        TableWLTS2V(tguiapis gui_api);
        TableWLTS2V(tguiapis gui_api, BordersR bordrs);
        virtual void Draw() override;
        BordersR GetBorder(uint8_t index);
        void NextItem();
        void PreviuosItem();
        void NextGroup();
        void PreviuosGroup();
    };
    #define UC_GRIDWLTS2V_Size (sizeof(TableWLTS2V))

    /// @brief Обозначение кнопок на экране
    class Mark : public Component {
      public:
        Images::tImageAlias image_alias;

        Mark(tguiapis gui_apis);
        Mark(tguiapis gui_apis, BordersR bordrs);
        Mark(tguiapis gui_apis, BordersR bordrs, Images::tImageAlias image);
        virtual void Draw() override; 
    };
    #define UC_MARK_Size (sizeof(Mark))

  };

#endif