#include "UControls.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>

using namespace UCPrime;

#pragma region    [UserPrimitives]

  uint8_t UCPrime::GetLastIndex(tguiapis* drv, const char* text, uint16_t pix_len_lim) {
    uint8_t res_index  {0};
    if(drv != nullptr && text != nullptr) {
      uint16_t symb_len = strlen(text);
      uint16_t length {0};
      for(uint8_t i = 0; i < symb_len; ++i) {
        length += drv->font->GetWidth((uint8_t)(*(uint8_t*)&text[i]));
        if(length <= pix_len_lim) res_index++;
        else                      break; 
      }
    }
    return res_index;
  }

  Point::Point() {}
  Point::Point(uint8_t x, uint8_t y) : x(x), y(y) {}
  Point::Point(const UCPrime::Point& p) : x(p.x), y(p.y) {}

  BordersR::BordersR() {}
  BordersR::BordersR(Point p, uint8_t w, uint8_t h) : p(p), width(w), height(h) {}
  BordersR::BordersR(Point p0, Point p1) {
    p       = p0;
    width   = p1.x - p0.x;
    height  = p1.y - p0.y;
  }
  BordersR::BordersR(const UCPrime::BordersR& bordrs) : p(bordrs.p), width(bordrs.width), height(bordrs.height) {}

  Component::Component(tguiapis gui_apis) : gui_apis(gui_apis) {}
  Component::Component(tguiapis gui_apis, BordersR bordrs) : border(bordrs), gui_apis(gui_apis) {}
  
  Label::Label(tguiapis gui_apis) : Component(gui_apis) {}
  Label::Label(tguiapis gui_apis, char* txt) : Component(gui_apis), text (txt) {}
  Label::Label(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs) {}
  Label::Label(tguiapis gui_apis, BordersR bordrs, char* txt) : Component(gui_apis, bordrs), text (txt) {}
  
  void Label::Draw() {
    if( gui_apis.font == nullptr || gui_apis.gfx == nullptr || gui_apis.images == nullptr || 
        text == nullptr)
      return;

    char*     rus_text    = StringConverter::UTF8ToCP1251(text);
    uint16_t  symb_length = strlen(rus_text);                   /* Длина в символах */
    uint16_t  pix_length  = gui_apis.font->GetWidth(rus_text);  /* Длина в пикселях */
    uint8_t   pix_heigth  = gui_apis.font->GetHigh();

    uint16_t  res_x { border.p.x };
    uint16_t  res_y { border.p.y };
    switch(align_h) {
      case tHrzAlign::h_align_left:  /* res_x = p0.x; */ width_ofield = border.width;     break;
      case tHrzAlign::h_align_centr: res_x += (border.width - pix_length)/2; width_ofield = border.width /* / 2 */ - (res_x - border.p.x); break;
      case tHrzAlign::h_align_rigth: res_x += (border.width - pix_length);   width_ofield = border.width - pix_length; break;
      default: break;
    };
    switch(align_v) {
      case tVrtAlign::v_align_up:    /* res_y += (border.height - pix_heigth)/2; */    break;
      case tVrtAlign::v_align_centr: res_y += (border.height - pix_heigth)/2; break;
      case tVrtAlign::v_align_down:  res_y += border.height - pix_heigth;     break;
      default: break;
    }

    if(width_ofield != 0) {
     
      if(pix_length > width_ofield) {
        /* Выводим неполную строку, так как размер превышает длину поля */
        if(iteration == 0) {
          Label_NewIteration:
            end_index = GetLastIndex(&gui_apis, &rus_text[start_index], width_ofield);
            gui_apis.font->DrawText((const char*)&rus_text[start_index], res_x, res_y, end_index, !is_brigth, index_symb_brigth);
            iteration++;
        }
        else if(iteration != iterations) {
          /* Вывод строки между итерациями */
          gui_apis.font->DrawText((const char*)&rus_text[start_index], res_x, res_y, end_index, !is_brigth, index_symb_brigth);
          iteration++;
        }
        else {
          /* Смещение вывода строки */
          iteration = 0;
          if((symb_length) == (start_index + end_index)) {
            start_index = 0;
            end_index = 0;
          }
          else {
            start_index++;
            if(start_index >= symb_length) {
              start_index = 0;
              end_index = 0;
            }
          }
          goto Label_NewIteration;
        }
      }
      else {
        gui_apis.font->DrawText(rus_text, res_x, res_y, (uint8_t)!is_brigth, index_symb_brigth);
      }
    }
    else {
      gui_apis.font->DrawText(rus_text, res_x, res_y, (uint8_t)!is_brigth, index_symb_brigth);
    }
  }

  Title::Title(tguiapis gui_apis, BordersR bordrs, const char* txt) : Label(gui_apis, bordrs, (char*)txt) {
    /* Используем для вывода p0 */
    align_h = tHrzAlign::h_align_centr;
    align_v = tVrtAlign::v_align_up;
  }

  RecordValue::RecordValue(tguiapis gui_apis) 
    : Component(gui_apis), 
    lbl_name(gui_apis), 
    lbl_separator(gui_apis),
    lbl_value(gui_apis, (char*)string_value) {
  }
  RecordValue::RecordValue(tguiapis gui_apis, char* txt) 
    : Component(gui_apis), 
    lbl_name(gui_apis, txt),
    lbl_separator(gui_apis), 
    lbl_value(gui_apis, (char*)string_value) {
  }
  RecordValue::RecordValue(tguiapis gui_apis, BordersR bordrs) 
    : Component(gui_apis, bordrs), 
    lbl_name(gui_apis, bordrs),
    lbl_separator(gui_apis, bordrs), 
    lbl_value(gui_apis, bordrs, (char*)string_value) {
  }
  RecordValue::RecordValue(tguiapis gui_apis, BordersR bordrs, char* txt) 
    : Component(gui_apis, bordrs), 
    lbl_name(gui_apis, bordrs, txt),
    lbl_separator(gui_apis, bordrs), 
    lbl_value(gui_apis, bordrs, (char*)string_value) 
  /* Methods: */
  {
  }

  void RecordValue::Draw() {
    if(gui_apis.font == nullptr && gui_apis.gfx == nullptr && gui_apis.images == nullptr)
      return;
    #if 1 // new with Border
      /*
        - Уставнавливаем границы для надписей, поровну для всех
      */
     uint8_t 
        img_w { 0 },   /* Ширина изображения */
        // img_h { 0 },   /* Высота изображения */
        img_x { 0 },   /* по оси х */
        img_y { 0 };   /* по оси у */

      lbl_separator.border.height = border.height;
      lbl_name.border.height = border.height;
      lbl_value.border.height = border.height;
      if(image_units != Images::tImageAlias::img_null) {
        /* img_h range 14 downto 10 */
        gui_apis.images->SetImage(image_units);
        img_w = gui_apis.images->GetWidth() + 2 * (proportion != nullptr ? proportion->div_3 : 1.0f);
        // img_h = gui_apis.images->GetHigh();
      }

      lbl_separator.border.width  = gui_apis.font->GetWidth(lbl_separator.text) * (proportion != nullptr ? proportion->div_1 : 1.0f) + 2;
      lbl_name.border.width       = ((border.width - lbl_separator.border.width - img_w) * (proportion != nullptr ? proportion->div_0 : 1.0f)) / 2;
      lbl_value.border.width      = lbl_name.border.width * (proportion != nullptr ? proportion->div_2 : 1.0f);

      lbl_name.border.p.x       = border.p.x;
      lbl_separator.border.p.x  = border.p.x + lbl_name.border.width;
      lbl_value.border.p.x      = lbl_separator.border.p.x + lbl_separator.border.width;
      img_x                     = lbl_value.border.p.x + lbl_value.border.width;

      lbl_name.border.p.y       = border.p.y;
      lbl_separator.border.p.y  = border.p.y;
      lbl_value.border.p.y      = border.p.y;
      img_y                     = border.p.y;

      lbl_name.Draw();
      lbl_separator.Draw();
      memset(string_value, 0, sizeof(string_value));
      if(p_int_value != nullptr) {
        StringConverter::IntToString(string_value, sizeof(string_value), *p_int_value);
      }
      else if(p_flt_value != nullptr) {
        // StringConverter::FloatToString(string_value, sizeof(string_value), p_flt_value);
        StringConverter::f_to_str(string_value, sizeof(string_value), *p_flt_value);
      }
      else {
        if(err_value != nullptr) {
          char* p_loc = StringConverter::UTF8ToCP1251(err_value); 
          memcpy(string_value, p_loc, strlen(p_loc));
        }
        else if(none_value != nullptr) {
          char* p_loc = StringConverter::UTF8ToCP1251(none_value); 
          memcpy(string_value, p_loc, strlen(p_loc));
        }
      }
      lbl_value.text = (char*)string_value;
      lbl_value.Draw();
      if(image_units != Images::tImageAlias::img_null) {
        gui_apis.images->DrawImage(img_x, img_y, is_brigth);
      }

    #elif 0 // old with Point debuggzzzzzz
    memset(string_value, 0, sizeof(string_value));
    /* Последовательно заполняем Х в элементах так, что бы следующий обращался к предыдущему. */
    /* Добавить назначение координат  */
    lbl_name.border.p.x = border.p.x;
    lbl_name.border.p.y = border.p.y;
    lbl_name.Draw();
    /* Выставляем коорд. x для "разделителя" */
    if(lbl_name.width_ofield != 0)
      lbl_separator.p0.x = lbl_name.p0.x + lbl_name.width_ofield + 1;
    else
      lbl_separator.p0.x = lbl_name.p0.x + gui_apis.font->GetWidth(lbl_name.text);
    lbl_separator.p0.y  = p0.y;
    /* Рисуем разделитель, если он есть */
    if(lbl_separator.text != nullptr) {
      lbl_separator.Draw();
      lbl_value.p0.x  = lbl_separator.p0.x + gui_apis.font->GetWidth(lbl_separator.text) + 1;
      lbl_value.p0.y  = p0.y;
    }
    else {
      lbl_value.p0.x  = lbl_separator.p0.x;
      lbl_value.p0.y  = p0.y;
    }
    /* Рисуем значение */
    if(p_int_value != nullptr) {
      StringConverter::IntToString(string_value, sizeof(string_value), *p_int_value);
    }
    else if(p_flt_value != nullptr) {
      StringConverter::FloatToString(string_value, sizeof(string_value), p_flt_value);
    }
    lbl_value.text = (char*)string_value;
    lbl_value.Draw();
    /* Если есть единицы измерения, то рисуем... */
    uint16_t x { 0 };
    if(lbl_value.width_ofield != 0)
      x = lbl_name.p0.x + lbl_name.width_ofield + 3 + lbl_value.width_ofield;
    else
      x = lbl_name.p0.x + lbl_name.width_ofield + gui_apis.font->GetWidth(lbl_name.text) + 3;
    if(image_units != Images::ImageAlias::img_null) {
      gui_apis.images->SetImage(image_units);
      gui_apis.images->DrawImage(
        x, //lbl_value.p0.x + 2 + gui_apis.font->GetWidth((char*)string_value),
        lbl_value.p0.y 
      );
    }
    #endif
  }

  RecordString::RecordString(tguiapis gui_apis) 
    : Component(gui_apis), 
    lbl_name(gui_apis), 
    lbl_separator(gui_apis),
    lbl_value(gui_apis, (char*)string_value) {
  }
  RecordString::RecordString(tguiapis gui_apis, char* txt) 
    : Component(gui_apis), 
    lbl_name(gui_apis, txt),
    lbl_separator(gui_apis), 
    lbl_value(gui_apis, (char*)string_value) {
  }
  RecordString::RecordString(tguiapis gui_apis, BordersR bordrs) 
    : Component(gui_apis, bordrs), 
    lbl_name(gui_apis, bordrs),
    lbl_separator(gui_apis, bordrs), 
    lbl_value(gui_apis, bordrs, (char*)string_value) {
  }
  RecordString::RecordString(tguiapis gui_apis, BordersR bordrs, char* txt) 
    : Component(gui_apis, bordrs), 
    lbl_name(gui_apis, bordrs, txt),
    lbl_separator(gui_apis, bordrs), 
    lbl_value(gui_apis, bordrs, (char*)string_value) 
  /* Methods: */
  {
  }

  void RecordString::Draw() {
    if(gui_apis.font == nullptr && gui_apis.gfx == nullptr && gui_apis.images == nullptr)
      return;
   
    lbl_separator.border.height   = border.height;
    lbl_name.border.height        = border.height;
    lbl_value.border.height       = border.height;

    lbl_separator.border.width  = gui_apis.font->GetWidth(lbl_separator.text) + 2;
    lbl_name.border.width       = (border.width - lbl_separator.border.width) / proportion;
    // lbl_value.border.width      = lbl_name.border.width;
    lbl_value.border.width      = border.width - lbl_name.border.width - lbl_separator.border.width;

    lbl_name.border.p.x       = border.p.x;
    lbl_separator.border.p.x  = border.p.x + lbl_name.border.width;
    lbl_value.border.p.x      = lbl_separator.border.p.x + lbl_separator.border.width;
    
    lbl_name.border.p.y       = border.p.y;
    lbl_separator.border.p.y  = border.p.y;
    lbl_value.border.p.y      = border.p.y;
    
    lbl_name.Draw();
    lbl_separator.Draw();
    memset(string_value, 0, sizeof(string_value));
    lbl_value.Draw();
  }

  RecordWLTS::RecordWLTS(tguiapis gui_apis) 
  /* Inits:: */
  : Component(gui_apis), 
    lbl_num(gui_apis),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_rssi(gui_apis)
  /**/{
  }
  RecordWLTS::RecordWLTS(tguiapis gui_apis, char* txt) 
  /* Inits:: */
  : Component(gui_apis), 
    lbl_num(gui_apis, txt),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_rssi(gui_apis)
  /**/{  
  }
  RecordWLTS::RecordWLTS(tguiapis gui_apis, BordersR bordrs) 
  /* Inits:: */
    : Component(gui_apis, bordrs), 
    lbl_num(gui_apis),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_rssi(gui_apis)
  /**/{
  }
  RecordWLTS::RecordWLTS(tguiapis gui_apis, BordersR bordrs, char* txt) 
  /* Inits:: */
    : Component(gui_apis, bordrs), 
    lbl_num(gui_apis, txt),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_rssi(gui_apis) 
  /**/{
  }

  void RecordWLTS::Draw(){
    if(gui_apis.font == nullptr && gui_apis.gfx == nullptr && gui_apis.images == nullptr)
      return;

    uint8_t 
      lim_num   { 40 },
      lim_ser   { 96 },
      lim_val   { 58 },
      lim_rssi  { 30 },
      lim_bound { 4  };
    
    if(limits != nullptr) {
      lim_num   = limits->num;
      lim_ser   = limits->ser;
      lim_val   = limits->val;
      lim_rssi  = limits->rssi;
      lim_bound = limits->bound;
    }
    
    lbl_num.border.height       = border.height;
    lbl_serial.border.height    = border.height;
    lbl_value.border.height     = border.height;
    lbl_rssi.border.height      = border.height;
    
    lbl_num.border.width       = lim_num - lim_bound;
    lbl_serial.border.width    = lim_ser - lim_bound;
    lbl_value.border.width     = lim_val - lim_bound;
    lbl_rssi.border.width      = lim_rssi - lim_bound;

    lbl_num.border.p.x       = border.p.x;
    lbl_serial.border.p.x    = lbl_num.border.p.x + lbl_num.border.width + lim_bound;
    lbl_value.border.p.x     = lbl_serial.border.p.x + lbl_serial.border.width + lim_bound;
    lbl_rssi.border.p.x      = lbl_value.border.p.x + lbl_value.border.width + lim_bound;

    lbl_num.border.p.y       = border.p.y;
    lbl_serial.border.p.y    = border.p.y;
    lbl_value.border.p.y     = border.p.y;
    lbl_rssi.border.p.y      = border.p.y;

    lbl_num.align_h     = align_h;
    lbl_num.align_v     = align_v;
    lbl_serial.align_h  = align_h;
    lbl_serial.align_v  = align_v;
    lbl_value.align_h   = align_h;
    lbl_value.align_v   = align_v;
    lbl_rssi.align_h    = align_h;
    lbl_rssi.align_v    = align_v;

    lbl_num.is_brigth     = is_brigth;
    lbl_serial.is_brigth  = is_brigth;
    lbl_value.is_brigth   = is_brigth;
    lbl_rssi.is_brigth    = is_brigth;
    
    lbl_num.Draw();
    lbl_serial.Draw();
    lbl_value.Draw();
    lbl_rssi.Draw();
  }

  RecordWLTS2V::RecordWLTS2V(tguiapis gui_apis) 
  /* Inits:: */
  : Component(gui_apis), 
    lbl_num(gui_apis),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_volt(gui_apis),
    lbl_rssi(gui_apis)
  /**/{
  }
  RecordWLTS2V::RecordWLTS2V(tguiapis gui_apis, char* txt) 
  /* Inits:: */
  : Component(gui_apis), 
    lbl_num(gui_apis, txt),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_volt(gui_apis),
    lbl_rssi(gui_apis)
  /**/{  
  }
  RecordWLTS2V::RecordWLTS2V(tguiapis gui_apis, BordersR bordrs) 
  /* Inits:: */
    : Component(gui_apis, bordrs), 
    lbl_num(gui_apis),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_volt(gui_apis),
    lbl_rssi(gui_apis)
  /**/{
  }
  RecordWLTS2V::RecordWLTS2V(tguiapis gui_apis, BordersR bordrs, char* txt) 
  /* Inits:: */
    : Component(gui_apis, bordrs), 
    lbl_num(gui_apis, txt),
    lbl_serial(gui_apis),
    lbl_value(gui_apis),
    lbl_volt(gui_apis),
    lbl_rssi(gui_apis) 
  /**/{
  }

  void RecordWLTS2V::Draw(){
    if(gui_apis.font == nullptr && gui_apis.gfx == nullptr && gui_apis.images == nullptr)
      return;

    uint8_t 
      lim_num   { 32 },
      lim_ser   { 58 },
      lim_val   { 56 },
      lim_volt  { 48 },
      lim_rssi  { 30 },
      lim_bound { 4  };          
       
    if(limits != nullptr) {
      lim_num   = limits->num;
      lim_ser   = limits->ser;
      lim_val   = limits->val;
      lim_volt  = limits->volt;
      lim_rssi  = limits->rssi;
      lim_bound = limits->bound;
    }
    
    lbl_num.border.height       = border.height;
    lbl_serial.border.height    = border.height;
    lbl_value.border.height     = border.height;
    lbl_volt.border.height      = border.height;
    lbl_rssi.border.height      = border.height;
    
    lbl_num.border.width       = lim_num - lim_bound;
    lbl_serial.border.width    = lim_ser - lim_bound;
    lbl_value.border.width     = lim_val - lim_bound;
    lbl_volt.border.width      = lim_volt - lim_bound;
    lbl_rssi.border.width      = lim_rssi - lim_bound;

    lbl_num.border.p.x       = border.p.x;
    lbl_serial.border.p.x    = lbl_num.border.p.x     + lbl_num.border.width    + lim_bound;
    lbl_value.border.p.x     = lbl_serial.border.p.x  + lbl_serial.border.width + lim_bound;
    lbl_volt.border.p.x      = lbl_value.border.p.x   + lbl_value.border.width  + lim_bound;
    lbl_rssi.border.p.x      = lbl_volt.border.p.x    + lbl_volt.border.width   + lim_bound;

    lbl_num.border.p.y       = border.p.y;
    lbl_serial.border.p.y    = border.p.y;
    lbl_value.border.p.y     = border.p.y;
    lbl_volt.border.p.y      = border.p.y;
    lbl_rssi.border.p.y      = border.p.y;

    lbl_num.align_h     = align_h;
    lbl_num.align_v     = align_v;
    lbl_serial.align_h  = align_h;
    lbl_serial.align_v  = align_v;
    lbl_value.align_h   = align_h;
    lbl_value.align_v   = align_v;
    lbl_volt.align_h    = align_h;
    lbl_volt.align_v    = align_v;
    lbl_rssi.align_h    = align_h;
    lbl_rssi.align_v    = align_v;

    lbl_num.is_brigth     = is_brigth;
    lbl_serial.is_brigth  = is_brigth;
    lbl_value.is_brigth   = is_brigth;
    lbl_volt.is_brigth    = is_brigth;
    lbl_rssi.is_brigth    = is_brigth;

    lbl_num.Draw();
    lbl_serial.Draw();
    lbl_value.Draw();
    lbl_volt.Draw();
    lbl_rssi.Draw();
  }

  RecordBitField::RecordBitField(tguiapis gui_apis) : Component(gui_apis), 
  lbl_name(gui_apis),
  lbl_separator(gui_apis),
  lbl_value(gui_apis) {}
  
  RecordBitField::RecordBitField(tguiapis gui_apis, char* txt) : Component(gui_apis),
  lbl_name(gui_apis, txt),
  lbl_separator(gui_apis),
  lbl_value(gui_apis) {}
  
  RecordBitField::RecordBitField(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs),
  lbl_name(gui_apis),
  lbl_separator(gui_apis),
  lbl_value(gui_apis) {}
  
  RecordBitField::RecordBitField(tguiapis gui_apis, BordersR bordrs, char* txt) : Component(gui_apis, bordrs),
  lbl_name(gui_apis),
  lbl_separator(gui_apis),
  lbl_value(gui_apis) {}

  void RecordBitField::Draw() {
    if(gui_apis.font == nullptr && gui_apis.gfx == nullptr && gui_apis.images == nullptr)
      return;
    
    uint8_t condition {};
    char*   txt_cond  {};

    lbl_separator.border.height = border.height;
    lbl_name.border.height = border.height;
    lbl_value.border.height = border.height;

    lbl_separator.border.width  = gui_apis.font->GetWidth(lbl_separator.text) * (proportion != nullptr ? proportion->div_1 : 1.0f) + 2;
    lbl_name.border.width       = ((border.width - lbl_separator.border.width) * (proportion != nullptr ? proportion->div_0 : 1.0f)) / 2;
    lbl_value.border.width      = lbl_name.border.width * (proportion != nullptr ? proportion->div_2 : 1.0f);

    lbl_name.border.p.x       = border.p.x;
    lbl_separator.border.p.x  = border.p.x + lbl_name.border.width;
    lbl_value.border.p.x      = lbl_separator.border.p.x + lbl_separator.border.width;

    lbl_name.border.p.y       = border.p.y;
    lbl_separator.border.p.y  = border.p.y;
    lbl_value.border.p.y      = border.p.y;

    lbl_name.Draw();
    lbl_separator.Draw();

    condition = p_digi_value != nullptr ? (uint8_t)(((*p_digi_value) >> index_value & 1)) : condition;
    txt_cond = condition ? txt_cond_on : txt_cond_off;
    if(txt_cond != nullptr) {
      lbl_value.text = txt_cond;
      lbl_value.is_brigth = is_brigth;
      lbl_value.Draw();
    }
  }

  U4DPassword::U4DPassword(tguiapis gui_apis) : Component(gui_apis), lbl_pwd(gui_apis) {}
  U4DPassword::U4DPassword(tguiapis gui_apis, char* txt) : Component(gui_apis), lbl_pwd(gui_apis, txt) {}
  U4DPassword::U4DPassword(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs), lbl_pwd(gui_apis, bordrs) {}
  U4DPassword::U4DPassword(tguiapis gui_apis, BordersR bordrs, char* txt) : Component(gui_apis, bordrs), lbl_pwd(gui_apis, bordrs, txt) {}
  void U4DPassword::Draw() {
    lbl_pwd.text              = str_pwd;
    lbl_pwd.border            = border;
    lbl_pwd.align_h           = align_h;
    lbl_pwd.align_v           = align_v;
    lbl_pwd.index_symb_brigth = index;
    lbl_pwd.Draw();
  }
  void U4DPassword::NextDigit() {
    if(index < max_index) index++;
    else                  index = 0;
  }
  void U4DPassword::PrevDigit() {
    if(index > 0) index--;
    else          index = max_index;
  }
  void U4DPassword::Increment() {
    if( ((uint8_t)str_pwd[index]) < bound_high) str_pwd[index]++;
    else                                        str_pwd[index] = bound_low;
  }
  void U4DPassword::Decrement() {
    if( ((uint8_t)str_pwd[index]) > bound_low) str_pwd[index]--;
    else                                       str_pwd[index] = bound_high;
  }

  UMDEntryValue::UMDEntryValue(tguiapis gui_apis) : Component(gui_apis), lbl_value(gui_apis) {}
  UMDEntryValue::UMDEntryValue(tguiapis gui_apis, char* txt) : Component(gui_apis), lbl_value(gui_apis, txt) {}
  UMDEntryValue::UMDEntryValue(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs), lbl_value(gui_apis, bordrs) {}
  UMDEntryValue::UMDEntryValue(tguiapis gui_apis, BordersR bordrs, char* txt) : Component(gui_apis, bordrs), lbl_value(gui_apis, bordrs, txt) {}
  void UMDEntryValue::Draw() {
    lbl_value.text              = str_value;
    lbl_value.border            = border;
    lbl_value.align_h           = align_h;
    lbl_value.align_v           = align_v;
    lbl_value.index_symb_brigth = index;
    lbl_value.Draw();
  }
  void UMDEntryValue::NextDigit() {
    if(index < max_index) index++;
    else                  index = 0;
  }
  void UMDEntryValue::PrevDigit() {
    if(index > 0) index--;
    else          index = max_index;
  }
  void UMDEntryValue::Increment() {
    if( ((uint8_t)str_value[index]) < bound_high) str_value[index]++;
    else                                          str_value[index] = bound_low;
  }
  void UMDEntryValue::Decrement() {
    if( ((uint8_t)str_value[index]) > bound_low) str_value[index]--;
    else                                         str_value[index] = bound_high;
  }
  int UMDEntryValue::Getvalue(){
    return std::atoi((char*)str_value);
  }
  
  UMDValue::UMDValue(tguiapis gui_apis) : Component(gui_apis), lbl_value(gui_apis) {}
  UMDValue::UMDValue(tguiapis gui_apis, char* txt) : Component(gui_apis), lbl_value(gui_apis, txt) {}
  UMDValue::UMDValue(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs), lbl_value(gui_apis, bordrs) {}
  UMDValue::UMDValue(tguiapis gui_apis, BordersR bordrs, char* txt) : Component(gui_apis, bordrs), lbl_value(gui_apis, bordrs, txt) {}
  void UMDValue::Draw() {
    StringConverter::IntToString(str, sizeof(str), value);
    lbl_value.text              = (char*)str; 
    lbl_value.border            = border;
    lbl_value.align_h           = align_h;
    lbl_value.align_v           = align_v;
    lbl_value.Draw();
  }
  void UMDValue::NextDigit() { return; }
  void UMDValue::PrevDigit() { return; }
  void UMDValue::Increment() {
    if(value < limit_up)  value++;
    else                  value = limit_low;
  }
  void UMDValue::Decrement() {
    if(value > limit_low) value--;
    else                  value = limit_up;
  }

  UBoolValue::UBoolValue(tguiapis gui_apis) : Component(gui_apis), lbl_value(gui_apis) {}
  UBoolValue::UBoolValue(tguiapis gui_apis, char* txt): Component(gui_apis), lbl_value(gui_apis, txt) {}
  UBoolValue::UBoolValue(tguiapis gui_apis, BordersR bordrs): Component(gui_apis, bordrs), lbl_value(gui_apis, bordrs) {}
  UBoolValue::UBoolValue(tguiapis gui_apis, BordersR bordrs, char* txt): Component(gui_apis, bordrs), lbl_value(gui_apis, bordrs, txt) {}
  void UBoolValue::Draw(){
    lbl_value.text    = value == true ? (char*)b_str_true : (char*)b_str_false;
    lbl_value.border  = border;
    lbl_value.align_h = align_h;
    lbl_value.align_v = align_v;
    lbl_value.Draw();
  }
  void UBoolValue::Change(){
    value = !value;
  }

  Grid::Grid(tguiapis gui_apis) : Component(gui_apis) {
    component = components[0];
  }
  Grid::Grid(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs) {
    component = components[0];
  }
  void Grid::Draw() {
    uint8_t 
      group_vol   {},   /* Объем группы  */
      group       {},   /* Текущая группа */
      index_begin {},
      index_end   {};

    group_vol     = (uint8_t) vol_horizontal_line * vol_vertical_line;
    group         = (uint8_t) index / group_vol;
    index_begin   = (uint8_t) group * group_vol;
    index_end     = (uint8_t) index_begin + group_vol;

    if(index_end > volume)
      index_end = volume;

    for(uint16_t i = index_begin; i < index_end; ++i) {
      if(components[i] != nullptr) {
        components[i]->Draw();
      }
    }
  }
  Point Grid::GetPoint(uint8_t index) {
    Point point {};
    #if 0 // Deprecated
    uint16_t res_x { 0 };
    uint16_t res_y { 0 };
   
    uint16_t pos_horizontal = index % vol_horizontal_line + 1;
    uint16_t pos_vertical   = index % vol_vertical_line + 1;

    uint16_t width = p1.x - p0.x;
    uint16_t height = p1.y - p0.y;
    // uint16_t width = border.w;
    uint16_t height = p1.y - p0.y;
    uint16_t field_width  = width / vol_horizontal_line;
    uint16_t field_height = height / vol_vertical_line; 
    
    res_x = p0.x + (pos_horizontal * field_width);
    res_y = p0.y + (pos_vertical * field_height);

    switch(align_h) {
      case tHrzAlign::h_align_left:  res_x -= field_width;    break;
      case tHrzAlign::h_align_centr: res_x -= field_width/2;  break;
      case tHrzAlign::h_align_rigth: break;
      default: break;
    };
    switch(align_v) {
      case tVrtAlign::v_align_up:    res_y -= field_height;    break;
      case tVrtAlign::v_align_centr: res_y -= field_height/2;  break;
      case tVrtAlign::v_align_down:  break;
      default: break;
    }

    point.x = res_x;
    point.y = res_y;
    #endif
    return point;
  }
  BordersR Grid::GetBorder(uint8_t index) {
    BordersR res_border {};
    uint16_t 
      pos_horizontal  {},
      pos_vertical    {},
      width           {},
      height          {},
      field_width     {},
      field_height    {};
    
    /* По схеме: заполняем сначала строки сверху вниз */
    pos_horizontal = index % vol_horizontal_line;   
    pos_vertical   = (index / vol_horizontal_line) % vol_vertical_line;

    width = border.width;
    height = border.height;
    field_width  = width / vol_horizontal_line;
    field_height = height / vol_vertical_line; 

    res_border.width  = field_width;
    res_border.height = field_height;
    res_border.p.x    = border.p.x + (pos_horizontal * field_width);
    res_border.p.y    = border.p.y + (pos_vertical   * field_height);
    
    return res_border;
  }
  void Grid::AlignComponents(){
    for(uint16_t i = 0; i < volume; ++i) {
      if(components[i] != nullptr) {
        components[i]->border = GetBorder(i);
        components[i]->align_h = align_h;
        components[i]->align_v = align_v;
      }
    }
  }
  void Grid::Next(/* change_brigth */) {
    components[index]->is_brigth = false;
    if(index < (volume - 1)) index++;
    else                     index = 0;
    components[index]->is_brigth = true;
    component = components[index];
  }
  void Grid::Previous(/* change_brigth */) {
    components[index]->is_brigth = false;
    if(index > 0) index--;
    else          index = volume - 1;
    components[index]->is_brigth = true;
    component = components[index];
  }
  void Grid::NextGroup(){
    uint16_t vol_group = vol_horizontal_line * vol_vertical_line;
    int16_t i = (index / vol_group + 1) * vol_group;
    if(i >= volume) index = volume - 1;
    else index = i;
  }
  void Grid::PreviousGroup(){
    int16_t vol_group = vol_horizontal_line * vol_vertical_line;
    int16_t i = (index / vol_group - 1) * vol_group;
    if(i < 0) index = 0;
    else index = i;
  }

  GridBitValues::GridBitValues(tguiapis gui_apis) : Component(gui_apis), lbl_record(gui_apis) {}
  GridBitValues::GridBitValues(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs), lbl_record(gui_apis) {}
  BordersR GridBitValues::GetBorder(uint8_t index) {
    BordersR res_border {};
    uint16_t 
      pos_horizontal  {},
      pos_vertical    {},
      width           {},
      height          {},
      field_width     {},
      field_height    {};
    
    /* По схеме: заполняем сначала строки сверху вниз */
    pos_horizontal = index % vol_horizontal_line;   
    pos_vertical   = (index / vol_horizontal_line) % vol_vertical_line;

    width = border.width;
    height = border.height;
    field_width  = width / vol_horizontal_line;
    field_height = height / vol_vertical_line; 

    res_border.width  = field_width;
    res_border.height = field_height;
    res_border.p.x    = border.p.x + (pos_horizontal * field_width);
    res_border.p.y    = border.p.y + (pos_vertical   * field_height);
    
    return res_border;
  }
  void GridBitValues::Draw() {
    uint8_t 
      group_vol   {},   /* Объем группы  */
      group       {},   /* Текущая группа */
      index_begin {},
      index_end   {};

    group_vol     = (uint8_t) vol_horizontal_line * vol_vertical_line;
    group         = (uint8_t) index / group_vol;
    index_begin   = (uint8_t) group * group_vol;
    index_end     = (uint8_t) index_begin + group_vol;

    if(index_end > volume)
      index_end = volume;

    for(uint16_t i = index_begin; i < index_end; ++i) {
      StringConverter::IntToString((uint8_t*)str, str_length, i+1);
      lbl_record.txt_cond_on    = txt_on;
      lbl_record.txt_cond_off   = txt_off;
      lbl_record.lbl_name.text        = (char*)str;
      lbl_record.lbl_separator.text   = (char*)txt_separator;
      // lbl_record.lbl_value.text
      lbl_record.proportion     = proportion;
      lbl_record.border         = GetBorder(i);
      lbl_record.p_digi_value   = p_value;
      lbl_record.index_value    = i;
      lbl_record.is_brigth = false;
      if(index == i && is_brigth) {
        lbl_record.is_brigth = true;
      }
      lbl_record.Draw();
    }
  }
  void GridBitValues::NextItem(bool change_brigth) {
    /* ... */
  }
  void GridBitValues::NextItem() {
    // components[index]->is_brigth = false;
    if(index < (volume - 1)) index++;
    else                     index = 0;
    // components[index]->is_brigth = true;
    // component = components[index];
  }
  void GridBitValues::PreviousItem(bool change_brigth) {
    /* ... */
  } 
  void GridBitValues::PreviousItem() {
    // components[index]->is_brigth = false;
    if(index > 0) index--;
    else          index = volume - 1;
    // components[index]->is_brigth = true;
    // component = components[index];
  }
  void GridBitValues::NextGroup(bool change_brigth) {
    uint16_t vol_group = vol_horizontal_line * vol_vertical_line;
    int16_t i = (index / vol_group + 1) * vol_group;
    if(i > volume) index = volume - 1;
    else index = i;
  }
  void GridBitValues::NextGroup() {
    NextGroup(false);
  }
  void GridBitValues::PreviousGroup(bool change_brigth) {
    int16_t vol_group = vol_horizontal_line * vol_vertical_line;
    int16_t i = (index / vol_group - 1) * vol_group;
    if(i < 0) index = 0;
    else index = i;
  }
  void GridBitValues::PreviousGroup() {
    PreviousGroup(false);
  }

  TableWLTS::TableWLTS(tguiapis gui_api) 
  /* Inits:: */  
    : Component(gui_api),
    row_header(gui_api),
    row_record(gui_api)
  /**/{
  }
  TableWLTS::TableWLTS(tguiapis gui_api, BordersR bordrs)
  /* Inits:: */  
    : Component(gui_api, bordrs),
    row_header(gui_api),
    row_record(gui_api)
  /**/{
  }
  void TableWLTS::Draw(){
    uint8_t 
      group_vol   {},   /* Объем группы  */
      group       {},   /* Текущая группа */
      index_begin {},
      index_end   {};

    group_vol     = (uint8_t) vol_horizontal_line * vol_vertical_line_it;
    group         = (uint8_t) index / group_vol;
    index_begin   = (uint8_t) group * group_vol;
    index_end     = (uint8_t) index_begin + group_vol;

    if(index_end > volume)
      index_end = volume;

    row_header.border = border;
    row_header.border.height = header_height;
    row_header.Draw();
    for(uint16_t i = index_begin; i < index_end; ++i) {
      uint8_t str_num[10] {};
      uint8_t str_ser[16] {};
      uint8_t str_val[8]  {};
      uint8_t str_rssi[8] {};

      StringConverter::IntToString(str_num, sizeof(str_num), (int32_t) (index_display_offs + i));
      StringConverter::IntToString(str_ser, sizeof(str_ser), vals_table[i /* - index_begin */].serial);
      // StringConverter::FloatToString(str_val, sizeof(str_val), &vals_table[i /* - index_begin */].temp);
      StringConverter::f_to_str(str_val, sizeof(str_val), vals_table[i /* - index_begin */].temp);
      StringConverter::IntToString(str_rssi, sizeof(str_rssi), vals_table[i /* - index_begin */].rssi);

      row_record.border           = GetBorder(i/* +1 */);
      row_record.lbl_num.text     = (char*)str_num;
      row_record.lbl_serial.text  = (char*)str_ser;
      row_record.lbl_value.text   = (char*)str_val;
      row_record.lbl_rssi.text    = (char*)str_rssi;

      // row_record.border.p.y

      row_record.is_brigth = false;
      if((index) == i && is_brigth) {
        row_record.is_brigth = true;
        gui_apis.gfx->DrawRectFilled(
          row_record.border.p.x, 
          row_record.border.p.y, 
          row_record.border.p.x + row_record.border.width, 
          row_record.border.p.y + row_record.border.height - limits.bound + 1, 
          0xf
        );
      }
      row_record.Draw();
    }
  }
  BordersR TableWLTS::GetBorder(uint8_t index){
    BordersR res_border {};
    uint16_t 
      pos_horizontal  {},
      pos_vertical    {},
      width           {},
      height          {},
      field_width     {},
      field_height    {};
    
    /* По схеме: заполняем сначала строки сверху вниз */
    pos_horizontal = index % vol_horizontal_line;
    pos_vertical   = (index / vol_horizontal_line) % vol_vertical_line_it;

    width = border.width;
    height = border.height - header_height;
    field_width  = width / vol_horizontal_line;
    field_height = height / vol_vertical_line_it;
    res_border.width  = field_width;
    res_border.height = field_height;
    res_border.p.x    = border.p.x + (pos_horizontal * field_width);
    res_border.p.y    = border.p.y + header_height + (pos_vertical   * field_height);
    
    return res_border;
  }
  void TableWLTS::NextItem(){
    if(index < (volume - 1)) index++;
    else                     index = 0;
  }
  void TableWLTS::PreviuosItem(){
    if(index > 0) index--;
    else          index = volume - 1;
  }

  TableWLTS2V::TableWLTS2V(tguiapis gui_api) 
  /* Inits:: */  
    : Component(gui_api),
    row_header(gui_api),
    row_record(gui_api)
  /**/{
  }
  TableWLTS2V::TableWLTS2V(tguiapis gui_api, BordersR bordrs)
  /* Inits:: */  
    : Component(gui_api, bordrs),
    row_header(gui_api),
    row_record(gui_api)
  /**/{
  }
  void TableWLTS2V::Draw(){
    uint8_t 
      group_vol   {},   /* Объем группы  */
      group       {},   /* Текущая группа */
      index_begin {},
      index_end   {};

    group_vol     = (uint8_t) vol_horizontal_line * vol_vertical_line_it;
    group         = (uint8_t) index / group_vol;
    index_begin   = (uint8_t) group * group_vol;
    index_end     = (uint8_t) index_begin + group_vol;

    if(index_end > volume)
      index_end = volume;

    row_header.border = border;
    row_header.border.height = header_height;
    row_header.Draw();
    for(uint16_t i = index_begin; i < index_end; ++i) {
      uint8_t str_num[10] {};
      uint8_t str_ser[16] {};
      uint8_t str_val[8]  {};
      uint8_t str_volt[8]  {};
      uint8_t str_rssi[8] {};

      StringConverter::IntToString(str_num, sizeof(str_num), (int32_t) (index_display_offs + i));
      StringConverter::IntToString(str_ser, sizeof(str_ser), vals_table[i /* - index_begin */].serial);
      // StringConverter::FloatToString(str_val, sizeof(str_volt), &vals_table[i /* - index_begin */].temp);
      StringConverter::f_to_str(str_val, sizeof(str_volt), vals_table[i /* - index_begin */].temp);
      // StringConverter::FloatToString(str_volt, sizeof(str_volt), &vals_table[i /* - index_begin */].volt);
      StringConverter::f_to_str(str_volt, sizeof(str_volt), vals_table[i /* - index_begin */].volt);
      StringConverter::IntToString(str_rssi, sizeof(str_rssi), vals_table[i /* - index_begin */].rssi);

      row_record.border           = GetBorder(i/* +1 */);
      row_record.lbl_num.text     = (char*)str_num;
      row_record.lbl_serial.text  = (char*)str_ser;
      row_record.lbl_value.text   = (char*)str_val;
      row_record.lbl_volt.text    = (char*)str_volt;
      row_record.lbl_rssi.text    = (char*)str_rssi;

      // row_record.border.p.y

      row_record.is_brigth = false;
      if((index) == i && is_brigth) {
        row_record.is_brigth = true;
        gui_apis.gfx->DrawRectFilled(
          row_record.border.p.x, 
          row_record.border.p.y, 
          row_record.border.p.x + row_record.border.width, 
          row_record.border.p.y + row_record.border.height - limits.bound + 1, 
          0xf
        );
      }
      row_record.Draw();
    }
  }
  BordersR TableWLTS2V::GetBorder(uint8_t index){
    BordersR res_border {};
    uint16_t 
      pos_horizontal  {},
      pos_vertical    {},
      width           {},
      height          {},
      field_width     {},
      field_height    {};
    
    /* По схеме: заполняем сначала строки сверху вниз */
    pos_horizontal = index % vol_horizontal_line;
    pos_vertical   = (index / vol_horizontal_line) % vol_vertical_line_it;

    width = border.width;
    height = border.height - header_height;
    field_width  = width / vol_horizontal_line;
    field_height = height / vol_vertical_line_it;
    res_border.width  = field_width;
    res_border.height = field_height;
    res_border.p.x    = border.p.x + (pos_horizontal * field_width);
    res_border.p.y    = border.p.y + header_height + (pos_vertical   * field_height);
    
    return res_border;
  }
  void TableWLTS2V::NextItem(){
    if(index < (volume - 1)) index++;
    else                     index = 0;
  }
  void TableWLTS2V::PreviuosItem(){
    if(index > 0) index--;
    else          index = volume - 1;
  }

  Mark::Mark(tguiapis gui_apis) : Component(gui_apis) {}
  Mark::Mark(tguiapis gui_apis, BordersR bordrs) : Component(gui_apis, bordrs) {}
  Mark::Mark(tguiapis gui_apis, BordersR bordrs, Images::tImageAlias image) : Component(gui_apis, bordrs), image_alias(image) {}

  void Mark::Draw() {
    if(/* gui_apis.font == nullptr && gui_apis.gfx == nullptr &&  */gui_apis.images == nullptr)
      return;

    gui_apis.images->SetImage(image_alias);
    uint16_t img_w = gui_apis.images->GetWidth();
    uint16_t img_h = gui_apis.images->GetHigh();

    if(border.width < img_w || border.height < img_h) return;

    gui_apis.images->DrawImage(border.p.x, border.p.y, is_brigth);
  }

#pragma endregion [UserPrimitives]
