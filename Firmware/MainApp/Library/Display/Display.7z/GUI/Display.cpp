#include "Display.h"
#include "SPIDisplay.h"
#include "SBDelay.h"

using namespace ICs;

Switcher    Display::power(GPIOD, GPIO_PINS_2, gpio_pull_type::GPIO_PULL_UP);    /* Питание дисплея */

Display::Display(ICs::SSD1322* ssd1322) : ic_ssd1322(ssd1322) { }

void Display::Init() {
  if(ic_ssd1322 == nullptr)
    return;
  power.Init();
  power.ON();
  SBDelay::Delay_ms(300);
  ic_ssd1322->Init();
  ic_ssd1322->SetDisplayMode(SSD1322::Mode_e::SSD1322_MODE_NORMAL);
  ic_ssd1322->SetGrayscaleDefault();
  ic_ssd1322->SetContrast(0x7F);      // default: ff
  ic_ssd1322->SetBrightness(0xFU);    // 
}

void Display::SetBuffer(uint8_t *frame) {
  frame_buffer = frame;
}

void Display::Update(uint16_t start_x, uint16_t start_y) {
  if(frame_buffer == nullptr)
    return;

  ic_ssd1322->SetWindow(0, 63, 0, 127);//0-63-0-127
  ic_ssd1322->SendBuffer(frame_buffer + (start_y * width / 2) + start_x, 8192);
  // "width / 2" - это умножить на 4 и разделить на 8. p.s. каждый писель это 4 бита градации серого.
}