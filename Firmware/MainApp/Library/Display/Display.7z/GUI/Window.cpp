#include "Window.h"

#include <cstring>
#include <cstdio>
#include <cmath>

#ifdef GLOB_USE_FREE_RTOS
  extern "C" {
    #include <FreeRTOSConfig.h>
    #include <FreeRTOS.h>
    #include <task.h>
    #include <queue.h>
    #include <timers.h>
    #include <semphr.h>
  }
#endif

#include "SBDelay.h"
#include "SBerryButtons.h"
#include "SBerryConfig.h"

#include "Dictionary.h"
#include "Fonts.h"
#include "Images.h"
#include "StringConverters.h"

#include "MBU_State.h"
#include "Page_Screensaver.h"
#include "BoardA_MainPage.h"
#include "BoardB_MainPage.h"
#include "BoardWLTS_MainPage.h"
#include "IOB_MainPage.h"
#include "MBU_MainPage.h"
#include "IOB_DebugPage.h"
#include "IOB_RootDir.h"
#include "IOB_Monitor.h"
#include "IOB_Monitor_AIN.h"
#include "IOB_Monitor_DIN.h"
#include "IOB_Monitor_AOUT.h"
#include "IOB_Monitor_DOUT.h"
#include "IOB_About.h"
#include "IOB_Settings.h"
#include "IOB_Password.h"
#include "IOB_CANBus.h"
#include "IOB_UB_reserv_ctrl.h"
#include "IOB_WLTS.h"

/*! 
  TODO: А можно потом сделать автоматический расчет!
*/
static_assert(PAGE_FACTORY_BUFFER_SIZE > (
  /* Проверка размера буфера по минимому. Количество узвлов + длина страниц */
  (ObjectStackFactory::tnode_size * 2U) +   
  sizeof(tafcoScreensaver)  +
  sizeof(BoardA_MainPage)),
  "Make the buffer size bigger!"
); 

#pragma region    [WindowTools]

  extern const char* Lbl_Example_0; //= Get("TAFCO", sizeof("TAFCO"), words); 
  extern const char* Lbl_Example_1; //= Get("ТАФКО", sizeof("ТАФКО"), words); 
  extern const char* Lbl_Example_2; //= Get("TAFCO ТАФКО", sizeof("TAFCO ТАФКО"), words); 
  extern const char* Lbl_example_3;

  SPI3Display     WindowTask::spi_disp(SPI3, SPI3_MUX);
  ICs::SSD1322    WindowTask::ic_ssd1322(&spi_disp);
  Display         WindowTask::display(&ic_ssd1322);
  Window          WindowTask::window((Display*)&WindowTask::display);

  void WindowTask::CreateTask() {
    xTaskCreate(WindowTask::Task, "WindowTask", 0x200, NULL, tskIDLE_PRIORITY + 1, NULL);
    #ifdef GLOB_USE_WACH_DOOGZ
      SBerryCore::SysWatchDog::AddTaskWatching(&watchdog, SBerryCore::WatchPuppy::FSM::fsm_wd_run);
      // watchdog.fsm = WatchPuppy::WDogFSM::fsm_wd_run;
    #endif
  }

  void WindowTask::Task(void* args) {
    vTaskDelay(1000);
    display.Init();
    window.Init();

    for (;;) {
      window.Loop();
      SBDelay::Delay_ms(33);
      #ifdef GLOB_USE_WACH_DOOGZ
        watchdog.ResetCounter(xTaskGetTickCount());
      #endif
      taskYIELD();
    }//__for(;;)
  }//__void WindowTask::Task(...)

  #pragma region    [Window]

    uint8_t     Window::gue_storage[gue_storage_size] {};

    Window::Window(Display* disp) : page_factory(Window::gue_storage, Window::gue_storage_size), display(disp) { }

    void Window::Init() {
      gfx.SetParameters(OLED_Height, OLED_Width, display_memory);
      display->SetBuffer(display_memory);
      font.SetParameters(OLED_Height, OLED_Width, display_memory);
      font.Select(font.VF_Font_10);
      images.SetParameters(OLED_Height, OLED_Width, display_memory);
      images.SetImage(images.img_tafco_home_big);

      // ClicksEvent::event.SetRecipient((ClicksEvent*)this);
      SBerryCore::ButtonsTask::click_event.SetRecipient(this);
      // event.SetRecipient((IDelegate<uint32_t>*)this);

      if(dev_config.conf_prod.tasks.main_board == SBerryCore::CFGParam::tSBerryBoard::MainBoard_MBU_PIC) {
        current_page = page_factory.Create<PageRootDir, Window>(this);
      }
      else if(
        dev_config.conf_prod.tasks.main_board == SBerryCore::CFGParam::tSBerryBoard::MainBoard_IOB_UNITA || 
        dev_config.conf_prod.tasks.main_board == SBerryCore::CFGParam::tSBerryBoard::MainBoard_IOB_UNITB || 
        dev_config.conf_prod.tasks.main_board == SBerryCore::CFGParam::tSBerryBoard::MainBoard_IOB_WLTS
      ) {
        current_page = page_factory.Create<PageIOMonitor_AIN, Window>(this);
      }
      if(current_page != nullptr) current_page->Init();

      if(dev_config.conf_user.password_user.pwd[0] > 0) { 
        password.is_set  = true;
        password.is_auth = false;
      }

      sreen_timeout = xTaskGetTickCount();
    }

    void Window::Loop() {
      
        if( (xTaskGetTickCount() - sreen_timeout) > ScreenSaverTimeout && is_sreen_saver == false) {
          is_sreen_saver  = true;
          if(
            password.is_set ||
            dev_config.conf_user.password_user.pwd[0] != 0
          ) password.is_auth = false;
          #ifndef GLOB_WORK_AS_PIC32
            //! TODO: По конфигурации!!!
            current_page    = page_factory.Create<tafcoScreensaver, Window>(this);
          #else
            current_page    = page_factory.Create<VestorScreensaver, Window>(this);
          #endif
          if(current_page != nullptr) current_page->Init();
        } 
        /*!
          TODO: Полностью перейти к конструкции ниже, т.е. добавить сюда скринсайвер   
        */
        if ( is_sreen_saver == false && command.name != tPageName::Page_Empty) {
          IPage* next_page { nullptr };

          if(command.name == PageName::Page_Previous && page_previous != PageName::Page_Empty) {
            command.name = page_previous; 
            page_previous = PageName::Page_Empty;
          }
          switch (command.name) {
            case PageName::Page_Previous:
                next_page = (IPage*)page_factory.GotoPrevious();
              break;
            case PageName::Page_Root:
                next_page = (IPage*)page_factory.Create<PageRootDir, Window>(this, command.is_new);
              break;
            case PageName::Page_MBU_State:
                next_page = (IPage*)page_factory.Create<MBU_Page_State, Window>(this, command.is_new);
                // next_page = (IPage*)page_factory.Create<MBU_MainPage, Window>(this, command.is_new); /* Страница для отладки  */
              break;
            case PageName::Page_MonitorRoot:
                next_page = (IPage*)page_factory.Create<PageIOMonitor, Window>(this, command.is_new);
              break;
            case PageName::Page_Monitor_AIN:
                next_page = (IPage*)page_factory.Create<PageIOMonitor_AIN, Window>(this, command.is_new);
              break;
            case PageName::Page_Monitor_DIN:
                next_page = (IPage*)page_factory.Create<PageIOMonitor_DIN, Window>(this, command.is_new);
              break;
            case PageName::Page_Monitor_AOUT:
                next_page = (IPage*)page_factory.Create<PageIOMonitor_AOUT, Window>(this, command.is_new);
              break;
            case PageName::Page_Monitor_DOUT:
                next_page = (IPage*)page_factory.Create<PageIOMonitor_DOUT, Window>(this, command.is_new);
              break;
            case PageName::Page_Password:
                next_page = (IPage*)page_factory.Create<IOB_PasswordRootDir, Window>(this, command.is_new);
              break;
            case PageName::Page_PasswordAuth:
                next_page = (IPage*)page_factory.Create<IOB_PasswordAuth, Window>(this, command.is_new);
              break;
            case PageName::Page_ScreenSaver:
              break;
            case PageName::Page_CANBus:
                next_page = (IPage*)page_factory.Create<IOB_PageCANBus, Window>(this, command.is_new);
              break;
            case PageName::Page_RSRControl:
                next_page = (IPage*)page_factory.Create<IOB_Page_UBRsvCtrl, Window>(this, command.is_new);
              break;
            case PageName::Page_WLTS_Root:
                next_page = (IPage*)page_factory.Create<IOB_Page_WLTS_Root, Window>(this, command.is_new);
              break;
            case PageName::Page_WLTS_Sens:
                next_page = (IPage*)page_factory.Create<IOB_Page_WLTS_Sensors, Window>(this, command.is_new);
              break;
            case PageName::Page_WLTS_Search:
                next_page = (IPage*)page_factory.Create<IOB_Page_WLTS_Search, Window>(this, command.is_new);
              break;
            case PageName::Page_About:
                next_page = (IPage*)page_factory.Create<IOBPageAbout, Window>(this, command.is_new);
              break;
            case PageName::Page_Debugz:
                next_page = (IPage*)page_factory.Create<IOBDebugPage, Window>(this, command.is_new);
              break;
            default:
                next_page = (IPage*)page_factory.Create<PageRootDir, Window>(this, command.is_new);
              break;
          }
          if(next_page != nullptr) {
            current_page = next_page;
          }
          else {
            next_page = (IPage*)page_factory.Create<PageRootDir, Window>(this, true);
          }
          command = {};
        }

      if(current_page != nullptr)
        current_page->Loop();

    }

    void Window::Invoke(uint32_t* code) {
      uint32_t loc_code = (*code);
      // #ifndef GLOB_WORK_AS_PIC32
        (*code) = 0;
        if(loc_code && is_sreen_saver == true) {
          is_sreen_saver  = false;
          //! TODO: Check error
          current_page    = (IPage*)page_factory.GotoPrevious(); 
          // if(current_page != nullptr) current_page->Init();
        }
        else if(current_page != nullptr) /* else иначе будет выполняться клик */
          current_page->ClickHandl(loc_code);
        sreen_timeout   = xTaskGetTickCount();
      // #endif
    }

    void Window::Clear(bool f_update) {
      gfx.FillBuffer(0);
      if(f_update && display != nullptr)
        display->Update(0,0);
    }

    void Window::GoToPage(tPageName name, bool is_new) {
      command = { name, is_new };
    }
  
    void Window::GoToPage(tPageName name) {
      GoToPage(name, false);
    }

    void Window::GoToPage(tPageName prev_page_name, tPageName page_name, bool is_new) {
      page_previous = prev_page_name;
      GoToPage(page_name, is_new);
    }

  #pragma endregion [Window]

#pragma endregion [WindowTools]