#ifndef _WINDOW_H_
#define _WINDOW_H_

  #include "SPIDisplay.h"

  #include <cassert>

  #include "SSD1322.h"
  #include "Display.h"
  #include "GFX.h"
  #include "Fonts.h"
  #include "StringConverters.h"
  #include "Images.h"
  #include "SBerryBoard.h"
  #include "ObjFactory.h"
  #include "Delegate.h"
  #include "WatchDog.h"
  #include "UControls.h"
  
  class Window;

  #pragma region    [Page Interface]

    /// @brief Интерфейс страниц
    class IPage {
      protected: 
        Window*     mwindow;
      
      public:
        IPage(Window* _window) : mwindow(_window) {}

        virtual void Init() = 0;

        virtual void ClickHandl(uint32_t code) = 0;
        
        virtual void Loop() = 0;
    };//__class IPage

    #define PAGE_INTERFACE_SIZE (sizeof(IPage))

  #pragma endregion [Page Interface]

  #pragma region    [WindowTools]

    /// @brief Главное окно 
    class WindowTask {
      #ifdef GLOB_USE_WACH_DOOGZ      
        inline static SBerryCore::WatchPuppy watchdog { GLOB_WPUPPY_RESET_PERIOD_WINDOW, GLOB_WPUPPY_RESET_PERIOD_WINDOW };    /* Пёс данной задачи */
      #endif
      static SPI3Display     spi_disp;
      static ICs::SSD1322    ic_ssd1322;
      static Display         display;
      static Window          window; 
      public:
        static void CreateTask();
        static void Task(void *args);
    };//__class WindowTask

    #define PAGE_FACTORY_BUFFER_SIZE      (4096)   /* Размер буфера для фабрики страниц */

    class Window : public SBerryCore::IDelegate<uint32_t> {
      friend WindowTask;
      static constexpr uint16_t mem_size {256 * 64 / 2};            /* Размер буфера для пикселей дисплея  */
      public:
        typedef enum PageName : uint8_t {
          Page_Empty,
          Page_Previous,          /* goto previous page */
          Page_Root,              /* Root Page of Menu */
          Page_MBU_State,         /* Status for MBU */
          Page_MonitorRoot,       /* Root page of io-monitors */
          Page_Monitor_AIN,       /* page of analog inputs */
          Page_Monitor_DIN,       /* page of digital inputs */
          Page_Monitor_AOUT,      /* page of analog outputs */
          Page_Monitor_DOUT,      /* page of digital ouutputs */
          Page_Password,          /* page of change password  */
          Page_PasswordAuth,      /* page of auth */
          Page_CANBus,            /* page of can-bus addr */
          Page_RSRControl,        /* Reserv Control for io2033 (UnitB) */
          Page_WLTS_Root,         /* WirelessTempSensor for (UnitWLTS) */
          Page_WLTS_Sens,         /* WirelessTempSensor for (UnitWLTS) */
          Page_WLTS_Search,       /* WirelessTempSensor for (UnitWLTS) */
          Page_ScreenSaver,       /* page of screensaver */
          Page_About,             /* page of extended information */
          Page_Debugz,            /* page of debug */
        } tPageName;
        inline static tPageName page_previous; /* Что бы не тратить RAM можно сохранять только название. Тогда при переходе на страницу, ее можно создавать, 
          и чтобы не потерять данные нужно либо их кешировать либо добавить аргумент, отвечающий за создание страницы или ее расположение в "стек" фабрики
        */
        static void GoToPage(tPageName name);
        static void GoToPage(tPageName name, bool is_new);
        static void GoToPage(tPageName prev_page_name, tPageName page_name, bool is_new);
      
      protected:
        /// @brief Конечный автомат "Окна"
        typedef enum WindowState : uint8_t {
          WIN_Loop,
          WIN_ScreenSaver,
          WIN_Page
        } tWindowState;

        // tWindowState  win_state         { tWindowState::WIN_Loop };    /* Состояние "окна" */

        static inline struct next_page_cmd {
          tPageName   name;
          bool        is_new;
        } command {};

        IPage*        current_page      { nullptr };                   /* Текущая страница */

        static constexpr uint16_t   gue_storage_size {PAGE_FACTORY_BUFFER_SIZE};   
        static uint8_t              gue_storage[gue_storage_size];

        static constexpr  uint32_t ScreenSaverTimeout {120000};     /* Таймаут включения заставки, default 120000 */
        uint32_t                   sreen_timeout {};                /* Счетчик таймаута заставки */
        bool                       is_sreen_saver { false };        /* Флаг заставки */
      public:
        uint8_t                   display_memory[mem_size];     // Буффер окна / кадра.
        ObjectStackFactory        page_factory;
        Display*                  display;
        GFX                       gfx;
        FontV                     font;
        Images                    images;
        struct WIN_Password {
          bool  is_set;   /* ??? Установлен ли */
          bool  is_auth;  /* Авторизован ли */
        } password {

        };
        Window(Display* disp);
      protected:
        void Init();
        void Loop();
      private:
        /// @brief Обработчик события нажатия клавиши
        /// @param [in] code    :: Код нажатия
        virtual void Invoke(uint32_t* code) override;
      public:
        /// @brief Очистить буфер и и обновить дисплей 
        void Clear(bool f_update = false);
    };//__class Window

  #pragma endregion [WindowTools]

#endif // _MWINDOW_H_