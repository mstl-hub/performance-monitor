#ifndef _DICTIONARY_H_
#define _DICTIONARY_H_

#include <cstdint>
#include <cstring>

// enum ID_Sentence { };

// #define SOURCE_EXAMPLE // Правильный пример
#ifdef SOURCE_EXAMPLE
  /// @brief Шаблон времени компиляции для построения строки с кодировкой ASCII (Для русских символов).
  /// @tparam N :: Размер 
  template <int N> // N includes the null-terminator
  class tASCIIString {
    public:
      constexpr tASCIIString(const char* c) {
        for (int i = 0; i < N; i++) {
          arr[i] = c[i];
        }
      }
      
      constexpr const char* c_str() {
        return arr;
      }
      
      char arr[N] = {};
  };

  const char* Hello_wt = tASCIIString<sizeof("hello")>("hello").c_str(); // Пример применения !

#elif 0
  template <int SRC_Size> // N includes the null-terminator
  // Расшарить до template<int Stock_Size, int Source_Size> !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  //        Т.е. сделать еще шаблон для подсчета символов !!!!!!
  class tASCIIString {
    public:
      constexpr tASCIIString(const char* src) __attribute__((optimize("O0"))) {
        int arr_index = 0, src_index = 0;
        // for(int j = 0; j < SRC_Size; ++j)
        while(src_index < SRC_Size) {
          if( src[src_index]!= 0xD0 && src[src_index]!= 0xD1 ) {
            // UTF8_unicode, могут быть символы по два байта и по одному из стандартной таблицы
            arr[arr_index] = src[src_index];
            src_index++;
          }
          else {
            uint16_t u16_symbol = *((uint16_t*)(&src[src_index]));
            u16_symbol = ((u16_symbol >> 8) & 0xFF) | ((u16_symbol & 0xFF) << 8);
            // В кодировке unicode между буквами 'п' и 'р' есть разрыв, поэтому удаляем::
            if(u16_symbol >= 0xD180)
              u16_symbol -= 0xC0;
            // Удаляем смещение с 0xD090 или преобразуем в ASCII::
            if(u16_symbol >= 0xD090)
              u16_symbol -= 0xCFD0;
            arr[arr_index] = static_cast<uint8_t>(u16_symbol);
            src_index += 2;
          }
          arr_index++;
        }
      }
      
      constexpr const char* c_str() {
        return arr;
      }
      
      char arr[SRC_Size] = {};
  };

#elif 1
    template <int SRC_Size> // N includes the null-terminator
  // Расшарить до template<int Stock_Size, int Source_Size> !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  //        Т.е. сделать еще шаблон для подсчета символов !!!!!!
  class tASCIIString {
    public:
      constexpr tASCIIString(const char* src)  {
        int arr_index = 0;
        // for(int j = 0; j < SRC_Size; ++j)
        for(uint8_t j = 0; j < SRC_Size; ++j) {
          if( src[j]!= 0xD0 && src[j]!= 0xD1 ) {
            // UTF8_unicode, могут быть символы по два байта и по одному из стандартной таблицы
            arr[arr_index] = src[j];
            // j++;
          }
          else {
            uint16_t u16_symbol = *((uint16_t*)(&src[j]));
            u16_symbol = ((u16_symbol >> 8) & 0xFF) | ((u16_symbol & 0xFF) << 8);
            // В кодировке unicode между буквами 'п' и 'р' есть разрыв, поэтому удаляем::
            if(u16_symbol >= 0xD180)
              u16_symbol -= 0xC0;
            // Удаляем смещение с 0xD090 или преобразуем в ASCII::
            if(u16_symbol >= 0xD090)
              u16_symbol -= 0xCFD0;
            arr[arr_index] = static_cast<uint8_t>(u16_symbol);
            j += 1;
          }
          arr_index++;
        }
      }
      
      constexpr const char* c_str() {
        return arr;
      }
      
      char arr[SRC_Size] = {};
  };

#endif // SOURCE_EXAMPLE


// static const char* Lbl_Example_0 = tASCIIString<sizeof("TAFCO")>("TAFCO").c_str(); 
// static const char* Lbl_Example_1 = tASCIIString<sizeof("ТАФКО")>("ТАФКО").c_str(); 
// static const char* Lbl_Example_2 = tASCIIString<sizeof("TAFCO ТАФКО")>("TAFCO ТАФКО").c_str(); 


static /* constexpr */ uint8_t words[100];

constexpr char* Get(const char* source, int SRC_Size, uint8_t *words_) {
  uint16_t arr_index = *((uint16_t*)&words[0]);
  if(arr_index == 0)
    arr_index += 2;
  // for(int j = 0; j < SRC_Size; ++j)
  for(uint8_t j = 0; j < SRC_Size; ++j) {
    if( source[j]!= 0xD0 && source[j]!= 0xD1 ) {
      // UTF8_unicode, могут быть символы по два байта и по одному из стандартной таблицы
      words_[arr_index] = source[j];
      // j++;
    }
    else {
      uint16_t u16_symbol = *((uint16_t*)(&source[j]));
      u16_symbol = ((u16_symbol >> 8) & 0xFF) | ((u16_symbol & 0xFF) << 8);
      // В кодировке unicode между буквами 'п' и 'р' есть разрыв, поэтому удаляем::
      if(u16_symbol >= 0xD180)
        u16_symbol -= 0xC0;
      // Удаляем смещение с 0xD090 или преобразуем в ASCII::
      if(u16_symbol >= 0xD090)
        u16_symbol -= 0xCFD0;
      words_[arr_index] = static_cast<uint8_t>(u16_symbol);
      j += 1;
    }
    arr_index++;
  }
  uint16_t temp_index = *((uint16_t*)&words[0]); 
  *((uint16_t*)&words[0]) = arr_index + 1;
  if(temp_index == 0)
    temp_index += 2;
  // return (char*)&words[temp_index];
  return (char*)(&words[temp_index]);
}

static const char* Lbl_Example_0 = Get("TAFCO", sizeof("TAFCO"), words); 
static const char* Lbl_Example_1 = Get("ТАФКО", sizeof("ТАФКО"), words); 
// static const char* Lbl_Example_2 = Get("TAFCO ТАФКО", sizeof("TAFCO ТАФКО"), words); 
static const char* Lbl_example_3 {"TAFCO ТАФКО"};

// constexpr uint8_t array[100U];


#endif // _DICTIONARY_H_